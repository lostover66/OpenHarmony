#include "iot_watchdog.h"
#include "stm32f4xx_ll_iwdg.h"
// 独立看门狗
void IoTWatchDogEnable(void){
   /* 2. 解锁 IWDG_PR 和 IWDG_RLR 寄存器的写保护 */
    LL_IWDG_EnableWriteAccess(IWDG);
    /* 3. 设置预分频器: 16 分频 (LSI / 256 ≈ 0.125kHz = 8ms) */
    LL_IWDG_SetPrescaler(IWDG, LL_IWDG_PRESCALER_256);
    /* 4. 设置重装载值 (12 位最大值为 1250) 10s之内喂狗*/
    LL_IWDG_SetReloadCounter(IWDG, 1250-1);
    /* 6. 启动独立看门狗 (此后无法停止) */
    LL_IWDG_Enable(IWDG);
}
// 喂狗
void IoTWatchDogKick(void){
    LL_IWDG_ReloadCounter(IWDG);
}
    void IoTWatchDogDisable(void){
        printf("IWDG can not disable\n");
    }