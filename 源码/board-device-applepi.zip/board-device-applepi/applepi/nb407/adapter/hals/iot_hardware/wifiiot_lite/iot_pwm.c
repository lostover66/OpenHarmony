#include "iot_pwm.h"
#include "ll_pwm.h"
#include "iot_errno.h"
#include "stm32f4xx_ll_rcc.h"
#include "ll_gpio.h"
#include "stm32f4xx_ll_tim.h"
/**
 * @brief Initializes a PWM device.
 *
 * @param port Indicates the port number of the PWM device.
 * @return Returns {@link IOT_SUCCESS} if the PWM device is initialized;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
extern PWM_ST g_pwmGroups[PWM_MAX];
unsigned int IoTPwmInit(unsigned int port){
    if(port<1 || port>PWM_MAX){
        printf("%s line %d,port must be 1~%d\n", __func__,__LINE__,PWM_MAX);
        return IOT_FAILURE;
    }
    // 设置引脚pwm模式
    if(LL_CONFIG_TIM_PIN(port) == ERROR){
        printf("%s line %d,LL_CONFIG_TIM_PIN failed\n", __func__,__LINE__);
        return IOT_FAILURE;
    }
    // 打开时钟
    LL_ENABLE_TIM_CLK(port);
    // 启用自动加载
    LL_TIM_OC_EnablePreload(g_pwmGroups[port-1].TIMx, \
        g_pwmGroups[port-1].ch);
    // 启用预加载
    LL_TIM_EnableARRPreload(g_pwmGroups[port-1].TIMx);
    // 设置使用内部时钟
    LL_TIM_SetClockSource(g_pwmGroups[port-1].TIMx, \
        LL_TIM_CLOCKSOURCE_INTERNAL);
    //  禁用快速模式
    LL_TIM_OC_DisableFast(g_pwmGroups[port-1].TIMx, \
        g_pwmGroups[port-1].ch);
    // 禁用输出触发
    LL_TIM_SetTriggerOutput(g_pwmGroups[port-1].TIMx,
        LL_TIM_TRGO_RESET);
    // 禁用主从模式
    LL_TIM_DisableMasterSlaveMode(g_pwmGroups[port-1].TIMx);
    return IOT_SUCCESS;
}   

/**
 * @brief Deinitializes a PWM device.
 *
 * @param port Indicates the port number of the PWM device.
 * @return Returns {@link IOT_SUCCESS} if the PWM device is deinitialized;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTPwmDeinit(unsigned int port){
    if(port<1 || port>PWM_MAX){
        printf("%s line %d,port must be 1~%d\n", __func__,__LINE__,PWM_MAX);
        return IOT_FAILURE;
    }
    uint8_t group = g_pwmGroups[port-1].realPin/16;
    // 复位引脚
    if(LL_GPIO_DeInit(LL_GET_GPIOX(g_pwmGroups[port-1].realPin)) == ERROR){
        printf("%s line %d, LL_GPIO_DeInit failed\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    // 复位定时器
    if(LL_TIM_DeInit(LL_GET_TIMx(port)) == ERROR){
        printf("%s line %d, LL_TIM_DeInit failed\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    return IOT_SUCCESS;
}

/**
 * @brief Starts PWM signal output from a specified port based on the given output frequency and duty cycle.
 *
 *
 *
 * @param port Indicates the port number of the PWM device.
 * @param duty Indicates the duty cycle for PWM signal output. The value ranges from 1 to 99.
 * @param freq Indicates the frequency for PWM signal output.
 * @return Returns {@link IOT_SUCCESS} if the PWM signal output is started;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTPwmStart(unsigned int port, unsigned short duty, unsigned int freq){
    if(port<1 || port>PWM_MAX){
        printf("%s line %d,port must be 1~%d\n", __func__,__LINE__,PWM_MAX);
        return IOT_FAILURE;
    }
    if(duty>100){
        printf("%s line %d,duty must be 0~100\n", __func__,__LINE__);
        return IOT_FAILURE;
    }
    LL_TIM_InitTypeDef TIM_InitStruct={0};
    LL_TIM_OC_InitTypeDef TIM_OC_InitStruct={0};
    LL_RCC_ClocksTypeDef rcc={0};
    TIM_TypeDef *timx = g_pwmGroups[port-1].TIMx;
    // 获取RCC.APBx
    LL_RCC_GetSystemClocksFreq(&rcc);
    // 给结构体赋值
    TIM_InitStruct.CounterMode = LL_TIM_COUNTERDIRECTION_UP;
    TIM_InitStruct.ClockDivision = LL_TIM_CLOCKDIVISION_DIV1;
    TIM_InitStruct.RepetitionCounter = 0;
    // 根据timx决定rcc使用APBx
    if(timx==TIM2 || timx==TIM3 || timx==TIM4 || timx==TIM5 \
        || timx==TIM12 || timx==TIM13 || timx==TIM14)
        if(LL_CAL_TIM_PARAMS(rcc.PCLK1_Frequency, duty, freq,\
            &TIM_InitStruct.Prescaler, \
            &TIM_InitStruct.Autoreload, \
            &TIM_OC_InitStruct.CompareValue)==ERROR){
                printf("%s line %d,LL_CAL_TIM_PARAMS failed\n", __func__, __LINE__);
                return IOT_FAILURE;
            }
    else
        if(LL_CAL_TIM_PARAMS(rcc.PCLK2_Frequency, duty, freq,\
            &TIM_InitStruct.Prescaler, \
            &TIM_InitStruct.Autoreload, \
            &TIM_OC_InitStruct.CompareValue)==ERROR){
                printf("%s line %d,LL_CAL_TIM_PARAMS failed\n", __func__, __LINE__);
                return IOT_FAILURE;
            }
    TIM_OC_InitStruct.OCMode = LL_TIM_OCMODE_PWM1;
    TIM_OC_InitStruct.OCState =LL_TIM_OCSTATE_ENABLE;
    TIM_OC_InitStruct.OCNState = LL_TIM_OCSTATE_DISABLE;
    TIM_OC_InitStruct.OCPolarity = LL_TIM_OCPOLARITY_HIGH;
    // 初始化结构体
    if(LL_TIM_Init(timx, &TIM_InitStruct)==ERROR){
        printf("%s line %d, LL_TIM_Init failed\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    if(LL_TIM_OC_Init(timx, g_pwmGroups[port-1].ch, &TIM_OC_InitStruct)==ERROR){
        printf("%s line %d, LL_TIM_OC_Init failed\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    // 启动通道
    LL_TIM_CC_EnableChannel(timx, g_pwmGroups[port-1].ch);
    LL_TIM_EnableAllOutputs(timx);
    LL_TIM_EnableCounter(timx);
    return IOT_SUCCESS;
}

/**
 * @brief Stops PWM signal output from a specified port.
 *
 * @param port Indicates the port number of the PWM device.
 * @return Returns {@link IOT_SUCCESS} if the PWM signal output is stopped;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTPwmStop(unsigned int port){
    if(port<1 || port>PWM_MAX){
        printf("%s line %d,port must be 1~%d\n", __func__,__LINE__,PWM_MAX);
        return IOT_FAILURE;
    }
    // 关闭通道
    LL_TIM_CC_DisableChannel(g_pwmGroups[port-1].TIMx, \
        g_pwmGroups[port-1].ch);
    // 关闭定时器，导致timx对应的4个通道都被关闭
    LL_TIM_DisableCounter(g_pwmGroups[port-1].TIMx);
}

