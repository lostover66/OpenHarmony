#include "iot_flash.h"
#include "iot_errno.h"
#include "reg_flash.h"

/**
 * @brief Reads data from a flash memory address.
 *
 * This function reads a specified length of data from a specified flash memory address.
 *
 * @param flashOffset Indicates the address of the flash memory from which data is to read.
 * @param size Indicates the length of the data to read.
 * @param ramData Indicates the pointer to the RAM for storing the read data.
 * @return Returns {@link IOT_SUCCESS} if the data is read successfully;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTFlashRead(unsigned int flashOffset, unsigned int size, unsigned char *ramData){
    uint32_t word_cnt;
    word_cnt = size/4 + (size%4)==0?0:1;
    uint32_t *buf = (uint32_t)malloc(word_cnt*4);
    flash_read_buffer(flashOffset, buf, word_cnt);
    memcpy(buf, ramData, size);
}

/**
 * @brief Writes data to a flash memory address.
 *
 * This function writes a specified length of data to a specified flash memory address.
 *
 * @param flashOffset Indicates the address of the flash memory to which data is to be written.
 * @param size Indicates the length of the data to write.
 * @param ramData Indicates the pointer to the RAM for storing the data to write.
 * @param doErase Specifies whether to automatically erase existing data.
 * @return Returns {@link IOT_SUCCESS} if the data is written successfully;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTFlashWrite(unsigned int flashOffset, unsigned int size,
                           const unsigned char *ramData, unsigned char doErase){
    
    flash_erase_sector(7);
    flash_program_word(uint32_t addr, uint32_t data);
}

/**
 * @brief Erases data in a specified flash memory address.
 *
 * @param flashOffset Indicates the flash memory address.
 * @param size Indicates the data length in bytes.
 * @return Returns {@link IOT_SUCCESS} if the data is erased successfully;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTFlashErase(unsigned int flashOffset, unsigned int size){

}

/**
 * @brief Initializes a flash device.
 *
 * @return Returns {@link IOT_SUCCESS} if the flash device is initialized;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTFlashInit(void){

}

/**
 * @brief Deinitializes a flash device.
 *
 * @return Returns {@link IOT_SUCCESS} if the flash device is deinitialized;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTFlashDeinit(void){

}