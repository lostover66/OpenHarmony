#include "iot_gpio.h"
#include "iot_errno.h"
#include "ll_gpio.h"
#include "ll_exti.h"
#include "stdio.h"

/**
 * @brief Initializes a GPIO device.
 *
 * @param id Indicates the GPIO pin number.
 * @return Returns {@link IOT_SUCCESS} if the GPIO device is initialized;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
extern PIN_ST g_pinsGroup[STM32_GPIO_GROUP_MAX*STM32_GPIO_PIN_MAX];
unsigned int IoTGpioInit(unsigned int id){
    // 检测参数
    if(id >= STM32_GPIO_GROUP_MAX*STM32_GPIO_PIN_MAX){
        printf("%s line %d error, invalid pin\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    // 打开时钟
    LL_AHB1_GRP1_EnableClock(LL_GET_GPIO_CLK(id));
    // 初始化GPIO结构体
    LL_CONFIG_GPIO(id, LL_GPIO_MODE_OUTPUT,LL_GPIO_PULL_NO,\
        LL_GPIO_SPEED_FREQ_HIGH,LL_GPIO_OUTPUT_PUSHPULL,\
        LL_GPIO_AF_0);
    // LL_GPIO_Init
    ErrorStatus status;
    status = LL_GPIO_Init(LL_GET_GPIOX(id), &g_pinsGroup[id].gpioStruct);
    if(status != SUCCESS){
        printf("%s line %d error\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    return IOT_SUCCESS;
}

/**
 * @brief Deinitializes a GPIO device.
 *
 * @param id Indicates the GPIO pin number.
 * @return Returns {@link IOT_SUCCESS} if the GPIO device is deinitialized;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTGpioDeinit(unsigned int id){
    // 检测参数
    if(id >= STM32_GPIO_GROUP_MAX*STM32_GPIO_PIN_MAX){
        printf("%s line %d error, invalid pin\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    
    ErrorStatus status;
    status = LL_GPIO_DeInit(LL_GET_GPIOX(id));
    if(status != SUCCESS){
        printf("%s line %d error\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    return IOT_SUCCESS;
}

/**
 * @brief Sets the direction for a GPIO pin.
 *
 * @param id Indicates the GPIO pin number.
 * @param dir Indicates the GPIO input/output direction.
 * @return Returns {@link IOT_SUCCESS} if the direction is set;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTGpioSetDir(unsigned int id, IotGpioDir dir){
    // 检测参数
    if(id >= STM32_GPIO_GROUP_MAX*STM32_GPIO_PIN_MAX){
        printf("%s line %d error, invalid pin\n", __func__, __LINE__);
        return IOT_FAILURE;
    }

    if(dir == IOT_GPIO_DIR_IN){
        LL_GPIO_SetPinMode(LL_GET_GPIOX(id),\
            LL_GET_GPIO_PIN(id),LL_GPIO_MODE_INPUT);
    }
    else if(dir == IOT_GPIO_DIR_OUT){
        LL_GPIO_SetPinMode(LL_GET_GPIOX(id),\
            LL_GET_GPIO_PIN(id),LL_GPIO_MODE_OUTPUT);
    }else{
        printf("%s line %d error, invalid dir\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    return IOT_SUCCESS;
}

/**
 * @brief Obtains the direction for a GPIO pin.
 *
 * @param id Indicates the GPIO pin number.
 * @param dir Indicates the pointer to the GPIO input/output direction.
 * @return Returns {@link IOT_SUCCESS} if the direction is obtained;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTGpioGetDir(unsigned int id, IotGpioDir *dir){
    // 检测参数
    if(id >= STM32_GPIO_GROUP_MAX*STM32_GPIO_PIN_MAX){
        printf("%s line %d error, invalid pin\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    
    uint32_t res=LL_GPIO_GetPinMode(LL_GET_GPIOX(id),LL_GET_GPIO_PIN(id));
    if(res == LL_GPIO_MODE_INPUT)
        *dir = IOT_GPIO_DIR_IN;
    else if(res == LL_GPIO_MODE_OUTPUT)
        *dir = IOT_GPIO_DIR_OUT;
    else
        return IOT_FAILURE;
    return IOT_SUCCESS;
}

/**
 * @brief Sets the output level value for a GPIO pin.
 *
 * @param id Indicates the GPIO pin number.
 * @param val Indicates the output level value.
 * @return Returns {@link IOT_SUCCESS} if the output level value is set;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTGpioSetOutputVal(unsigned int id, IotGpioValue val){
    // 检测参数
    if(id >= STM32_GPIO_GROUP_MAX*STM32_GPIO_PIN_MAX){
        printf("%s line %d error, invalid pin\n", __func__, __LINE__);
        return IOT_FAILURE;
    }

    if(val == IOT_GPIO_VALUE1)
        LL_GPIO_SetOutputPin(LL_GET_GPIOX(id), LL_GET_GPIO_PIN(id));
    else if(val == IOT_GPIO_VALUE0)
        LL_GPIO_ResetOutputPin(LL_GET_GPIOX(id), LL_GET_GPIO_PIN(id));
    else{
        printf("%s line %d error, invalid dir\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    return IOT_SUCCESS;
}

/**
 * @brief Obtains the output level value of a GPIO pin.
 *
 * @param id Indicates the GPIO pin number.
 * @param val Indicates the pointer to the output level value.
 * @return Returns {@link IOT_SUCCESS} if the output level value is obtained;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTGpioGetOutputVal(unsigned int id, IotGpioValue *val){
    // 检测参数
    if(id >= STM32_GPIO_GROUP_MAX*STM32_GPIO_PIN_MAX){
        printf("%s line %d error, invalid pin\n", __func__, __LINE__);
        return IOT_FAILURE;
    }

    uint32_t res = LL_GPIO_IsOutputPinSet(LL_GET_GPIOX(id), LL_GET_GPIO_PIN(id));
    if(res == 1)
        *val = IOT_GPIO_VALUE1;
    else
        *val = IOT_GPIO_VALUE0;
    return IOT_SUCCESS;
}

/**
 * @brief Obtains the input level value of a GPIO pin.
 *
 * @param id Indicates the GPIO pin number.
 * @param val Indicates the pointer to the input level value.
 * @return Returns {@link IOT_SUCCESS} if the input level value is obtained;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTGpioGetInputVal(unsigned int id, IotGpioValue *val){
    // 检测参数
    if(id >= STM32_GPIO_GROUP_MAX*STM32_GPIO_PIN_MAX){
        printf("%s line %d error, invalid pin\n", __func__, __LINE__);
        return IOT_FAILURE;
    }

    uint32_t res = LL_GPIO_IsInputPinSet(LL_GET_GPIOX(id), LL_GET_GPIO_PIN(id));
    if(res == 1)
        *val = IOT_GPIO_VALUE1;
    else
        *val = IOT_GPIO_VALUE0;
    return IOT_SUCCESS;
}

/**
 * @brief Enables the interrupt feature for a GPIO pin.
 *
 * This function can be used to set the interrupt type, interrupt polarity, and interrupt callback for a GPIO pin.
 *
 * @param id Indicates the GPIO pin number.
 * @param intType Indicates the interrupt type.
 * @param intPolarity Indicates the interrupt polarity.
 * @param func Indicates the interrupt callback function.
 * @param arg Indicates the pointer to the argument used in the interrupt callback function.
 * @return Returns {@link IOT_SUCCESS} if the interrupt feature is enabled;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTGpioRegisterIsrFunc(unsigned int id, IotGpioIntType intType, IotGpioIntPolarity intPolarity,
                                    GpioIsrCallbackFunc func, char *arg){
    // 检测参数
    if(id >= STM32_GPIO_GROUP_MAX*STM32_GPIO_PIN_MAX){
        printf("%s line %d error, invalid pin\n", __func__, __LINE__);
        return IOT_FAILURE;
    }  
    uint8_t pin = id%16;                            
    LL_EXTI_InitTypeDef cfg;
    // 外部中断线 2^n
    cfg.Line_0_31 = LL_EXTI_LINE_0<<pin;
    // 是否允许中断
    cfg.LineCommand = ENABLE;
    // 中断极性
    if(intPolarity == IOT_GPIO_EDGE_RISE_LEVEL_HIGH)
        cfg.Trigger = LL_EXTI_TRIGGER_RISING;
    else if(intPolarity == IOT_GPIO_EDGE_FALL_LEVEL_LOW)
        cfg.Trigger = LL_EXTI_TRIGGER_FALLING;
    else{
        printf("%s line %d error, invalid intPolarity\n",__func__, __LINE__);
        return IOT_FAILURE;
    }
    // 中断方式
    if(intType == IOT_INT_TYPE_EDGE)
        cfg.Mode = LL_EXTI_MODE_IT;
    else if(intType == IOT_INT_TYPE_LEVEL){
        printf("%s line %d error,invalid inttype,stm32f4 do not surpport level mode\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    else{
        printf("%s line %d error, invalid intType\n",__func__, __LINE__);
        return IOT_FAILURE;
    }
    if(LL_SETUP_EXTI(id, cfg, func)==ERROR){
        return IOT_FAILURE;
    }
    // 使能中断
    LL_EXTI_EnableIT_0_31(cfg.Line_0_31);
    return IOT_SUCCESS;
}

/**
 * @brief Disables the interrupt feature for a GPIO pin.
 *
 * @param id Indicates the GPIO pin number.
 * @return Returns {@link IOT_SUCCESS} if the interrupt feature is disabled;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTGpioUnregisterIsrFunc(unsigned int id){
    // 检测参数
    if(id >= STM32_GPIO_GROUP_MAX*STM32_GPIO_PIN_MAX){
        printf("%s line %d error, invalid pin\n", __func__, __LINE__);
        return IOT_FAILURE;
    }

    uint8_t pin = id%16;
    if(pin<=4)
        NVIC_SetVector(EXTI0_IRQn+pin, 0);
    else if(pin>=5 && pin<=9)
        NVIC_SetVector(EXTI9_5_IRQn, 0);
    else if(pin>=10 && pin<=15)
        NVIC_SetVector(EXTI15_10_IRQn, 0);
    return IOT_SUCCESS;
}

/**
 * @brief Masks the interrupt feature for a GPIO pin.
 *
 * @param id Indicates the GPIO pin number.
 * @param mask Indicates whether the interrupt function is masked.
 * The value <b>1</b> means to mask the interrupt function, and <b>0</b> means not to mask the interrupt function.
 * @return Returns {@link IOT_SUCCESS} if the interrupt feature is masked;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTGpioSetIsrMask(unsigned int id, unsigned char mask){
    // 检测参数
    if(id >= STM32_GPIO_GROUP_MAX*STM32_GPIO_PIN_MAX){
        printf("%s line %d error, invalid pin\n", __func__, __LINE__);
        return IOT_FAILURE;
    }

    if(mask == 1){
        LL_EXTI_DisableIT_0_31(LL_EXTI_LINE_0<<(id%16));
    }
    return IOT_SUCCESS;
}

/**
 * @brief Sets the interrupt trigger mode of a GPIO pin.
 *
 * This function configures a GPIO pin based on the interrupt type and interrupt polarity.
 *
 * @param id Indicates the GPIO pin number.
 * @param intType Indicates the interrupt type.
 * @param intPolarity Indicates the interrupt polarity.
 * @return Returns {@link IOT_SUCCESS} if the interrupt trigger mode is set;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTGpioSetIsrMode(unsigned int id, IotGpioIntType intType, IotGpioIntPolarity intPolarity){
    // 检测参数
    if(id >= STM32_GPIO_GROUP_MAX*STM32_GPIO_PIN_MAX){
        printf("%s line %d error, invalid pin\n", __func__, __LINE__);
        return IOT_FAILURE;
    }

    return IoTGpioRegisterIsrFunc(id, intType, intPolarity,g_pinsGroup[id].handler ,NULL);
}
