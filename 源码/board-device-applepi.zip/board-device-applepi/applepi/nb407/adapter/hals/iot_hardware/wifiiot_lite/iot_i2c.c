#include "iot_i2c.h"
#include "iot_errno.h"
#include "ll_i2c.h"
#include "stm32f4xx_ll_i2c.h"
#include "stdio.h"

extern I2C_ST g_i2cGroups[I2C_MAX];
/**
 * @brief Initializes an I2C device with a specified baud rate.
 *
 *
 *
 * @param id Indicates the I2C device ID.
 * @param baudrate Indicates the I2C baud rate.
 * @return Returns {@link IOT_SUCCESS} if the I2C device is initialized;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTI2cInit(unsigned int id, unsigned int baudrate)
{
    // 检测id
    if (id > I2C_MAX)
    {
        printf("%s line %d, invalid id, 1<=id<=%d\n", __func__, __LINE__, I2C_MAX);
        return IOT_FAILURE;
    }
    // 检测baudrate 最大400k
    if (baudrate > 400 * 1000)
    {
        printf("%s line %d, invalid buad, buadrate<=400k\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    // 将引脚配置为I2C功能
    if (LL_CONFIG_I2C_PIN(id) == ERROR)
    {
        printf("%s line %d, LL_CONFIG_I2C_PIN failed\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    // 打开I2C时钟
    LL_APB1_GRP1_EnableClock(LL_GET_I2C_CLK(id));

    LL_I2C_InitTypeDef I2C_InitStruct = {0};
    // 关闭从机模式
    LL_I2C_DisableOwnAddress2(g_i2cGroups[id - 1].I2Cx);
    // 禁止广播
    LL_I2C_DisableGeneralCall(g_i2cGroups[id - 1].I2Cx);
    // 使能时钟延长
    LL_I2C_EnableClockStretching(g_i2cGroups[id - 1].I2Cx);
    // 配置结构体
    I2C_InitStruct.PeripheralMode = LL_I2C_MODE_I2C;
    // 波特率
    I2C_InitStruct.ClockSpeed = baudrate; // 默认100k
    I2C_InitStruct.DutyCycle = LL_I2C_DUTYCYCLE_2;
    I2C_InitStruct.OwnAddress1 = 0;
    // 设置有应答
    I2C_InitStruct.TypeAcknowledge = LL_I2C_ACK;
    // 7位地址
    I2C_InitStruct.OwnAddrSize = LL_I2C_OWNADDRESS1_7BIT;
    if (LL_I2C_Init(g_i2cGroups[id - 1].I2Cx, &I2C_InitStruct) == ERROR)
    {
        printf("%s line %d, LL_I2C_Init failed\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    LL_I2C_SetOwnAddress2(g_i2cGroups[id - 1].I2Cx, 0);
    // 保存I2C_InitStruct
    g_i2cGroups[id - 1].li2c = I2C_InitStruct;
    // 使能I2C
    LL_I2C_Enable(g_i2cGroups[id - 1].I2Cx);
    return IOT_SUCCESS;
}

/**
 * @brief Deinitializes an I2C device.
 *
 * @param id Indicates the I2C device ID.
 * @return Returns {@link IOT_SUCCESS} if the I2C device is deinitialized;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTI2cDeinit(unsigned int id)
{
    // 检测id
    if (id > I2C_MAX)
    {
        printf("%s line %d, invalid id, 1<=id<=%d\n", __func__, __LINE__, I2C_MAX);
        return IOT_FAILURE;
    }
    // 复位gpio
    if (LL_GPIO_DeInit(LL_GET_GPIOX(g_i2cGroups[id - 1].scl)) == ERROR)
    {
        printf("%s line %d, LL_GPIO_DeInit scl failed\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    if (LL_GPIO_DeInit(LL_GET_GPIOX(g_i2cGroups[id - 1].sda)) == ERROR)
    {
        printf("%s line %d, LL_GPIO_DeInit sda failed\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    // 复位i2c
    if (LL_I2C_DeInit(g_i2cGroups[id - 1].I2Cx) == ERROR)
    {
        printf("%s line %d, LL_I2C_DeInit failed\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    return IOT_SUCCESS;
}

/**
 * @brief Writes data to an I2C device.
 *
 *
 *
 * @param id Indicates the I2C device ID.
 * @param deviceAddr Indicates the I2C device address.
 * @param data Indicates the pointer to the data to write.
 * @param dataLen Indicates the length of the data to write.
 * @return Returns {@link IOT_SUCCESS} if the data is written to the I2C device successfully;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTI2cWrite(unsigned int id, unsigned short deviceAddr, const unsigned char *data, unsigned int dataLen)
{
    // 检测id
    if (id > I2C_MAX)
    {
        printf("%s line %d, invalid id, 1<=id<=%d\n", __func__, __LINE__, I2C_MAX);
        return IOT_FAILURE;
    }
    if(data == NULL){
        printf("%s line %d error, data is NULL\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    // 生成起始信号
    LL_I2C_GenerateStartCondition(g_i2cGroups[id - 1].I2Cx);
    // 判断是否生成
    uint64_t start_tick, end_tick;
    start_tick = LL_GetTick();
    while (!LL_I2C_IsActiveFlag_SB(g_i2cGroups[id - 1].I2Cx))
    {
        end_tick = LL_GetTick();
        if (end_tick - start_tick > 1000 * I2C_TIMEOUT)
        {
            printf("%s line %d, Generate Start Condition timeout\n", __func__, __LINE__);
            return IOT_FAILURE;
        }
    }
    // 等待进入主机模式
    start_tick = LL_GetTick();
    while (!LL_I2C_IsActiveFlag_MSL(g_i2cGroups[id - 1].I2Cx))
    {
        end_tick = LL_GetTick();
        if (end_tick - start_tick > 1000 * I2C_TIMEOUT)
        {
            printf("%s line %d, enter master mode timeout\n", __func__, __LINE__);
            return IOT_FAILURE;
        }
    }
    /***********************SLAVE ADDR******************/
    // 发送从机地址 最低位0代表写，1代表读
    LL_I2C_TransmitData8(g_i2cGroups[id - 1].I2Cx, (deviceAddr << 1) + 0);
    // 等待从机地址发送完毕
    start_tick = LL_GetTick();
    while (!LL_I2C_IsActiveFlag_ADDR(g_i2cGroups[id - 1].I2Cx))
    {
        end_tick = LL_GetTick();
        if (end_tick - start_tick > 1000 * I2C_TIMEOUT)
        {
            printf("%s line %d, enter master mode timeout\n", __func__, __LINE__);
            return IOT_FAILURE;
        }
    }
    // 清空地址位
    LL_I2C_ClearFlag_ADDR(g_i2cGroups[id - 1].I2Cx);
    /***********************DATA******************/
    // 发送数据
    for (uint32_t i = 0; i < dataLen; i++)
    {
        LL_I2C_TransmitData8(g_i2cGroups[id - 1].I2Cx, data[i]);
        // 等待当前数据发送完毕
        start_tick = LL_GetTick();
        while (!LL_I2C_IsActiveFlag_TXE(g_i2cGroups[id - 1].I2Cx)){
            end_tick = LL_GetTick();
            if (end_tick - start_tick > 1000 * I2C_TIMEOUT){
                printf("%s line %d, send data%d\n", __func__, __LINE__, i);
                return IOT_FAILURE;
            }
        }
    }
    // 等待数据发送完毕
    start_tick = LL_GetTick();
    while(!LL_I2C_IsActiveFlag_BTF(g_i2cGroups[id - 1].I2Cx)){
        end_tick = LL_GetTick();
        if (end_tick - start_tick > 1000 * I2C_TIMEOUT){
            printf("%s line %d send failed\n", __func__, __LINE__);
            return IOT_FAILURE;
        }
    }
    /***********************END******************/
    // 生成结束信号
    LL_I2C_GenerateStopCondition(g_i2cGroups[id - 1].I2Cx);
    return IOT_SUCCESS;
}

/**
 * @brief Reads data from an I2C device.
 *
 * The data read will be saved to the address specified by <b>i2cData</b>.
 *
 * @param id Indicates the I2C device ID.
 * @param deviceAddr Indicates the I2C device address.
 * @param data Indicates the pointer to the data to read.
 * @param dataLen Indicates the length of the data to read.
 * @return Returns {@link IOT_SUCCESS} if the data is read from the I2C device successfully;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTI2cRead(unsigned int id, unsigned short deviceAddr, unsigned char *data, unsigned int dataLen)
{
    // 检测id
    if (id > I2C_MAX)
    {
        printf("%s line %d, invalid id, 1<=id<=%d\n", __func__, __LINE__, I2C_MAX);
        return IOT_FAILURE;
    }
    if(data == NULL){
        printf("%s line %d error, data is NULL\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    /******************start*****************/
    // 生成起始信号
    LL_I2C_GenerateStartCondition(g_i2cGroups[id - 1].I2Cx);
    // 判断是否生成
    uint64_t start_tick, end_tick;
    start_tick = LL_GetTick();
    while (!LL_I2C_IsActiveFlag_SB(g_i2cGroups[id - 1].I2Cx))
    {
        end_tick = LL_GetTick();
        if (end_tick - start_tick > 1000 * I2C_TIMEOUT)
        {
            printf("%s line %d, Generate Start Condition timeout\n", __func__, __LINE__);
            return IOT_FAILURE;
        }
    }
    // 等待进入主机模式
    start_tick = LL_GetTick();
    while (!LL_I2C_IsActiveFlag_MSL(g_i2cGroups[id - 1].I2Cx))
    {
        end_tick = LL_GetTick();
        if (end_tick - start_tick > 1000 * I2C_TIMEOUT)
        {
            printf("%s line %d, enter master mode timeout\n", __func__, __LINE__);
            return IOT_FAILURE;
        }
    }
    /***********************SLAVE ADDR******************/
    // 发送从机地址 最低位0代表写，1代表读
    LL_I2C_TransmitData8(g_i2cGroups[id - 1].I2Cx, (deviceAddr << 1) + 1);
    // 等待从机地址发送完毕
    start_tick = LL_GetTick();
    while (!LL_I2C_IsActiveFlag_ADDR(g_i2cGroups[id - 1].I2Cx))
    {
        end_tick = LL_GetTick();
        if (end_tick - start_tick > 1000 * I2C_TIMEOUT)
        {
            printf("%s line %d, enter master mode timeout\n", __func__, __LINE__);
            return IOT_FAILURE;
        }
    }
    // 如果是一个数据
    if(dataLen==1){
        // 设置非应答
        LL_I2C_AcknowledgeNextData(g_i2cGroups[id-1].I2Cx, LL_I2C_NACK);
        // 清空地址标记
        LL_I2C_ClearFlag_ADDR(g_i2cGroups[id-1].I2Cx);
        // 生成停止位
        LL_I2C_GenerateStopCondition(g_i2cGroups[id-1].I2Cx);
    }else{
        LL_I2C_ClearFlag_ADDR(g_i2cGroups[id-1].I2Cx);
    }
    /*******************data********************/
    // 接收数据
    for(uint32_t i=0; i<dataLen; i++){
        // 等待接收区非空
        start_tick = LL_GetTick();
        while(!LL_I2C_IsActiveFlag_RXNE(g_i2cGroups[id-1].I2Cx)){
            end_tick = LL_GetTick();
            if (end_tick - start_tick > 1000 * I2C_TIMEOUT){
                printf("%s line %d, recv timeout\n", __func__, __LINE__);
                return IOT_FAILURE;
            }
        }
        data[i] = LL_I2C_ReceiveData8(g_i2cGroups[id-1].I2Cx);
        // 倒数第二个数据设置非应答 // 生成停止位
        if(i == dataLen-2){
            LL_I2C_AcknowledgeNextData(g_i2cGroups[id-1].I2Cx, LL_I2C_NACK);
            LL_I2C_GenerateStopCondition(g_i2cGroups[id-1].I2Cx);
        } 
    }
    return IOT_SUCCESS;
}

/**
 * @brief Sets the baud rate for an I2C device.
 *
 * @param id Indicates the I2C device ID.
 * @param baudrate Indicates the baud rate to set.
 * @return Returns {@link IOT_SUCCESS} if the baud rate is set;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTI2cSetBaudrate(unsigned int id, unsigned int baudrate)
{
    // 检测id
    if (id > I2C_MAX)
    {
        printf("%s line %d, invalid id, 1<=id<=%d\n", __func__, __LINE__, I2C_MAX);
        return IOT_FAILURE;
    }
    // 检测baudrate 最大400k
    if (baudrate > 400 * 1000)
    {
        printf("%s line %d, invalid buad, buadrate<=400k\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    g_i2cGroups[id - 1].li2c.ClockSpeed = baudrate;
    if (LL_I2C_Init(g_i2cGroups[id - 1].I2Cx, &g_i2cGroups[id - 1].li2c) == ERROR)
    {
        printf("%s line %d, LL_I2C_Init failed\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    return IOT_SUCCESS;
}
