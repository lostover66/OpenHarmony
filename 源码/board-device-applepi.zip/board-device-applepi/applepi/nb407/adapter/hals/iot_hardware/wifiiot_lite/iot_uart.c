#include "iot_uart.h"
#include "ll_gpio.h"
#include "ll_uart.h"
#include "queue.h"
#include "stm32f4xx_ll_usart.h"
#include "iot_errno.h"

extern UART_ST g_uartStruct[UART_MAX];
#define DEBUG_UART_PORT 1

/**
 * @brief Configures a UART device with the port number specified by <b>id</b>
 * based on the basic and extended attributes.
 *
 *
 *
 * @param id Indicates the port number of the UART device.
 * @param param Indicates the pointer to the UART attributes.
 * @return Returns {@link IOT_SUCCESS} if the UART device is configured successfully;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTUartInit(unsigned int id, const IotUartAttribute *param){
    // 检测id
    if(id<1 || id>UART_MAX){
        printf("%s line %d, invalid id 1~%d\n", __func__, __LINE__, UART_MAX);
        return IOT_FAILURE;
    }
    if(param == NULL){
        printf("%s line %d, param is null\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    
    // 打开串口时钟
    LL_ENABLE_UART_CLK(id);
    // 配置引脚为串口模式
    if(LL_CONFIG_UART_PIN(id)==ERROR){
        printf("%s line %d, LL_CONFIG_UART_PIN FAILED id\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    // 设置串口参数 波特率、数据位、停止位、校验位
    g_uartStruct[id-1].luart.BaudRate = param->baudRate;
    g_uartStruct[id-1].luart.DataWidth = param->dataBits;
    g_uartStruct[id-1].luart.StopBits = param->stopBits;
    g_uartStruct[id-1].luart.Parity = param->parity;
    g_uartStruct[id-1].luart.TransferDirection = LL_USART_DIRECTION_TX_RX;
    g_uartStruct[id-1].luart.HardwareFlowControl = LL_USART_HWCONTROL_NONE;
    g_uartStruct[id-1].luart.OverSampling = LL_USART_OVERSAMPLING_16;
    // 初始化串口
    if(LL_USART_Init(g_uartStruct[id-1].UARTx, &g_uartStruct[id-1].luart)==ERROR){
        printf("%s line %d, LL_USART_Init FAILED \n", __func__, __LINE__);
        if(id!=DEBUG_UART_PORT)
            return IOT_FAILURE;
    }
    // 创建队列
    if(QueueCreate(&g_uartStruct[id-1].queue_id, 1, g_uartStruct[id-1].queue_size)!=SUCCESS){
        printf("%s line %d, QueueCreate FAILED \n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    // 设置异步模式
    LL_USART_ConfigAsyncMode(g_uartStruct[id-1].UARTx);
    // 初始化DMA
    LL_UART_DMA_Init(id);
    // 使能串口
    LL_USART_Enable(g_uartStruct[id-1].UARTx);
    return IOT_SUCCESS;
}

/**
 * @brief Reads a specified length of data from a UART device with the port number specified by <b>id</b>.
 *
 *
 *
 * @param id Indicates the port number of the UART device.
 * @param data Indicates the pointer to the start address of the data to read.
 * @param dataLen Indicates the number of bytes to read.
 * @return Returns the number of bytes read if the operation is successful; returns <b>-1</b> otherwise.
 * @since 2.2
 * @version 2.2
 */
int IoTUartRead(unsigned int id, unsigned char *data, unsigned int dataLen){
    // 检测id
    if(id<1 || id>UART_MAX){
        printf("%s line %d, invalid id 1~%d\n", __func__, __LINE__, UART_MAX);
        return IOT_FAILURE;
    }
    if(data == NULL){
        printf("%s line %d, data is null\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    int i;
    for(i=0; i<dataLen; i++){
        char tmp;
        if(QueueOut(g_uartStruct[id-1].queue_id, &tmp)!=SUCCESS){
            return i-1;
        }else{
            data[i] = tmp;
        }
    }
    return dataLen;
}

int IoTUartReadTimeout(unsigned int id, unsigned char *data, unsigned int dataLen, unsigned int tick)
{
    // 检测参数
    if (id > UART_MAX || id < 1)
    {
        printf("%s line %d error : bad uart id, for stm32f407 uart id is 1~6...\n", __func__, __LINE__);
        return IOT_FAILURE;
    }
    if(data == NULL)
    {
        printf("%s line %d error : bad recv buf pointer...\n", __func__, __LINE__);
        return IOT_FAILURE;
    }

    uint8_t tmp_len = 1;
    uint32_t i=0;
    uint64_t start_tick, end_tick;
    start_tick = LL_GetTick();
    // 循环读取，直到超时
    while(i<dataLen)
    {
        char u_data;
        if (QueueOut(g_uartStruct[id-1].queue_id, &u_data) == SUCCESS)
        {
            data[i] = u_data;
            i++;
        }
        end_tick = LL_GetTick();
        if (end_tick - start_tick > tick*1000)
        {
            break;
        }
    }
    return i;
}

/**
 * @brief Writes a specified length of data to a UART device with the port number specified by <b>id</b>.
 *
 *
 *
 * @param id Indicates the port number of the UART device.
 * @param data Indicates the pointer to the start address of the data to write.
 * @param dataLen Indicates the number of bytes to write.
 * @return Returns the number of bytes written if the operation is successful; returns <b>-1</b> otherwise.
 * @since 2.2
 * @version 2.2
 */
int IoTUartWrite(unsigned int id, const unsigned char *data, unsigned int dataLen){
    // 检测id
    if(id<1 || id>UART_MAX){
        printf("%s line %d, invalid id 1~%d\n", __func__, __LINE__, UART_MAX);
        return IOT_FAILURE;
    }
    if(data == NULL){
        printf("%s line %d, data is null\n", __func__, __LINE__);
        return IOT_FAILURE;
    }

    return UartWriteDMA(id, data, dataLen, 5);
}

/**
 * @brief Deinitializes a UART device.
 *
 * @param id Indicates the port number of the UART device.
 * @return Returns {@link IOT_SUCCESS} if the UART device is deinitialized;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTUartDeinit(unsigned int id){
    // 检测id
    if(id<1 || id>UART_MAX){
        printf("%s line %d, invalid id 1~%d\n", __func__, __LINE__, UART_MAX);
        return IOT_FAILURE;
    }
    // 复位gpio
    if(LL_GPIO_DeInit(LL_GET_GPIOX(g_uartStruct[id-1].rx_pin))!=SUCCESS){
        printf("%s line %d, LL_GPIO_DeInit failed\n", __func__, __LINE__, UART_MAX);
        return IOT_FAILURE;
    }
    if(LL_GPIO_DeInit(LL_GET_GPIOX(g_uartStruct[id-1].tx_pin))!=SUCCESS){
        printf("%s line %d, LL_GPIO_DeInit failed\n", __func__, __LINE__, UART_MAX);
        return IOT_FAILURE;
    }
    // 复位串口
    if(LL_USART_DeInit(g_uartStruct[id-1].UARTx)!=SUCCESS){
        printf("%s line %d, LL_USART_DeInit failed\n", __func__, __LINE__, UART_MAX);
        return IOT_FAILURE;
    }
    // 复位dma
    LL_UART_DMA_DeInit(id);
    // 销毁队列
    QueueDestroy(g_uartStruct[id-1].queue_id);
    return IOT_SUCCESS;
}

/**
 * @brief Sets flow control for a UART device with the port number specified by <b>id</b>.
 *
 *
 *
 * @param id Indicates the port number of the UART device.
 * @param flowCtrl Indicates the flow control parameters, as enumerated in {@link IotFlowCtrl}.
 * @return Returns {@link IOT_SUCCESS} if flow control is set successfully;
 * returns {@link IOT_FAILURE} otherwise. For details about other return values, see the chip description.
 * @since 2.2
 * @version 2.2
 */
unsigned int IoTUartSetFlowCtrl(unsigned int id, IotFlowCtrl flowCtrl){
    // 检测id
    if(id<1 || id>UART_MAX){
        printf("%s line %d, invalid id 1~%d\n", __func__, __LINE__, UART_MAX);
        return IOT_FAILURE;
    }
    if(flowCtrl == IOT_FLOW_CTRL_NONE)
    g_uartStruct[id-1].luart.HardwareFlowControl = LL_USART_HWCONTROL_NONE;
    else if(flowCtrl == IOT_FLOW_CTRL_RTS_CTS)
    g_uartStruct[id-1].luart.HardwareFlowControl = LL_USART_HWCONTROL_RTS_CTS;
    else if(flowCtrl == IOT_FLOW_CTRL_RTS_ONLY)
    g_uartStruct[id-1].luart.HardwareFlowControl = LL_USART_HWCONTROL_RTS;
    else if(flowCtrl == IOT_FLOW_CTRL_CTS_ONLY)
    g_uartStruct[id-1].luart.HardwareFlowControl = LL_USART_HWCONTROL_CTS;
    // 初始化串口
    if(LL_USART_Init(g_uartStruct[id-1].UARTx, &g_uartStruct[id-1].luart)==ERROR){
        printf("%s line %d, LL_USART_Init FAILED \n", __func__, __LINE__);
        if(id!=DEBUG_UART_PORT)
            return IOT_FAILURE;
    }
}

