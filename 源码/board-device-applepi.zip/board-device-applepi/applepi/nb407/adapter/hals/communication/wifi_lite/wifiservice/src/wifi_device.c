#include "wifi_device.h"
#include "wifi_hotspot_config.h"
#include "iot_uart.h"
#include "wifi_adapter.h"
#include "string.h"
#include "queue.h"
#include "stdio.h"

#define RSSI_LEVEL_4_2_G (-65)
#define RSSI_LEVEL_3_2_G (-75)
#define RSSI_LEVEL_2_2_G (-82)
#define RSSI_LEVEL_1_2_G (-88)
#define RSSI_LEVEL_4_5_G (-65)
#define RSSI_LEVEL_3_5_G (-72)
#define RSSI_LEVEL_2_5_G (-79)
#define RSSI_LEVEL_1_5_G (-85)

#define CHANNEL_80211B_ONLY 14
#define FREQ_OF_CHANNEL_1 2412
#define FREQ_OF_CHANNEL_80211B_ONLY 2484
#define WIFI_MIN_CHANNEL 1
#define WIFI_FREQ_INTERVAL 5

NetModeType g_wifiMode;
int g_maxNetID = 0;
uint8_t g_scanQueue;
uint8_t g_deviceConfigQueue;
uint8_t g_wifiEventQueue;

extern QueueInfo g_queueInfo[QUEUE_MAX];

// 字符串mac转为6个hex
void mac_str2hex(unsigned char *dst, char *src)
{
    int i;
    char tmp[2];
    for (i = 0; i < 6; i++)
    {
        memcpy(tmp, &src[i * 3], 2);
        for (int j = 0; j < 2; j++)
        {
            // 大写转小写
            if (tmp[j] >= 'A' && tmp[j] <= 'Z')
                tmp[j] = tolower(tmp[j]);
            // 字符转数字
            if (tmp[j] >= '0' && tmp[j] <= '9')
                tmp[j] = tmp[j] - '0';
            else if (tmp[j] >= 'a' && tmp[j] <= 'z')
                tmp[j] = tmp[j] - 87;
        }
        dst[i] = tmp[0] * 16 + tmp[1];
    }
}
// hex数组转为mac字符串
void mac_hex2str(unsigned char *dst, unsigned char *src)
{
    int i;
    for (i = 0; i < 6; i++)
    {
        sprintf(dst + i * 3, "%02x", src[i]);
        if (i != 0)
            dst[i * 3 - 1] = ':';
    }
}
// 字符串ip转为整数
uint32_t ip_to_int(char *ip)
{
    uint32_t result = 0;
    char a[4] = {0};
    char b[4] = {0};
    char c[4] = {0};
    char d[4] = {0};
    int i, l = 0, m = 0, n = 0;
    for (i = 0; i < strlen(ip); i++)
    {
        if (ip[i] == '.')
        {
            if (l == 0)
                l = i;
            else if (m == 0)
                m = i;
            else if (n == 0)
                n = i;
        }
    }
    memcpy(a, ip, l);
    memcpy(b, ip + l + 1, m - l - 1);
    memcpy(c, ip + m + 1, n - m - 1);
    memcpy(d, ip + n + 1, strlen(ip) - n - 1);
    return ((unsigned int)atoi(a) << 24) + ((unsigned int)atoi(b) << 16) + ((unsigned int)atoi(c) << 8) + atoi(d);
}
// 整数ip转为字符串
void int_to_ip(char *ip_str, uint32_t ip_int)
{
    sprintf(ip_str, "%d.%d.%d.%d", (ip_int >> 24) & 0xff, (ip_int >> 16) & 0xff, (ip_int >> 8) & 0xff, (ip_int >> 0) & 0xff);
}

unsigned int ChannelToFrequency(unsigned int channel)
{
    if (channel <= 0)
    {
        return 0;
    }
    if (channel == CHANNEL_80211B_ONLY)
    {
        return FREQ_OF_CHANNEL_80211B_ONLY;
    }
    return (((channel - WIFI_MIN_CHANNEL) * WIFI_FREQ_INTERVAL) + FREQ_OF_CHANNEL_1);
}
unsigned int FrequencyToChannel(unsigned int frequency)
{
    if (frequency == FREQ_OF_CHANNEL_80211B_ONLY)
    {
        return CHANNEL_80211B_ONLY;
    }
    if (frequency < FREQ_OF_CHANNEL_1)
    {
        return 0;
    }
    return (frequency - FREQ_OF_CHANNEL_1) / WIFI_FREQ_INTERVAL + WIFI_MIN_CHANNEL;
}
void ScanCB(WifiErrorCode res)
{
    if (g_wifiEventQueue != 0xff)
    {
        unsigned int size;
        size = g_queueInfo[g_scanQueue].cur_len;
        // 遍历队列
        QUEUE_NODE *tmp;
        // 遍历
        uint16_t i = 0;
        LOS_DL_LIST_FOR_EACH_ENTRY(tmp, &g_queueInfo[g_wifiEventQueue].head, QUEUE_NODE, s_list)
        {
            // 检测函数指针
            if (((WifiEvent *)(tmp->user_data))->OnWifiScanStateChanged == NULL)
                continue;
            if (res == WIFI_SUCCESS)
                ((WifiEvent *)(tmp->user_data))->OnWifiScanStateChanged(WIFI_STATE_AVAILABLE, size);
            else
                ((WifiEvent *)(tmp->user_data))->OnWifiScanStateChanged(WIFI_STATE_NOT_AVAILABLE, 0);
        }
    }
}
void ConnectCB(WifiErrorCode res)
{
    if (g_wifiEventQueue != 0xff)
    {
        WifiLinkedInfo info;
        // 获取连接信息
        if (res == WIFI_SUCCESS)
            GetLinkedInfo(&info);
        // 遍历队列
        QUEUE_NODE *tmp, *node;
        // 遍历
        uint16_t i = 0;
        LOS_DL_LIST_FOR_EACH_ENTRY(tmp, &g_queueInfo[g_wifiEventQueue].head, QUEUE_NODE, s_list)
        {
            // 检测函数指针
            if (((WifiEvent *)(tmp->user_data))->OnWifiConnectionChanged == NULL)
                continue;
            if (res == WIFI_SUCCESS)
                ((WifiEvent *)(tmp->user_data))->OnWifiConnectionChanged(WIFI_STATE_AVAILABLE, &info);
            else
                ((WifiEvent *)(tmp->user_data))->OnWifiConnectionChanged(WIFI_STATE_NOT_AVAILABLE, NULL);
        }
    }
}
void DisConnectCB(WifiErrorCode res)
{
    if (g_wifiEventQueue != 0xff)
    {
        // 遍历队列
        QUEUE_NODE *tmp, *node;
        // 遍历
        uint16_t i = 0;
        LOS_DL_LIST_FOR_EACH_ENTRY(tmp, &g_queueInfo[g_wifiEventQueue].head, QUEUE_NODE, s_list)
        {
            if (((WifiEvent *)(tmp->user_data))->OnWifiConnectionChanged == NULL)
                continue;
            if (res == WIFI_SUCCESS)
                ((WifiEvent *)(tmp->user_data))->OnWifiConnectionChanged(WIFI_STATE_AVAILABLE, NULL);
            else
                ((WifiEvent *)(tmp->user_data))->OnWifiConnectionChanged(WIFI_STATE_NOT_AVAILABLE, NULL);
        }
    }
}
void PrintScanInfo(WifiScanInfo *info)
{
    if(info == NULL)
        return;
    char mac[18]={0};
    mac_hex2str(mac, info->bssid);
    printf("Hotspot : %s,%s,%d,%d,%d\n", info->ssid, mac, info->securityType, info->rssi, info->frequency);
}
/**
 * @brief Enables the station mode.
 *
 * @return Returns {@link WIFI_SUCCESS} if the station mode is enabled; returns an error code defined in
 * {@link WifiErrorCode} otherwise.
 * @since 7
 */

WifiErrorCode EnableWifi(void)
{
    WifiErrorCode res;
#if WIFI_DEBUG
    printf("Enable Wi-Fi ... ");
    //fflush(stdout);
#endif
    // 设置模式1 这是esp8266的station模式
    char mode = 1;
    // 发送指令并等待应答
    res = SendWifiCommand(WIFI_SET_MODE, &mode);
    if (res == WIFI_SUCCESS)
    {
        res = WaitWifiResponse(WIFI_SET_MODE, &g_wifiMode, WIFI_TIMEOUT);
    }
#if WIFI_DEBUG
    PrintWifiError(res);
#endif
    //g_deviceConfigQueue = 0xff;
    return res;
}

/**
 * @brief Disables the station mode.
 *
 * @return Returns {@link WIFI_SUCCESS} if the station mode is disabled; returns an error code defined in
 * {@link WifiErrorCode} otherwise.
 * @since 7
 */
WifiErrorCode DisableWifi(void)
{
#if 0
    SendWifiCommand(ESP8266_LIGHT_SLEEP);
    return WaitWifiResponse(ESP8266_LIGHT_SLEEP);
#endif
#if WIFI_DEBUG
    printf("Disable Wi-Fi SUCCESS...\n");
#endif
    QueueDestroy(g_scanQueue);
    // 8266模块默认情况就是WiFi-OFF，modem-sleep低功耗模式
    return WIFI_SUCCESS;
}

/**
 * @brief Checks whether the station mode is enabled.
 *
 * @return Returns {@link WIFI_STA_ACTIVE} if the station mode is enabled; returns {@link WIFI_STA_NOT_ACTIVE}
 * otherwise.
 * @since 7
 */
int IsWifiActive(void)
{
    if (g_wifiMode == STA)
        return WIFI_STA_ACTIVE;
    return WIFI_STA_NOT_ACTIVE;
}

/**
 * @brief Starts a Wi-Fi scan.
 *
 * @return Returns {@link WIFI_SUCCESS} if the Wi-Fi scan is started; returns an error code defined in
 * {@link WifiErrorCode} otherwise.
 * @since 7
 */
WifiErrorCode Scan(void)
{
    WifiErrorCode res;
#if WIFI_DEBUG
    printf("Scan Wi-Fi ... ");
    //fflush(stdout);
#endif
    // 没有队列，则创建
    if (g_scanQueue == 0xff)
        if (QueueCreate(&g_scanQueue, 100, WIFI_SCAN_HOTSPOT_LIMIT))
            return ERROR_WIFI_UNKNOWN;
        // 扫描前 清空队列
        else
            QueueClear(g_scanQueue);
    // 开始扫描
    res = SendWifiCommand(STA_SCAN_HOTSPOT, NULL);
    if (res == WIFI_SUCCESS)
    {
        res = WaitWifiResponse(STA_SCAN_HOTSPOT, NULL, WIFI_TIMEOUT);
    }
#if WIFI_DEBUG
    PrintWifiError(res);
#endif
    //  执行回调函数
    //ScanCB(res);

    return res;
}

/**
 * @brief Obtains an array of hotspots detected in a Wi-Fi scan.
 *
 * The array of hotspots can be obtained only after the Wi-Fi scan is complete. \n
 *
 * @param result Indicates the array of hotspots detected in a Wi-Fi scan. The array is requested and released by the
 * caller. The value must be greater than or equal to {@link WIFI_SCAN_HOTSPOT_LIMIT}.
 * @param size Indicates the size of the array.
 * @return Returns {@link WIFI_SUCCESS} if the array of hotspots detected in the Wi-Fi scan is obtained; returns an
 * error code defined in {@link WifiErrorCode} otherwise.
 * @since 7
 */
WifiErrorCode GetScanInfoList(WifiScanInfo *result, unsigned int *size)
{
    WifiErrorCode res=WIFI_SUCCESS;
#if WIFI_DEBUG
    printf("Get Scan Info List ...");
    //fflush(stdout);
#endif
    int i;
    // 参数检查
    if (result == NULL)
        res = ERROR_WIFI_INVALID_ARGS;
    else
    {
        // 信息个数
        *size = g_queueInfo[g_scanQueue].cur_len;
        if (*size == 0)
            res = ERROR_WIFI_NOT_AVAILABLE;
        else
        {
            char buf[256];
            // 逐条获取
            for (i = 0; i < (*size); i++)
            {
                memset(buf, 0, 256);
                // 出队
                QueueOut(g_scanQueue, buf);
                // 解析数据
                ParseWifiScanResult(buf, &result[i]);
            }
        }
    }
#if WIFI_DEBUG
    PrintWifiError(res);
#endif
    return res;
}

/**
 * @brief Adds a specified hotspot configuration for connecting to a hotspot.
 *
 * This function generates a <b>networkId</b>. \n
 *
 * @param config Indicates the hotspot configuration to add.
 * @param result Indicates the generated <b>networkId</b>. Each <b>networkId</b> matches a hotspot configuration.
 * @return Returns {@link WIFI_SUCCESS} if the specified hotspot configuration is added; returns an error code defined
 * in {@link WifiErrorCode} otherwise.
 * @since 7
 */
WifiErrorCode AddDeviceConfig(const WifiDeviceConfig *config, int *result)
{
    // 申请队列
    if (g_deviceConfigQueue == 0xff)
    {
        if (QueueCreate(&g_deviceConfigQueue, sizeof(WifiDeviceConfig), WIFI_MAX_CONFIG_SIZE))
        {
            printf("%s line %d error : create queue node failed...\n", __func__, __LINE__);
            return ERROR_WIFI_BUSY;
        }
    }
    QUEUE_NODE *tmp;
    // 申请内存
    tmp = (QUEUE_NODE *)malloc(sizeof(QUEUE_NODE));
    if (tmp == NULL)
    {
        printf("%s line %d error : malloc queue node failed...\n", __func__, __LINE__);
        return ERROR_WIFI_BUSY;
    }
    tmp->user_data = (char *)malloc(sizeof(WifiDeviceConfig));
    if (tmp->user_data == NULL)
    {
        printf("%s line %d error : malloc user data failed...\n", __func__, __LINE__);
        return ERROR_WIFI_BUSY;
    }
    // 超过总长度
    if (g_queueInfo[g_deviceConfigQueue].cur_len >= g_queueInfo[g_deviceConfigQueue].max_len)
    {
        printf("%u %u\n", g_queueInfo[g_deviceConfigQueue].cur_len, g_queueInfo[g_deviceConfigQueue].max_len);
        printf("%s line %d error : queue is full ...\n", __func__, __LINE__);
        return ERROR_WIFI_BUSY;
    }
    // 复制数据
    memcpy(tmp->user_data, config, sizeof(WifiDeviceConfig));
    // 设置netid
    ((WifiDeviceConfig *)(tmp->user_data))->netId = g_maxNetID;
    *result = g_maxNetID;
    g_maxNetID++;
    // 插入节点
    LOS_ListTailInsert(&g_queueInfo[g_deviceConfigQueue].head, &(tmp->s_list));
    // 长度1
    g_queueInfo[g_deviceConfigQueue].cur_len++;
    return WIFI_SUCCESS;
}

/**
 * @brief Obtains all hotspot configurations.
 *
 * Hotspot configurations were added using {@link AddDeviceConfig}. \n
 *
 * @param result Indicates the array of all hotspot configurations. The array is requested and released by the caller.
 * The value must be greater than or equal to {@link WIFI_MAX_CONFIG_SIZE}.
 * @param size Indicates the size of the array.
 * @return Returns {@link WIFI_SUCCESS} if all hotspot configurations are obtained; returns an error code defined in
 * {@link WifiErrorCode} otherwise.
 * @since 7
 */
WifiErrorCode GetDeviceConfigs(WifiDeviceConfig *result, unsigned int *size)
{
    // 检测参数
    if (result == NULL)
    {
        return ERROR_WIFI_INVALID_ARGS;
    }
    // 设置长度
    *size = g_queueInfo[g_deviceConfigQueue].cur_len;
    // 遍历队列
    QUEUE_NODE *tmp;
    // 遍历
    uint16_t i = 0;
    LOS_DL_LIST_FOR_EACH_ENTRY(tmp, &g_queueInfo[g_deviceConfigQueue].head, QUEUE_NODE, s_list)
    {
        memcpy(&result[i++], tmp->user_data, sizeof(WifiDeviceConfig));
    }
    return WIFI_SUCCESS;
}

/**
 * @brief Removes a hotspot configuration matching a specified <b>networkId</b>.
 *
 * @param networkId Indicates the <b>networkId</b> matching the hotspot configuration to remove.
 * @return Returns {@link WIFI_SUCCESS} if the hotspot configuration is removed; returns an error code defined in
 * {@link WifiErrorCode} otherwise.
 * @since 7
 */
WifiErrorCode RemoveDevice(int networkId)
{
    // 遍历队列
    QUEUE_NODE *tmp, *node;
    // 遍历
    LOS_DL_LIST_FOR_EACH_ENTRY(tmp, &g_queueInfo[g_deviceConfigQueue].head, QUEUE_NODE, s_list)
    {
        if (((WifiDeviceConfig *)(tmp->user_data))->netId == networkId)
        {
            // 找到当前节点的前驱
            node = LOS_DL_LIST_ENTRY(tmp->s_list.pstPrev, QUEUE_NODE, s_list);
            // 删除节点
            LOS_ListDelete(&(tmp->s_list));
            // 释放内存
            free(tmp->user_data);
            free(tmp);
            // 由于当前节点被删除，因此tmp要重新赋值，这样tmp->s_list.pstNext才有效
            tmp = node;
            return WIFI_SUCCESS;
        }
    }
    return ERROR_WIFI_INVALID_ARGS;
}

/**
 * @brief Disable a hotspot configuration matching a specified <b>networkId</b>. If the config is disabled, it will
 * not be auto connected.
 *
 * @param networkId Indicates the <b>networkId</b> matching the hotspot configuration to disable.
 * @return Returns {@link WIFI_SUCCESS} if the hotspot configuration is disabled; returns an error code defined in
 * {@link WifiErrorCode} otherwise.
 * @since 7
 */
WifiErrorCode DisableDeviceConfig(int networkId)
{
    // 遍历队列
    QUEUE_NODE *tmp;
    // 遍历
    LOS_DL_LIST_FOR_EACH_ENTRY(tmp, &g_queueInfo[g_deviceConfigQueue].head, QUEUE_NODE, s_list)
    {
        if (((WifiDeviceConfig *)(tmp->user_data))->netId == networkId)
        {
            ((WifiDeviceConfig *)(tmp->user_data))->isHiddenSsid = 1;
            return WIFI_SUCCESS;
        }
    }
    return ERROR_WIFI_INVALID_ARGS;
}

/**
 * @brief Enable a hotspot configuration matching a specified <b>networkId</b>. If the config is enabled, it will
 * be connected automatically when wifi is enabled. When the config is added, it is enabled in default.
 *
 * @param networkId Indicates the <b>networkId</b> matching the hotspot configuration to enable.
 * @return Returns {@link WIFI_SUCCESS} if the hotspot configuration is enabled; returns an error code defined in
 * {@link WifiErrorCode} otherwise.
 * @since 7
 */
WifiErrorCode EnableDeviceConfig(int networkId)
{
    // 遍历队列
    QUEUE_NODE *tmp;
    // 遍历
    LOS_DL_LIST_FOR_EACH_ENTRY(tmp, &g_queueInfo[g_deviceConfigQueue].head, QUEUE_NODE, s_list)
    {
        if (((WifiDeviceConfig *)(tmp->user_data))->netId == networkId)
        {
            ((WifiDeviceConfig *)(tmp->user_data))->isHiddenSsid = 0;
            return WIFI_SUCCESS;
        }
    }
    return ERROR_WIFI_INVALID_ARGS;
}

/**
 * @brief Connects to a hotspot matching a specified <b>networkId</b>.
 *
 * Before calling this function, call {@link AddDeviceConfig} to add a hotspot configuration. \n
 *
 * @param networkId Indicates the <b>networkId</b> matching the target hotspot.
 * @return Returns {@link WIFI_SUCCESS} if the hotspot is connected; returns an error code defined in
 * {@link WifiErrorCode} otherwise.
 * @since 7
 */
WifiErrorCode ConnectTo(int networkId)
{
    WifiErrorCode res = ERROR_WIFI_INVALID_ARGS;
    QUEUE_NODE *tmp;
    // 遍历
    uint16_t i = 0;
    LOS_DL_LIST_FOR_EACH_ENTRY(tmp, &g_queueInfo[g_deviceConfigQueue].head, QUEUE_NODE, s_list)
    {
		// 从配置列表中找到匹配的netid
        if (((WifiDeviceConfig *)(tmp->user_data))->netId == networkId)
        {
            res = ConnectToDevice((WifiDeviceConfig *)(tmp->user_data));
			break;
        }
    }
    return res;
}
WifiErrorCode ConnectToAP(const char *ssid, const char *passwd)
{
    WifiErrorCode res;
    WifiDeviceConfig config;
    memset(config.ssid, 0, WIFI_MAX_SSID_LEN);
    memset(config.preSharedKey, 0, WIFI_MAX_KEY_LEN);
    memcpy(config.ssid, ssid, strlen(ssid));
    memcpy(config.preSharedKey, passwd, strlen(passwd));
    
    int net_id;
    res = AddDeviceConfig(&config, &net_id);
    if(res != WIFI_SUCCESS)
    {
        printf("%s line %d rror : Add Wi-Fi Device config error...\n", __func__, __LINE__);
        return res;
    }
    //LL_mDelay(3000);
    return ConnectTo(net_id);
}
/**
 * @brief Connect to a hotspot by config.
 *
 * @param config is device configuration to connect the Wi-Fi network.
 * @return Returns {@link WIFI_SUCCESS} if the hotspot is connected; returns an error code defined in
 * {@link WifiErrorCode} otherwise.
 * @since 7
 */
WifiErrorCode ConnectToDevice(const WifiDeviceConfig *config)
{
    WifiErrorCode res;
#if WIFI_DEBUG
    printf("Connect to hosspot ... ");
    //fflush(stdout);
#endif
    // 发送
    res = SendWifiCommand(STA_JOIN_HOTSPOT, config);
    if (res == WIFI_SUCCESS)
    {
        res = WaitWifiResponse(STA_JOIN_HOTSPOT, NULL, WIFI_TIMEOUT);
    }
#if WIFI_DEBUG
    PrintWifiError(res);
#endif
    // 执行回调函数
    //ConnectCB(res);

    return res;
}

/**
 * @brief Disconnects this Wi-Fi connection.
 *
 * @return Returns {@link WIFI_SUCCESS} if this Wi-Fi connection is disconnected; returns an error code defined
 * in {@link WifiErrorCode} otherwise.
 * @since 7
 */
WifiErrorCode Disconnect(void)
{
    WifiErrorCode res;
#if WIFI_DEBUG
    printf("DisConnect to Hotspot ... ");
#endif
    // 发送指令并等待结果
    res = SendWifiCommand(STA_EXIT_HOTSPOT, NULL);
    if (res == WIFI_SUCCESS)
    {
        res = WaitWifiResponse(STA_EXIT_HOTSPOT, NULL, WIFI_TIMEOUT);
    }
#if WIFI_DEBUG
    PrintWifiError(res);
#endif
    DisConnectCB(res);

    return res;
}

/**
 * @brief Obtains information about the connected hotspot.
 *
 * @param result Indicates the information about the connected hotspot.
 * @return Returns {@link WIFI_SUCCESS} if the information about the connected hotspot is obtained; returns an error
 * code defined in {@link WifiErrorCode} otherwise.
 * @since 7
 */
WifiErrorCode GetLinkedInfo(WifiLinkedInfo *result)
{
    WifiErrorCode res;
    WifiLinkedInfo linked_info;
    char tmp[100] = {0};

    // 参数不能为空
    if (result == NULL)
        return ERROR_WIFI_INVALID_ARGS;
    // 当前这几个值无法获取
    result->connState = WIFI_CONNECTED;
    result->disconnectedReason = 0;
    result->frequency = 0;
    result->band = 0;
    // 发送指令并等待结果
    SendWifiCommand(STA_CURRENT_HOTSPOT, NULL);
    res = WaitWifiResponse(STA_CURRENT_HOTSPOT, result, WIFI_TIMEOUT);
    if (res == WIFI_SUCCESS)
    {
        // 继续获取IP
        IpInfo info;
        res = GetIpInfo(&info);
        if (res == WIFI_SUCCESS)
        {
            result->ipAddress = info.ipAddress;
        }
    }

    return res;
}

/**
 * @brief Obtains the MAC address of this device.
 *
 * @param result Indicates the MAC address of this device. It is a char array whose length is 6.
 * @return Returns {@link WIFI_SUCCESS} if the MAC address of this device is obtained; returns an error code defined
 * in {@link WifiErrorCode} otherwise.
 * @since 7
 */
WifiErrorCode GetDeviceMacAddress(unsigned char *result)
{
    WifiErrorCode res;

    // 判断参数
    if (result == NULL)
        return ERROR_WIFI_INVALID_ARGS;
    // 发送指令，并等待结果
    res = SendWifiCommand(STA_GET_MAC, NULL);
    if (res == WIFI_SUCCESS)
    {
        res = WaitWifiResponse(STA_GET_MAC, result, WIFI_TIMEOUT);
    }
    return res;
}

/**
 * @brief Starts a Wi-Fi scan based on a specified parameter.
 *
 * Only results matching the specified parameter will be returned for the Wi-Fi scan.\n
 *
 * @param params Indicates the pointer to the parameter for starting the Wi-Fi scan.
 * For details, see {@link WifiScanParams}.
 * @return Returns {@link WIFI_SUCCESS} if the Wi-Fi scan is started successfully;
 * returns an error code defined in {@link WifiErrorCode} otherwise.
 * @since 7
 */
WifiErrorCode AdvanceScan(WifiScanParams *params)
{
    WifiErrorCode res;
    // 参数不能为空
    if (params == NULL)
        return ERROR_WIFI_INVALID_ARGS;
    // 没有队列，则创建
    if (g_scanQueue == 0xff)
        if (QueueCreate(&g_scanQueue, sizeof(WifiScanInfo), WIFI_SCAN_HOTSPOT_LIMIT))
            return ERROR_WIFI_UNKNOWN;
        // 扫描前 清空队列
        else
            QueueClear(g_scanQueue);
    WifiUnlock();
    // 开始扫描,并等待结果
    res = SendWifiCommand(STA_SCAN_HOTSPOT_CUSTOM, params);
    if (res == WIFI_SUCCESS)
        res = WaitWifiResponse(STA_SCAN_HOTSPOT_CUSTOM, NULL, WIFI_TIMEOUT);
    WifiUnlock();
    ScanCB(res);
    return res;
}

/*
 * @brief get the ip address.
 *
 * @return Returns {@link WIFI_SUCCESS} if the IP is got; returns an error code defined
 * in {@link WifiErrorCode} otherwise.
 * @since 7
 */
WifiErrorCode GetIpInfo(IpInfo *info)
{
    WifiErrorCode res;

    if (info == NULL)
    {
        return ERROR_WIFI_INVALID_ARGS;
    }
    res = SendWifiCommand(STA_GET_IP, NULL);
    if (res == WIFI_SUCCESS)
    {
        res = WaitWifiResponse(STA_GET_IP, (char *)info, WIFI_TIMEOUT);
    }
    return res;
}

/**
 * @brief Obtains the signal level indicated by a specified received signal strength indicator (RSSI) and frequency
 * band.
 *
 *
 * Based on the signal level, you can display the signal strength represented by the number of signal bars. \n
 *
 * @param rssi Indicates the RSSI.
 * @param band Indicates the frequency band, either {@link HOTSPOT_BAND_TYPE_5G} or {@link HOTSPOT_BAND_TYPE_2G}.
 * @return Returns the signal level if it is obtained; returns <b>-1</b> otherwise.
 * @since 7
 */
int GetSignalLevel(int rssi, int band)
{
    if (band == HOTSPOT_BAND_TYPE_2G)
    {
        if (rssi >= RSSI_LEVEL_4_2_G)
            return RSSI_LEVEL_4;
        if (rssi >= RSSI_LEVEL_3_2_G)
            return RSSI_LEVEL_3;
        if (rssi >= RSSI_LEVEL_2_2_G)
            return RSSI_LEVEL_2;
        if (rssi >= RSSI_LEVEL_1_2_G)
            return RSSI_LEVEL_1;
    }

    if (band == HOTSPOT_BAND_TYPE_5G)
    {
        if (rssi >= RSSI_LEVEL_4_5_G)
            return RSSI_LEVEL_4;
        if (rssi >= RSSI_LEVEL_3_5_G)
            return RSSI_LEVEL_3;
        if (rssi >= RSSI_LEVEL_2_5_G)
            return RSSI_LEVEL_2;
        if (rssi >= RSSI_LEVEL_1_5_G)
            return RSSI_LEVEL_1;
    }
    return ERROR_WIFI_INVALID_ARGS;
}

/**
 * @brief Registers a callback for a specified Wi-Fi event.
 *
 * The registered callback will be invoked when the Wi-Fi event defined in {@link WifiEvent} occurs. \n
 *
 * @param event Indicates the event for which the callback is to be registered.
 * @return Returns {@link WIFI_SUCCESS} if the callback is registered successfully; returns an error code defined
 * in {@link WifiErrorCode} otherwise.
 * @since 7
 */
WifiErrorCode RegisterWifiEvent(WifiEvent *event)
{
    WifiErrorCode res=WIFI_SUCCESS;
#if WIFI_DEBUG
    printf("Register Wi-Fi Event ... ");
    //fflush(stdout);
#endif
    // 检测参数
    if (event == NULL)
        res = ERROR_WIFI_INVALID_ARGS;
    else
    {
        // 是否需要创建队列
        if (g_wifiEventQueue == 0xff){
            if (QueueCreate(&g_wifiEventQueue, sizeof(WifiEvent), WIFI_MAX_EVENT_SIZE))
                res = ERROR_WIFI_UNKNOWN;
        }
        else
        {
            // 是否可插入
            if (g_queueInfo[g_wifiEventQueue].cur_len < WIFI_MAX_EVENT_SIZE)
                QueueIn(g_wifiEventQueue, (char *)event);
            else
                res = ERROR_WIFI_NOT_AVAILABLE;
        }    
    }
#if WIFI_DEBUG
    PrintWifiError(res);
#endif
    return res;
}

/**
 * @brief Unregisters a callback previously registered for a specified Wi-Fi event.
 *
 * @param event Indicates the event for which the callback is to be unregistered.
 * @return Returns {@link WIFI_SUCCESS} if the callback is unregistered successfully; returns an error code defined
 * in {@link WifiErrorCode} otherwise.
 * @since 7
 */
WifiErrorCode UnRegisterWifiEvent(const WifiEvent *event)
{
    // 检测参数
    if (event == NULL)
        return ERROR_WIFI_INVALID_ARGS;
    // 取消event
    if (g_wifiEventQueue == 0xff)
        return ERROR_WIFI_INVALID_ARGS;
    // 遍历队列
    QUEUE_NODE *tmp, *node;
    // 遍历
    uint16_t i = 0;
    LOS_DL_LIST_FOR_EACH_ENTRY(tmp, &g_queueInfo[g_wifiEventQueue].head, QUEUE_NODE, s_list)
    {
        if (((uint32_t *)(tmp->user_data)) == event)
        {
            // 找到当前节点的前驱
            node = LOS_DL_LIST_ENTRY(tmp->s_list.pstPrev, QUEUE_NODE, s_list);
            // 删除节点
            LOS_ListDelete(&(tmp->s_list));
            // 释放内存
            free(tmp->user_data);
            free(tmp);
            // 由于当前节点被删除，因此tmp要重新赋值，这样tmp->s_list.pstNext才有效
            tmp = node;
            return WIFI_SUCCESS;
        }
    }
    // 没找到节点，返回错误
    return ERROR_WIFI_INVALID_ARGS;
}