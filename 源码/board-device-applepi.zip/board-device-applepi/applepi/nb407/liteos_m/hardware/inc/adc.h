#ifndef __ADC_H
#define __ADC_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f4xx_ll_adc.h"
#include "stm32f4xx_ll_bus.h"
#include "stm32f4xx_ll_system.h"
#include "stm32f4xx_ll_gpio.h"
#include "stm32f4xx_ll_rcc.h"
#include "stdint.h"
#include "stdio.h"

void MX_ADC1_Init(void);
float get_voltage(uint8_t channel);

#ifdef __cplusplus
}
#endif

#endif