/*******************************************************************************
 * Copyright (c) 2014 IBM Corp.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * and Eclipse Distribution License v1.0 which accompany this distribution.
 *
 * The Eclipse Public License is available at
 *    http://www.eclipse.org/legal/epl-v10.html
 * and the Eclipse Distribution License is available at
 *   http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * Contributors:
 *    Ian Craggs - initial API and implementation and/or initial documentation
 *    Sergio R. Caprile - clarifications and/or documentation extension
 *******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "MQTTPacket.h"
#include "transport.h"
#include "car.h"

/* This is in order to get an asynchronous signal to stop the sample,
as the code loops waiting for msgs on the subscribed topic.
Your actual code will depend on your hw and approach*/
#include <signal.h>
#include "cJSON.h"

int toStop = 0;
void cfinish(int sig)
{
    signal(SIGINT, NULL);
    toStop = 1;
}
void stop_init(void)
{
    signal(SIGINT, cfinish);
    signal(SIGTERM, cfinish);
}
/* */
int mysock = 0;
int mqtt_connect(char *host, int port)
{
    MQTTPacket_connectData data = MQTTPacket_connectData_initializer;
    int rc = 0;
    unsigned char buf[200];
    int buflen = sizeof(buf);
    int len = 0;
    // 打开指定的服务器端口
    mysock = transport_open(host, port);
    if (mysock < 0)
        return mysock;

    printf("Sending to hostname %s port %d\n", host, port);

    data.clientID.cstring = "WJ11";           // 设置clientid
    data.keepAliveInterval = 120;            // 设置心跳时间20s
    data.cleansession = 1;                  // 清除会话
    data.username.cstring = "testuser";     // 用户名
    data.password.cstring = "testpassword"; // 密码

    // 将data结构序列化，转为字符串
    len = MQTTSerialize_connect(buf, buflen, &data);
    // 发送data数据
    rc = transport_sendPacketBuffer(mysock, buf, len);

    /* 等待服务器应答 */
    if (MQTTPacket_read(buf, buflen, transport_getdata) == CONNACK)
    {
        unsigned char sessionPresent, connack_rc;
        // 判断应答状态
        if (MQTTDeserialize_connack(&sessionPresent, &connack_rc, buf, buflen) != 1 || connack_rc != 0)
        {
            // 没有收到正确的应答，原因需要根据错误码判断
            printf("Unable to connect, return code %d\n", connack_rc);
            transport_close(mysock);
            return -1;
        }
    }
    else
    {
        // 没有任何应答数据，可能是网络不通
        transport_close(mysock);
        printf("Unable to connect, no net\n");
        return -2;
    }
    // 连接成功
    printf("mqtt connect ok\n");
    return 0;
}

int mqtt_subscribe(char *sub_topic)
{
    int rc = 0;
    int mysock = 0;
    unsigned char buf[200];
    int buflen = sizeof(buf);
    int msgid = 1;
    MQTTString topicString = MQTTString_initializer;
    int req_qos = 0;
    int len = 0;
    /* subscribe */
    topicString.cstring = sub_topic;
    // 序列化主题，转为字符串
    len = MQTTSerialize_subscribe(buf, buflen, 0, msgid, 1, &topicString, &req_qos);
    // 发送主题
    rc = transport_sendPacketBuffer(mysock, buf, len);
    // 判断应答
    if (MQTTPacket_read(buf, buflen, transport_getdata) == SUBACK) /* wait for suback */
    {
        unsigned short submsgid;
        int subcount;
        int granted_qos;

        rc = MQTTDeserialize_suback(&submsgid, 1, &subcount, &granted_qos, buf, buflen);
        // 判断信息质量
        if (granted_qos != 0)
        {
            printf("granted qos != 0, %d\n", granted_qos);
            transport_close(mysock);
            return -1;
        }
    }
    else
    {
        printf("sub topic failed, no net\n");
        transport_close(mysock);
        return -2;
    }
    printf("sub topic %s ok\n", sub_topic);
    return 0;
}

unsigned char *mqtt_getdata(int *payloadlen_in)
{
    int rc = 0;
    unsigned char buf[200];
    int buflen = sizeof(buf);
    int len = 0;
    // 读数据
    if (MQTTPacket_read(buf, buflen, transport_getdata) == PUBLISH)
    {
        unsigned char dup;
        int qos;
        unsigned char retained;
        unsigned short msgid;
        // int payloadlen_in;
        unsigned char *payload_in;
        int rc;
        MQTTString receivedTopic;

        rc = MQTTDeserialize_publish(&dup, &qos, &retained, &msgid, &receivedTopic,
                                     &payload_in, payloadlen_in, buf, buflen);
        printf("message arrived %.*s\n", *payloadlen_in, payload_in);
        // payload_in存放收到的数据，payloadlen_in数据的长度
        unsigned char *tmp;
        tmp = (unsigned char *)malloc(*payloadlen_in);//申请内存
        if(tmp != NULL){
            memcpy(tmp, payload_in, *payloadlen_in);//保存数据
            return tmp;
        }
    }
    return NULL;
}
/* 
{
    "led_r":"on","led_g":"on","led_b":"off",
    "relay":"on",
    "motor_state":"forward","motor_speed":90,
    "th":25, "rh":67
}
*/
// 用cJSON库解析以上json数据
extern CAR_DATA car_data;
void mqtt_parsedata(unsigned char *payload_in, int payloadlen_in)
{
    // 复制数据到tmp
    char *tmp = (char *)malloc(payloadlen_in);
    memcpy(tmp, payload_in, payloadlen_in);
    // 将字符串转为json数据
    cJSON *root = cJSON_Parse((char *)tmp);
    // 逐条提取数据
    cJSON *led_r = cJSON_GetObjectItem(root, "led_r");// "led_r":"on"
    cJSON *led_g = cJSON_GetObjectItem(root, "led_g");// "led_g":"off"
    cJSON *led_b = cJSON_GetObjectItem(root, "led_b");
    cJSON *motor_state = cJSON_GetObjectItem(root, "motor_state");
    cJSON *motor_speed = cJSON_GetObjectItem(root, "motor_speed");
    // 提取item的值
    if(led_r != NULL)
    {
        if(strcmp(led_r->valuestring, "on") == 0)
        {   
            // 处理led_r
            led_on(LED_RED);
            car_data.led_red = 1;
        }
        else if(strcmp(led_r->valuestring, "off") == 0)
        {
            led_off(LED_RED);
            car_data.led_red = 0;
        }
    }
    if(led_g != NULL)
    {
        if(strcmp(led_g->valuestring, "on") == 0)
        {   
            led_on(LED_GREEN);
            car_data.led_green = 1;
        }
        else if(strcmp(led_g->valuestring, "off") == 0)
        {
            led_off(LED_GREEN);
            car_data.led_green = 0;
        }
    }
    if(led_b != NULL)
    {
        printf("led_b ...\n");
        if(strcmp(led_b->valuestring, "on") == 0)
        {   
            // 处理led_r
            led_on(LED_BLUE);
            car_data.led_blue = 1;
        }
        else if(strcmp(led_b->valuestring, "off") == 0)
        {
            printf("led_b off\n");
            led_off(LED_BLUE);
            car_data.led_blue = 0;
        }
    }
    if(motor_state != NULL)
    {
        printf("motor_state parae %s %d\n", motor_state->valuestring, motor_speed->valueint);
        if(strcmp(motor_state->valuestring, "forward") == 0)
        {   
            motor_ctl(MOTOR_FORWARD, motor_speed->valueint);
            car_data.motor_state = MOTOR_FORWARD;
        }
        else if(strcmp(motor_state->valuestring, "backward") == 0)
        {
            motor_ctl(MOTOR_BACKWARD, motor_speed->valueint);
            car_data.motor_state = MOTOR_BACKWARD;
        }
        else if(strcmp(motor_state->valuestring, "stop") == 0)
        {
            motor_ctl(MOTOR_PAUSE, motor_speed->valueint);
            car_data.motor_state = MOTOR_PAUSE;
        }
        else if(strcmp(motor_state->valuestring, "standby") == 0)
        {
            motor_ctl(MOTOR_STANDBY, motor_speed->valueint);
            car_data.motor_state = MOTOR_STANDBY;
        }
        car_data.motor_speed = motor_speed->valueint;
    }
    cJSON_Delete(root);
    free(tmp);
}
int mqtt_publish(char *pub_topic, CAR_DATA data)
{
    MQTTString topicString = MQTTString_initializer;
    char buf[200];
    int buflen = sizeof(buf);
    int len = 0;
    int rc = 0;
    topicString.cstring = pub_topic;
    // 将car_data数据转为json字符串
    // 创建CJSON对象
    cJSON *root = cJSON_CreateObject();
    // 添加数据到CJSON对象
    char led_state[2][4] = {"off","on"};
    cJSON_AddStringToObject(root, "led_r", led_state[data.led_red]);
    cJSON_AddStringToObject(root, "led_g", led_state[data.led_green]);
    cJSON_AddStringToObject(root, "led_b", led_state[data.led_blue]);
    char state[4][10] = {"forward", "backward", "stop", "standby"};
    cJSON_AddStringToObject(root, "motor_state", state[data.motor_state-1]);
    cJSON_AddNumberToObject(root, "motor_speed", data.motor_speed);
    data.vol = get_voltage();
    cJSON_AddNumberToObject(root, "vol", data.vol);
    // 序列化json数据
    char *payload = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    // 发送payload
	len = MQTTSerialize_publish(buf, buflen, 0, 1, 0, 0, topicString,
								(unsigned char *)payload, strlen(payload));
	free(payload);
    rc = transport_sendPacketBuffer(mysock, buf, len);
	// 判断是否发送成功
	if(MQTTPacket_read(buf, buflen, transport_getdata)==PUBACK){
		printf("mqtt pushlish ok\n");
		rc = 0;
	}else{
		printf("mqtt pushlish failed\n");
		rc = -1;
	}
}

int mqtt_jump()
{
    // 发送心跳包
	int rc = 0;
	unsigned char buf[200];
	int buflen = sizeof(buf);
	
	int len = MQTTSerialize_pingreq(buf, buflen);//发送心跳
	rc = transport_sendPacketBuffer(mysock, buf, len);//发送
	if (MQTTPacket_read(buf, buflen, transport_getdata) == PINGRESP){
		printf("mqtt ping packet ok\n");
		rc = 0;
	}else{
		printf("mqtt ping packet failed\n");
		rc = -1;
	}
	return rc;
}
