#ifndef _PUB0SUB1_H
#define _PUB0SUB1_H

#include "MQTTPacket.h"
#include "transport.h"
#include "home.h"


int mqtt_connect(char *host, int port);
int mqtt_subscribe(char *sub_topic);
unsigned char *mqtt_getdata(int *payloadlen_in);
void mqtt_parsedata(unsigned char *payload_in, int payloadlen_in);
int mqtt_publish(char *pub_topic, HOME_DATA data);
void mqtt_jump();

#endif