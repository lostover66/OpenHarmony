// device/board/applepi/stm32f407_atk/liteos_m/queue/inc/queue.h
#ifndef _QUEUE_H
#define _QUEUE_H

#include "los_list.h"
#include "stdlib.h"
#include "string.h"

//#define SUCCESS     0
#define FAILED      -1
#define QUEUE_MAX   32

// 队列节点
typedef struct{
	LOS_DL_LIST s_list;
	char *user_data;
}QUEUE_NODE;

// 系统维护的队列信息
typedef struct{
    short id;
    unsigned short item_size;
    unsigned int max_len;
    unsigned int cur_len;
	LOS_DL_LIST head;
}QueueInfo;

void QueueInit();
char QueueCreate(unsigned char *id, unsigned short item_size, unsigned int len);
char QueueIn(unsigned char id, char *data);
char QueueOut(unsigned char id, char *data);
char QueueClear(unsigned char id);
char QueueDestroy(unsigned char id);



#endif /* _QUEUE_H */
