#include "main.h"
#include "ohos_types.h"
#include "ohos_init.h"
#include "los_compiler.h"
#include "los_task.h"
#include "rcc.h"

void HardFault_Handler(void);
void MemManage_Handler(void);
void BusFault_Handler(void);
void UsageFault_Handler(void);
void ExceptionInit()
{
    /**************参考CORTEX-M3权威手册 ************/
    // 复制HardFault_Handler
    uint32_t *vectors = (uint32_t *)(0x20000000 + 8);
    *vectors = (uint32_t)HardFault_Handler;

    // 重定向 向量表
    SCB->VTOR = 0x20000000 | (0 & (uint32_t)0x1FFFFF80);

    NVIC_SetVector(MemoryManagement_IRQn, (uint32_t)MemManage_Handler);
    // 配置MemManage Fault 中断优先级，实际上配置的是SCB->SHP 寄存器
    NVIC_SetPriority(MemoryManagement_IRQn, 0);
    // 使能MemManage Fault 中断或异常, 实际上设置SCB->SHCSR 的bit 16 为 1
    SCB->SHCSR |= SCB_SHCSR_MEMFAULTENA_Msk;

    NVIC_SetVector(BusFault_IRQn, (uint32_t)BusFault_Handler);
    // 配置Bus Fault 中断优先级，实际上配置的是SCB->SHP 寄存器
    NVIC_SetPriority(BusFault_IRQn, 0);
    // 使能Bus Fault 中断或异常, 实际上设置SCB->SHCSR 的bit 17 为 1
    SCB->SHCSR |= SCB_SHCSR_BUSFAULTENA_Msk;

    NVIC_SetVector(UsageFault_IRQn, (uint32_t)UsageFault_Handler);
    // 配置Usage fault 中断优先级，实际上配置的是SCB->SHP 寄存器
    NVIC_SetPriority(UsageFault_IRQn, 0);
    // 使能Usage fault 中断或异常, 实际上设置SCB->SHCSR 的bit 18 为 1
    SCB->SHCSR |= SCB_SHCSR_USGFAULTENA_Msk;
}

int main(){
    ExceptionInit();
    // 初始化时钟
    LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_SYSCFG);
    LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_PWR);
    LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOH);
    NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_4);
    NVIC_SetPriority(SysTick_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),15, 0));
    SystemClock_Config();
    // 初始化延时
    delay_init();
    QueueInit();
    // 初始化串口
    MX_USART1_UART_Init();

    uint32_t ret;
    ret = LOS_KernelInit();
    if(ret == LOS_OK){
        // 打开看门狗功能
        IoTWatchDogEnable();
        printf("I'm weijie, liteos_m is starting\n");
        // 初始化tick
        LL_Tick_Init();
        // 启动网络任务
        net_task();
        // 启动car核心业务
        car_task();
        LOS_Start();  // 启动系统，死循环
        // 不执行
    }
}