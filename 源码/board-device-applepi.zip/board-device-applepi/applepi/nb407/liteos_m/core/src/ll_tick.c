// 4.1.1/device/board/applepi/stm32f407_atk/liteos_m/core/src/ll_tick.c
#include "stm32f4xx.h"
#include "stm32f407xx.h"
#include "stm32f4xx_ll_cortex.h"
#include "stm32f4xx_ll_utils.h"
#include "stm32f4xx_ll_bus.h"
#include "stm32f4xx_ll_tim.h"
#include "stdio.h"

volatile uint64_t g_ll_tick=0;

void LL_Tick_Handler()
{
    /* 检查更新中断标志并清除 */
    if (LL_TIM_IsActiveFlag_UPDATE(TIM7))
    {
        LL_TIM_ClearFlag_UPDATE(TIM7);   // 必须清除，否则中断反复触发
        /* 1ms 到达，在此处执行你的任务 */
        g_ll_tick++;
        if(g_ll_tick%5000 == 0){
            IoTWatchDogKick();//5s喂狗
            //printf("dog kick\n");
        }
    }
}

uint64_t LL_GetTick()
{
    return g_ll_tick;
}

void LL_Tick_Init()
{   
    LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM7);

    /* 2. 配置时基单元 */
    // 目标：1ms 周期。计数时钟 84MHz
    // 公式：周期 = (PSC+1) * (ARR+1) / 84MHz
    // 取 PSC=83 (分频84)，则计数频率 1MHz，即 1us 计一次
    // 取 ARR=999，则 1000 次计数 = 1ms
    LL_TIM_SetPrescaler(TIM7, 83);       // 预分频：84MHz / (83+1) = 1MHz
    LL_TIM_SetAutoReload(TIM7, 999);     // 重装载：1000 * 1us = 1ms
    LL_TIM_SetCounterMode(TIM7, LL_TIM_COUNTERMODE_UP); // 向上计数
    /* 3. 使能更新中断 */
    LL_TIM_EnableIT_UPDATE(TIM7);
    /* 4. 配置 NVIC 中断优先级 */
    NVIC_SetVector(TIM7_IRQn, LL_Tick_Handler);
    NVIC_SetPriority(TIM7_IRQn, 15);
    NVIC_EnableIRQ(TIM7_IRQn);
    /* 5. 启动计数器 */
    LL_TIM_EnableCounter(TIM7);
}

// 由于没有使用hal库中的HAL_InitTick相关函数，这里需要重写HAL_IncTick HAL_GetTick
// 这两个函数和HAL_Delay息息相关，同时很多hal库代码中用到了这两个函数
void HAL_IncTick(void)
{
    g_ll_tick++;
}

uint32_t HAL_GetTick(void)
{
    return g_ll_tick;
}
