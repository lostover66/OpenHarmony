// device/board/applepi/stm32f407_atk/liteos_m/core/src/delay.c
#include "delay.h"
#include "stm32f4xx_ll_tim.h"
#include "stm32f4xx_ll_bus.h"
void delay_init(void)
{
    LL_TIM_InitTypeDef TIM_InitStruct = {0};
    LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM6);
    TIM_InitStruct.Prescaler = 0;
    TIM_InitStruct.CounterMode = LL_TIM_COUNTERMODE_UP;
    TIM_InitStruct.Autoreload = 84;
    LL_TIM_Init(TIM6, &TIM_InitStruct);
    LL_TIM_DisableARRPreload(TIM6);
    LL_TIM_SetTriggerOutput(TIM6, LL_TIM_TRGO_RESET);
    LL_TIM_DisableMasterSlaveMode(TIM6);
}

void delay_ms(unsigned int nms)
{
    delay_us(nms*1000);
}
void delay_us(unsigned int nus)
{
    LL_TIM_EnableCounter(TIM6);
    while(nus)
    {
        if(LL_TIM_IsActiveFlag_UPDATE(TIM6))
        {
            LL_TIM_ClearFlag_UPDATE(TIM6);
            nus--;
        }
    }
    LL_TIM_DisableCounter(TIM6);
}
