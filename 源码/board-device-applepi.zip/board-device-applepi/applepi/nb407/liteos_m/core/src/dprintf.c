// 4.1.1/device/board/applepi/stm32f407_atk/liteos_m/core/src/dprintf.c
#include <stdarg.h>
#include "stdio.h"
#include "los_debug.h"
#include "los_interrupt.h"
#include "usart.h"

int32_t UartPutc(int32_t ch, void *file){
    while((USART1->SR & 0x40)==0);
    USART1->DR = ch;
    return 1;
}

static void dputs(char const *s, int (*pFputc)(int n, FILE *cookie), void *cookie)
{
    unsigned int intSave;

    intSave = LOS_IntLock();
    while (*s) {
        pFputc(*s++, cookie);
    }
    LOS_IntRestore(intSave);
}

int printf(char const  *fmt, ...)
{
    char buf[1024] = { 0 };
    va_list ap;
    va_start(ap, fmt);
    int len = vsnprintf_s(buf, sizeof(buf), 1024 - 1, fmt, ap);
    if (len > 0) {
        dputs(buf, UartPutc, 0);
    } else {
        dputs("printf error!\n", UartPutc, 0);
    }
    va_end(ap);
    return len;
}
