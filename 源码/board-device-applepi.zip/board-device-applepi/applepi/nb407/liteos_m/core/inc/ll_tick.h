#ifndef __LL_TICK_H
#define __LL_TICK_H

#ifdef __cplusplus
extern "C" {
#endif

void LL_Tick_Init();
uint64_t LL_GetTick();

#ifdef __cplusplus
}
#endif

#endif