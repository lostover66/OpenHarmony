#ifndef __RCC_H
#define __RCC_H

#ifdef __cplusplus
extern "C" {
#endif

void SystemClock_Config(void);

#ifdef __cplusplus
}
#endif

#endif
