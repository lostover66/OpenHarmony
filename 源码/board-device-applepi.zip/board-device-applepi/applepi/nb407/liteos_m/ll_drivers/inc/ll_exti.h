#ifndef __LL_EXTI_H
#define __LL_EXTI_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
#include "stm32f4xx_ll_exti.h"
#include "stm32f4xx_ll_system.h"
#include "ll_gpio.h"

uint32_t LL_SETUP_EXTI(uint16_t id, LL_EXTI_InitTypeDef cfg, LL_EXTI_HANDLER handler);

#ifdef __cplusplus
}
#endif

#endif