#ifndef __LL_PWM_H
#define __LL_PWM_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
#include "stm32f4xx_ll_tim.h"
// TIMx  CHx  clk realpin params(freq\load\ocval)
#define PWM_MAX 31
typedef struct{
    TIM_TypeDef *TIMx;
    uint32_t ch;
    uint16_t realPin;
}PWM_ST;

TIM_TypeDef *LL_GET_TIMx(uint16_t id);
uint32_t LL_GET_TIM_CH(uint16_t id);
void LL_ENABLE_TIM_CLK(uint16_t id);
uint8_t LL_CONFIG_TIM_PIN(uint16_t id);
uint8_t LL_CAL_TIM_PARAMS(uint32_t rcc, uint8_t duty, uint32_t freq, \
    uint16_t *pre_div, uint32_t *auto_reload, uint32_t *oc_val);

#ifdef __cplusplus
}
#endif

#endif