#ifndef __LL_I2C_H
#define __LL_I2C_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
#include "ll_gpio.h"
#include "stm32f4xx_ll_i2c.h"

#define I2C1_SCL    PB6
#define I2C1_SDA    PB7
#define I2C2_SCL    PB10
#define I2C2_SDA    PB11
#define I2C3_SCL    PA8
#define I2C3_SDA    PC9

#define I2C_MAX     3
#define I2C_TIMEOUT 10

typedef struct{
    uint16_t scl;
    uint16_t sda;
    I2C_TypeDef *I2Cx;
    LL_I2C_InitTypeDef li2c;
}I2C_ST;

I2C_TypeDef *LL_GET_I2Cx(uint8_t id);
uint32_t LL_GET_I2C_CLK(uint8_t id);
uint16_t LL_GET_I2C_PIN(uint8_t id);
uint8_t LL_CONFIG_I2C_PIN(uint8_t id);

#ifdef __cplusplus
}
#endif

#endif