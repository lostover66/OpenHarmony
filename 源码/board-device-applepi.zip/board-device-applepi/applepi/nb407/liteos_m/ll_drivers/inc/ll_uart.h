#ifndef __LL_UART_H
#define __LL_UART_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
#include "stdio.h"
#include "stm32f4xx_ll_usart.h"
#include "stm32f4xx_ll_dma.h"
#include "ll_gpio.h"

#define RX  0
#define TX  1
// 引脚
#define UART1_RX    PA10
#define UART1_TX    PA9
#define UART2_RX    PA3
#define UART2_TX    PA2
#define UART3_RX    PB11
#define UART3_TX    PB10
#define UART4_RX    PC11
#define UART4_TX    PC10
#define UART5_RX    PD2
#define UART5_TX    PC12
#define UART6_RX    PC7
#define UART6_TX    PC6
// 最大个数
#define UART_MAX    6
// 超时 s
#define UART_TIMEOUT    10
// 接收缓存区长度
#define UART1_RX_DMA_LEN    256
#define UART2_RX_DMA_LEN    256
#define UART3_RX_DMA_LEN    256
#define UART4_RX_DMA_LEN    32
#define UART5_RX_DMA_LEN    32
#define UART6_RX_DMA_LEN    32
// 发送缓存区长度
#define UART1_TX_DMA_LEN    256
#define UART2_TX_DMA_LEN    256
#define UART3_TX_DMA_LEN    256
#define UART4_TX_DMA_LEN    32
#define UART5_TX_DMA_LEN    32
#define UART6_TX_DMA_LEN    32
// 队列的长度,循环队列，超出范围覆盖最早的信息
#define UART1_RX_QUEUE_SIZE 256*4
#define UART2_RX_QUEUE_SIZE 256*4
#define UART3_RX_QUEUE_SIZE 256*4
#define UART4_RX_QUEUE_SIZE 256*4
#define UART5_RX_QUEUE_SIZE 256*4
#define UART6_RX_QUEUE_SIZE 256*4

typedef struct{
    uint16_t rx_pin; // 引脚
    uint16_t tx_pin;
    uint8_t queue_id; // 队列id
    uint16_t queue_size;// 队列最大长度
    USART_TypeDef *UARTx;// USART1\2\3
    DMA_TypeDef *DMAx; // DMA1\2
    LL_USART_InitTypeDef luart;// 串口初始化结构体
}UART_ST;

USART_TypeDef *LL_GET_UARTX(uint8_t id);
DMA_TypeDef *LL_GET_UART_DMAX(uint8_t id);
uint8_t LL_CONFIG_UART_PIN(uint8_t id);
void LL_ENABLE_UART_CLK(uint8_t id);
/*********中断处理函数**********/
void UART_RxDmaHandler();
void UART_TxDmaHandler();
void UART_IRQHandler();
/*********判断DMA 完成或出错标记**********/
uint8_t LL_DMA_IS_RX_TC(uint8_t id);
uint8_t LL_DMA_IS_RX_TE(uint8_t id);
uint8_t LL_DMA_IS_TX_TC(uint8_t id);
uint8_t LL_DMA_IS_TX_TE(uint8_t id);
/*********清除DMA 完成或出错标记**********/
void LL_DMA_CLEAR_RX_TC(uint8_t id);
void LL_DMA_CLEAR_RX_TE(uint8_t id);
void LL_DMA_CLEAR_TX_TC(uint8_t id);
void LL_DMA_CLEAR_TX_TE(uint8_t id);
void LL_DMA_CLEAR_ALL_FLAG(uint8_t id);

void LL_UART_DMA_Init(uint8_t id);
void LL_UART_DMA_DeInit(uint8_t id);
int UartWriteDMA(unsigned int id, const unsigned char *data, unsigned int dataLen, uint8_t sec);

#ifdef __cplusplus
}
#endif

#endif