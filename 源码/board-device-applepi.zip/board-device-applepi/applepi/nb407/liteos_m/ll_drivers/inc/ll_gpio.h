    #ifndef __LL_GPIO_H
    #define __LL_GPIO_H

    #ifdef __cplusplus
    extern "C" {
    #endif

    #include "stdint.h"
    #include "stm32f4xx_ll_gpio.h"
    #include "stm32f4xx_ll_exti.h"
    #include "stm32f4xx_ll_bus.h"
    #include "stm32f4xx_ll_utils.h"
    /*将所有引脚从0开始排序，适配iot框架的id*/
    /* id/16得到某个组号， id%16得到组内编号*/
    /* PA0 ~ PA15 */
    #define PA0     (0*16+0)
    #define PA1     (0*16+1)
    #define PA2     (0*16+2)
    #define PA3     (0*16+3)
    #define PA4     (0*16+4)
    #define PA5     (0*16+5)
    #define PA6     (0*16+6)
    #define PA7     (0*16+7)
    #define PA8     (0*16+8)
    #define PA9     (0*16+9)
    #define PA10    (0*16+10)
    #define PA11    (0*16+11)
    #define PA12    (0*16+12)
    #define PA13    (0*16+13)
    #define PA14    (0*16+14)
    #define PA15    (0*16+15)

    /* PB0 ~ PB15 */
    #define PB0     (1*16+0)
    #define PB1     (1*16+1)
    #define PB2     (1*16+2)
    #define PB3     (1*16+3)
    #define PB4     (1*16+4)
    #define PB5     (1*16+5)
    #define PB6     (1*16+6)
    #define PB7     (1*16+7)
    #define PB8     (1*16+8)
    #define PB9     (1*16+9)
    #define PB10    (1*16+10)
    #define PB11    (1*16+11)
    #define PB12    (1*16+12)
    #define PB13    (1*16+13)
    #define PB14    (1*16+14)
    #define PB15    (1*16+15)

    /* PC0 ~ PC15 */
    #define PC0     (2*16+0)
    #define PC1     (2*16+1)
    #define PC2     (2*16+2)
    #define PC3     (2*16+3)
    #define PC4     (2*16+4)
    #define PC5     (2*16+5)
    #define PC6     (2*16+6)
    #define PC7     (2*16+7)
    #define PC8     (2*16+8)
    #define PC9     (2*16+9)
    #define PC10    (2*16+10)
    #define PC11    (2*16+11)
    #define PC12    (2*16+12)
    #define PC13    (2*16+13)
    #define PC14    (2*16+14)
    #define PC15    (2*16+15)

    /* PD0 ~ PD15 */
    #define PD0     (3*16+0)
    #define PD1     (3*16+1)
    #define PD2     (3*16+2)
    #define PD3     (3*16+3)
    #define PD4     (3*16+4)
    #define PD5     (3*16+5)
    #define PD6     (3*16+6)
    #define PD7     (3*16+7)
    #define PD8     (3*16+8)
    #define PD9     (3*16+9)
    #define PD10    (3*16+10)
    #define PD11    (3*16+11)
    #define PD12    (3*16+12)
    #define PD13    (3*16+13)
    #define PD14    (3*16+14)
    #define PD15    (3*16+15)

    /* PE0 ~ PE15 */
    #define PE0     (4*16+0)
    #define PE1     (4*16+1)
    #define PE2     (4*16+2)
    #define PE3     (4*16+3)
    #define PE4     (4*16+4)
    #define PE5     (4*16+5)
    #define PE6     (4*16+6)
    #define PE7     (4*16+7)
    #define PE8     (4*16+8)
    #define PE9     (4*16+9)
    #define PE10    (4*16+10)
    #define PE11    (4*16+11)
    #define PE12    (4*16+12)
    #define PE13    (4*16+13)
    #define PE14    (4*16+14)
    #define PE15    (4*16+15)

    /* PF0 ~ PF15 */
    #define PF0     (5*16+0)
    #define PF1     (5*16+1)
    #define PF2     (5*16+2)
    #define PF3     (5*16+3)
    #define PF4     (5*16+4)
    #define PF5     (5*16+5)
    #define PF6     (5*16+6)
    #define PF7     (5*16+7)
    #define PF8     (5*16+8)
    #define PF9     (5*16+9)
    #define PF10    (5*16+10)
    #define PF11    (5*16+11)
    #define PF12    (5*16+12)
    #define PF13    (5*16+13)
    #define PF14    (5*16+14)
    #define PF15    (5*16+15)

    /* PG0 ~ PG15 */
    #define PG0     (6*16+0)
    #define PG1     (6*16+1)
    #define PG2     (6*16+2)
    #define PG3     (6*16+3)
    #define PG4     (6*16+4)
    #define PG5     (6*16+5)
    #define PG6     (6*16+6)
    #define PG7     (6*16+7)
    #define PG8     (6*16+8)
    #define PG9     (6*16+9)
    #define PG10    (6*16+10)
    #define PG11    (6*16+11)
    #define PG12    (6*16+12)
    #define PG13    (6*16+13)
    #define PG14    (6*16+14)
    #define PG15    (6*16+15)

    /* PH0 ~ PH15 */
    #define PH0     (7*16+0)
    #define PH1     (7*16+1)
    #define PH2     (7*16+2)
    #define PH3     (7*16+3)
    #define PH4     (7*16+4)
    #define PH5     (7*16+5)
    #define PH6     (7*16+6)
    #define PH7     (7*16+7)
    #define PH8     (7*16+8)
    #define PH9     (7*16+9)
    #define PH10    (7*16+10)
    #define PH11    (7*16+11)
    #define PH12    (7*16+12)
    #define PH13    (7*16+13)
    #define PH14    (7*16+14)
    #define PH15    (7*16+15)

    typedef enum{
        STM32_GPIO_GROUP_A = 0,
        STM32_GPIO_GROUP_B,
        STM32_GPIO_GROUP_C,
        STM32_GPIO_GROUP_D,
        STM32_GPIO_GROUP_E,
        STM32_GPIO_GROUP_F,
        STM32_GPIO_GROUP_G,
        STM32_GPIO_GROUP_H,
        STM32_GPIO_GROUP_MAX,
    }STM32_GPIO_GROUP;

    typedef enum{
        STM32_GPIO_PIN_0 = 0,
        STM32_GPIO_PIN_1,
        STM32_GPIO_PIN_2,
        STM32_GPIO_PIN_3,
        STM32_GPIO_PIN_4,
        STM32_GPIO_PIN_5,
        STM32_GPIO_PIN_6,
        STM32_GPIO_PIN_7,
        STM32_GPIO_PIN_8,
        STM32_GPIO_PIN_9,
        STM32_GPIO_PIN_10,
        STM32_GPIO_PIN_11,
        STM32_GPIO_PIN_12,
        STM32_GPIO_PIN_13,
        STM32_GPIO_PIN_14,
        STM32_GPIO_PIN_15,
        STM32_GPIO_PIN_MAX,
    }STM32_GPIO_PIN;

    typedef void (*LL_EXTI_HANDLER)(uint16_t realPin);

    typedef struct{
        uint8_t group; // 引脚分组 PA\PB\PC, STM32_GPIO_GROUP_x
        uint8_t pin;   // 组内id，0~15，STM32_GPIO_PIN_x
        uint16_t realPin; // 实际引脚号，PXx
        GPIO_TypeDef *GPIOx; // GPIOA\B\C
        uint32_t pinReg;     // LL_GPIO_PIN_X
        LL_GPIO_InitTypeDef gpioStruct;//gpio初始化结构

        LL_EXTI_InitTypeDef extiStruct;// 中断结构体
        LL_EXTI_HANDLER handler;// 中断处理函数
    }PIN_ST;

    GPIO_TypeDef *LL_GET_GPIOX(uint16_t id);
    uint32_t LL_GET_GPIO_PIN(uint16_t id);
    uint32_t LL_GET_GPIO_CLK(uint16_t id);
    void LL_CONFIG_GPIO(uint16_t id, \
        uint32_t mode, uint32_t pull,\
        uint32_t speed, uint32_t outType, \
        uint32_t alt
    );


    #ifdef __cplusplus
    }
    #endif

    #endif