#include "ll_gpio.h"

GPIO_TypeDef *LL_GET_GPIOX(uint16_t id){
    uint8_t group = id/16;
    //return (GPIOA+0x400*group);
    switch(group){
        case 0: return (GPIO_TypeDef *)GPIOA;
        case 1: return (GPIO_TypeDef *)GPIOB;
        case 2: return (GPIO_TypeDef *)GPIOC;
        case 3: return (GPIO_TypeDef *)GPIOD;
        case 4: return (GPIO_TypeDef *)GPIOE;
        case 5: return (GPIO_TypeDef *)GPIOF;
        case 6: return (GPIO_TypeDef *)GPIOG;
        case 7: return (GPIO_TypeDef *)GPIOH;
    }
}
// LL_GPIO_PIN_x ---- 2^n
uint32_t LL_GET_GPIO_PIN(uint16_t id){
    uint8_t pin = id%16;
    return (LL_GPIO_PIN_0<<pin);
}
// LL_AHB1_GRP1_PERIPH_GPIOx --- 2^n
uint32_t LL_GET_GPIO_CLK(uint16_t id){
    uint8_t group = id/16;
    //return LL_AHB1_GRP1_PERIPH_GPIOA<<group;
    switch(group){
        case 0: return LL_AHB1_GRP1_PERIPH_GPIOA;
        case 1: return LL_AHB1_GRP1_PERIPH_GPIOB;
        case 2: return LL_AHB1_GRP1_PERIPH_GPIOC;
        case 3: return LL_AHB1_GRP1_PERIPH_GPIOD;
        case 4: return LL_AHB1_GRP1_PERIPH_GPIOE;
        case 5: return LL_AHB1_GRP1_PERIPH_GPIOF;
        case 6: return LL_AHB1_GRP1_PERIPH_GPIOG;
        case 7: return LL_AHB1_GRP1_PERIPH_GPIOH;
    }
}
// 全局数组，记录每个引脚配置
PIN_ST g_pinsGroup[STM32_GPIO_GROUP_MAX*STM32_GPIO_PIN_MAX]={0};
void LL_CONFIG_GPIO(uint16_t id, \
    uint32_t mode, uint32_t pull,\
    uint32_t speed, uint32_t outType, \
    uint32_t alt
){
    g_pinsGroup[id].pin = id%16;
    g_pinsGroup[id].group = id/16;
    g_pinsGroup[id].realPin = id;
  g_pinsGroup[id].gpioStruct.Pin = LL_GET_GPIO_PIN(id);
  g_pinsGroup[id].gpioStruct.Mode = mode;
  g_pinsGroup[id].gpioStruct.Speed = speed;
  g_pinsGroup[id].gpioStruct.OutputType = outType;
  g_pinsGroup[id].gpioStruct.Pull = pull;
  g_pinsGroup[id].gpioStruct.Alternate = alt;
}