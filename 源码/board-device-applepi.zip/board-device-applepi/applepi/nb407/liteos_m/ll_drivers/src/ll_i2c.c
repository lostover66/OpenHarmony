/*****************************************************
Tabel I2C-Pin about stm32f407 gpio alternate for I2C

┏━━━━━━━━━━━━━━━┯━━━━━━━━━━━┯━━━━━━━━━━━┯━━━━━━━━━━━┓
┃   function    ┃   pin     ┃  pin      ┃   pin     ┃
┠━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┨
┃                      LL_GPIO_AF4                  ┃
┠━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┨
┃   I2C1_SCL    ┃   PB6     ┃  PB8      ┃           ┃
┃   I2C1_SDA    ┃   PB7     ┃  PB9      ┃           ┃
┠━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┨
┃   I2C2_SCL    ┃   PB10    ┃  PF1      ┃   PH4     ┃
┃   I2C2_SDA    ┃   PB11    ┃  PF0      ┃   PH5     ┃
┠━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┨
┃   I2C3_SCL    ┃   PA8     ┃  PH7      ┃           ┃
┃   I2C3_SDA    ┃   PC9     ┃  PH8      ┃           ┃
┗━━━━━━━━━━━━━━━┷━━━━━━━━━━━┷━━━━━━━━━━━┷━━━━━━━━━━━┛
*****************************************************/
#include "ll_i2c.h"

I2C_ST g_i2cGroups[I2C_MAX]={0};
extern PIN_ST g_pinsGroup[STM32_GPIO_GROUP_MAX * STM32_GPIO_PIN_MAX];
static uint16_t g_i2cPinMap[I2C_MAX][2]={
    {I2C1_SCL, I2C1_SDA},
    {I2C2_SCL, I2C2_SDA},
    {I2C3_SCL, I2C3_SDA},
};

I2C_TypeDef *LL_GET_I2Cx(uint8_t id){
    switch(id){
        case 1: return I2C1;
        case 2: return I2C2;
        case 3: return I2C3;
    }
}
uint32_t LL_GET_I2C_CLK(uint8_t id){
    switch(id){
        case 1: return LL_APB1_GRP1_PERIPH_I2C1;
        case 2: return LL_APB1_GRP1_PERIPH_I2C2;
        case 3: return LL_APB1_GRP1_PERIPH_I2C3;
    }
}
uint16_t LL_GET_I2C_PIN(uint8_t id){

}
uint8_t LL_CONFIG_I2C_PIN(uint8_t id){
    // 通过id得到引脚
    g_i2cGroups[id-1].scl = g_i2cPinMap[id-1][0];
    g_i2cGroups[id-1].sda = g_i2cPinMap[id-1][1];
    g_i2cGroups[id-1].I2Cx = LL_GET_I2Cx(id);
    // 把引脚配置为AF_4，I2C功能
    LL_CONFIG_GPIO(g_i2cGroups[id-1].scl, \
        LL_GPIO_MODE_ALTERNATE, LL_GPIO_PULL_NO,\
        LL_GPIO_SPEED_FREQ_VERY_HIGH, \
        LL_GPIO_OUTPUT_OPENDRAIN,LL_GPIO_AF_4);
    LL_CONFIG_GPIO(g_i2cGroups[id-1].sda, \
        LL_GPIO_MODE_ALTERNATE, LL_GPIO_PULL_NO,\
        LL_GPIO_SPEED_FREQ_VERY_HIGH, \
        LL_GPIO_OUTPUT_OPENDRAIN,LL_GPIO_AF_4);
    // 打开GPIO时钟
    LL_AHB1_GRP1_EnableClock( \
        LL_GET_GPIO_CLK(g_i2cGroups[id-1].scl));
    LL_AHB1_GRP1_EnableClock( \
        LL_GET_GPIO_CLK(g_i2cGroups[id-1].sda));
    // 初始化引脚
    uint8_t res;
    res = LL_GPIO_Init(
        LL_GET_GPIOX(g_i2cGroups[id-1].scl), \
        &g_pinsGroup[g_i2cGroups[id-1].scl].gpioStruct
    );
    if(res == ERROR){
        printf("%s line %d, LL_GPIO_Init scl failed\n",__func__, __LINE__);
        return ERROR;
    }
    res = LL_GPIO_Init(
        LL_GET_GPIOX(g_i2cGroups[id-1].sda), \
        &g_pinsGroup[g_i2cGroups[id-1].sda].gpioStruct
    );
    if(res == ERROR){
        printf("%s line %d, LL_GPIO_Init sda failed\n",__func__, __LINE__);
        return ERROR;
    }
    return SUCCESS;
}
