/*********************************************************************************************
Tabel UART-Pin about stm32f407 gpio alternate for UART 1~3 AF_7   4~6 AF_8
┏━━━━━━━━━━━━━━━┯━━━━━━━━━━━┯━━━━━━━━━━━┯━━━━━━━━━━━┯━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃   function    ┃   pin     ┃  pin      ┃   pin     ┃   DMA request                          ┃
┠━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┨
┃   UART1_RX    ┃   PA10    ┃  PB7      ┃           ┃   Channel4/DMA2_Steam2/DMA2_Steam5     ┃
┃   UART1_TX    ┃   PA9     ┃  PB6      ┃           ┃   Channel4/DMA2_Steam7                 ┃
┠━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┨
┃   UART2_RX    ┃   PA3     ┃  PD6      ┃           ┃   Channel4/DMA1_Steam5                 ┃
┃   UART2_TX    ┃   PA2     ┃  PD5      ┃           ┃   Channel4/DMA1_Steam6                 ┃
┠━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┨
┃   UART3_RX    ┃   PB11    ┃  PC11     ┃   PD9     ┃   Channel4/DMA1_Steam1                 ┃
┃   UART3_TX    ┃   PB10    ┃  PC10     ┃   PD8     ┃   Channel4/DMA1_Steam3                 ┃
┠━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┨
┃   UART4_RX    ┃   PA1     ┃  PC11     ┃           ┃   Channel4/DMA1_Steam2                 ┃
┃   UART4_TX    ┃   PA0     ┃  PC10     ┃   PC6     ┃   Channel4/DMA1_Steam4                 ┃
┠━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┨
┃   UART5_RX    ┃   PD2     ┃           ┃           ┃   Channel4/DMA1_Steam0                 ┃
┃   UART5_TX    ┃   PC12    ┃           ┃           ┃   Channel4/DMA1_Steam7                 ┃
┠━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┨
┃   UART6_RX    ┃   PC7     ┃  PG9      ┃           ┃   Channel5/DMA2_Steam2                 ┃
┃   UART6_TX    ┃   PC6     ┃  PG14     ┃           ┃   Channel5/DMA2_Steam6/DMA2_Steam7     ┃
┗━━━━━━━━━━━━━━━┷━━━━━━━━━━━┷━━━━━━━━━━━┷━━━━━━━━━━━┷━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
*********************************************************************************************/
/*

#include "stm32f4xx.h"
#include "stm32f4xx_ll_usart.h"
#include "stm32f4xx_ll_dma.h"
#include "stm32f4xx_ll_gpio.h"
#include "stm32f4xx_ll_bus.h"

#define USART1_RX_BUF_SIZE      256U
static uint8_t usart1_rx_buf[USART1_RX_BUF_SIZE];
static volatile uint16_t usart1_rx_len = 0U;
static volatile uint8_t  usart1_rx_flag = 0U;
static volatile uint8_t  usart1_tx_busy = 0U;

void USART1_Init(uint32_t baudrate)
{
 
    LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_USART1);
    LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOA);

    LL_GPIO_SetPinMode(GPIOA, LL_GPIO_PIN_9,  LL_GPIO_MODE_ALTERNATE);
    LL_GPIO_SetPinMode(GPIOA, LL_GPIO_PIN_10, LL_GPIO_MODE_ALTERNATE);
    LL_GPIO_SetPinOutputType(GPIOA, LL_GPIO_PIN_9, LL_GPIO_OUTPUT_PUSHPULL);
    LL_GPIO_SetPinPull(GPIOA, LL_GPIO_PIN_10, LL_GPIO_PULL_UP);
    LL_GPIO_SetAFPin_8_15(GPIOA, LL_GPIO_PIN_9,  LL_GPIO_AF_7);
    LL_GPIO_SetAFPin_8_15(GPIOA, LL_GPIO_PIN_10, LL_GPIO_AF_7);
  
    LL_USART_InitTypeDef USART_InitStruct = {0};
    USART_InitStruct.BaudRate            = baudrate;
    USART_InitStruct.DataWidth           = LL_USART_DATAWIDTH_8B;
    USART_InitStruct.StopBits            = LL_USART_STOPBITS_1;
    USART_InitStruct.Parity              = LL_USART_PARITY_NONE;
    USART_InitStruct.TransferDirection   = LL_USART_DIRECTION_TX_RX;
    USART_InitStruct.HardwareFlowControl = LL_USART_HWCONTROL_NONE;
    USART_InitStruct.OverSampling        = LL_USART_OVERSAMPLING_16;
    LL_USART_Init(USART1, &USART_InitStruct);

    LL_USART_EnableDMAReq_RX(USART1);
    LL_USART_EnableDMAReq_TX(USART1);

    LL_USART_EnableIT_IDLE(USART1);

    LL_USART_Enable(USART1);

    NVIC_SetPriority(USART1_IRQn, 1);
    NVIC_EnableIRQ(USART1_IRQn);
}

void USART1_DMA_Init(void)
{
    LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_DMA2);
    LL_DMA_DisableStream(DMA2, LL_DMA_STREAM_5);
    while (LL_DMA_IsEnabledStream(DMA2, LL_DMA_STREAM_5)) { }

    LL_DMA_SetChannelSelection(DMA2, LL_DMA_STREAM_5, LL_DMA_CHANNEL_4);
    LL_DMA_SetDataTransferDirection(DMA2, LL_DMA_STREAM_5,
                                    LL_DMA_DIRECTION_PERIPH_TO_MEMORY);
    LL_DMA_SetStreamPriorityLevel(DMA2, LL_DMA_STREAM_5, LL_DMA_PRIORITY_HIGH);
    LL_DMA_SetMode(DMA2, LL_DMA_STREAM_5, LL_DMA_MODE_CIRCULAR);
    LL_DMA_SetPeriphIncMode(DMA2, LL_DMA_STREAM_5, LL_DMA_PERIPH_NOINCREMENT);
    LL_DMA_SetMemoryIncMode(DMA2, LL_DMA_STREAM_5, LL_DMA_MEMORY_INCREMENT);
    LL_DMA_SetPeriphSize(DMA2, LL_DMA_STREAM_5, LL_DMA_PDATAALIGN_BYTE);
    LL_DMA_SetMemorySize(DMA2, LL_DMA_STREAM_5, LL_DMA_MDATAALIGN_BYTE);
    LL_DMA_DisableFifoMode(DMA2, LL_DMA_STREAM_5);

    LL_DMA_SetPeriphAddress(DMA2, LL_DMA_STREAM_5, (uint32_t)&USART1->DR);
    LL_DMA_SetMemoryAddress(DMA2, LL_DMA_STREAM_5, (uint32_t)usart1_rx_buf);
    LL_DMA_SetDataLength(DMA2, LL_DMA_STREAM_5, USART1_RX_BUF_SIZE);

    LL_DMA_EnableStream(DMA2, LL_DMA_STREAM_5);

 
    LL_DMA_DisableStream(DMA2, LL_DMA_STREAM_7);
    while (LL_DMA_IsEnabledStream(DMA2, LL_DMA_STREAM_7)) { }

    LL_DMA_SetChannelSelection(DMA2, LL_DMA_STREAM_7, LL_DMA_CHANNEL_4);
    LL_DMA_SetDataTransferDirection(DMA2, LL_DMA_STREAM_7,
                                    LL_DMA_DIRECTION_MEMORY_TO_PERIPH);
    LL_DMA_SetStreamPriorityLevel(DMA2, LL_DMA_STREAM_7, LL_DMA_PRIORITY_MEDIUM);
    LL_DMA_SetMode(DMA2, LL_DMA_STREAM_7, LL_DMA_MODE_NORMAL);
    LL_DMA_SetPeriphIncMode(DMA2, LL_DMA_STREAM_7, LL_DMA_PERIPH_NOINCREMENT);
    LL_DMA_SetMemoryIncMode(DMA2, LL_DMA_STREAM_7, LL_DMA_MEMORY_INCREMENT);
    LL_DMA_SetPeriphSize(DMA2, LL_DMA_STREAM_7, LL_DMA_PDATAALIGN_BYTE);
    LL_DMA_SetMemorySize(DMA2, LL_DMA_STREAM_7, LL_DMA_MDATAALIGN_BYTE);
    LL_DMA_DisableFifoMode(DMA2, LL_DMA_STREAM_7);

    LL_DMA_SetPeriphAddress(DMA2, LL_DMA_STREAM_7, (uint32_t)&USART1->DR);

    LL_DMA_EnableIT_TC(DMA2, LL_DMA_STREAM_7);

    NVIC_SetPriority(DMA2_Stream7_IRQn, 2);
    NVIC_EnableIRQ(DMA2_Stream7_IRQn);
}

======================== 串口中断处理 ========================== 
void USART1_IRQHandler(void)
{
    if (LL_USART_IsActiveFlag_IDLE(USART1) && LL_USART_IsEnabledIT_IDLE(USART1))
    {
        LL_USART_ClearFlag_IDLE(USART1);    
        uint16_t remain = LL_DMA_GetDataLength(DMA2, LL_DMA_STREAM_5);
      
        usart1_rx_len = USART1_RX_BUF_SIZE - remain;
        if (usart1_rx_len > 0U)
        {
            usart1_rx_flag = 1U;
        }
    }
  
    if (LL_USART_IsActiveFlag_ORE(USART1))
    {
        LL_USART_ClearFlag_ORE(USART1);
    }
}

====================== DMA 中断处理 ============================ 
void DMA2_Stream7_IRQHandler(void)
{
    if (LL_DMA_IsActiveFlag_TC7(DMA2))
    {
        LL_DMA_ClearFlag_TC7(DMA2);
        LL_DMA_DisableStream(DMA2, LL_DMA_STREAM_7);
        LL_USART_ClearFlag_TC(USART1);
        usart1_tx_busy = 0U;  
    }
    if (LL_DMA_IsActiveFlag_TE7(DMA2))
    {
        LL_DMA_ClearFlag_TE7(DMA2);
        LL_DMA_DisableStream(DMA2, LL_DMA_STREAM_7);
        usart1_tx_busy = 0U;
    }
}

 ======================== 串口发送函数 ==========================
uint8_t USART1_Send_DMA(const uint8_t *data, uint16_t len)
{
    if (data == NULL || len == 0U)
    {
        return 1U;
    }

    if (usart1_tx_busy)
    {
        return 1U;
    }

    usart1_tx_busy = 1U;
    LL_DMA_DisableStream(DMA2, LL_DMA_STREAM_7);
    while (LL_DMA_IsEnabledStream(DMA2, LL_DMA_STREAM_7)) { }
    LL_DMA_SetMemoryAddress(DMA2, LL_DMA_STREAM_7, (uint32_t)data);
    LL_DMA_SetDataLength(DMA2, LL_DMA_STREAM_7, len);
    LL_DMA_ClearFlag_TC7(DMA2);  
    LL_DMA_EnableStream(DMA2, LL_DMA_STREAM_7);

    return 0U;
}
*/
#include "ll_uart.h"
#include "stm32f4xx_ll_usart.h"
#include "stm32f4xx_ll_bus.h"

UART_ST g_uartStruct[UART_MAX]={0};
extern PIN_ST g_pinsGroup[STM32_GPIO_GROUP_MAX*STM32_GPIO_PIN_MAX];
// 串口dma缓冲区
static uint8_t uartRxBuffer_1[UART1_RX_DMA_LEN];
static uint8_t uartRxBuffer_2[UART2_RX_DMA_LEN];
static uint8_t uartRxBuffer_3[UART3_RX_DMA_LEN];
static uint8_t uartRxBuffer_4[UART4_RX_DMA_LEN];
static uint8_t uartRxBuffer_5[UART5_RX_DMA_LEN];
static uint8_t uartRxBuffer_6[UART6_RX_DMA_LEN];
static uint8_t uartTxBuffer_1[UART1_TX_DMA_LEN];
static uint8_t uartTxBuffer_2[UART2_TX_DMA_LEN];
static uint8_t uartTxBuffer_3[UART3_TX_DMA_LEN];
static uint8_t uartTxBuffer_4[UART4_TX_DMA_LEN];
static uint8_t uartTxBuffer_5[UART5_TX_DMA_LEN];
static uint8_t uartTxBuffer_6[UART6_TX_DMA_LEN];
// 引脚映射
static uint16_t UART_PIN_MAP[UART_MAX][2]={
    {UART1_RX, UART1_TX},
    {UART2_RX, UART2_TX},
    {UART3_RX, UART3_TX},
    {UART4_RX, UART4_TX},
    {UART5_RX, UART5_TX},
    {UART6_RX, UART6_TX},
};
// DMA长度
static uint16_t UART_DMA_LEN[UART_MAX][2]={
    {UART1_RX_DMA_LEN, UART1_TX_DMA_LEN},
    {UART2_RX_DMA_LEN, UART2_TX_DMA_LEN},
    {UART3_RX_DMA_LEN, UART3_TX_DMA_LEN},
    {UART4_RX_DMA_LEN, UART4_TX_DMA_LEN},
    {UART5_RX_DMA_LEN, UART5_TX_DMA_LEN},
    {UART6_RX_DMA_LEN, UART6_TX_DMA_LEN},
};
// dma中断号
static uint8_t UART_DMA_IRQ[UART_MAX][2] = {
    {DMA2_Stream5_IRQn, DMA2_Stream7_IRQn},
    {DMA1_Stream5_IRQn, DMA1_Stream6_IRQn},
    {DMA1_Stream1_IRQn, DMA1_Stream3_IRQn},
    {DMA1_Stream2_IRQn, DMA1_Stream4_IRQn},
    {DMA1_Stream0_IRQn, DMA1_Stream7_IRQn},
    {DMA2_Stream2_IRQn, DMA2_Stream6_IRQn},
};
// dma stream
static uint32_t UART_DMA_STREAM[UART_MAX][2] = {
    {LL_DMA_STREAM_5, LL_DMA_STREAM_7},
    {LL_DMA_STREAM_5, LL_DMA_STREAM_6},
    {LL_DMA_STREAM_1, LL_DMA_STREAM_3},
    {LL_DMA_STREAM_2, LL_DMA_STREAM_4},
    {LL_DMA_STREAM_0, LL_DMA_STREAM_7},
    {LL_DMA_STREAM_2, LL_DMA_STREAM_6},
};
// dma channel
static uint32_t UART_DMA_CHANNEL[UART_MAX] = {
    LL_DMA_CHANNEL_4, LL_DMA_CHANNEL_4, LL_DMA_CHANNEL_4, LL_DMA_CHANNEL_4, LL_DMA_CHANNEL_4, LL_DMA_CHANNEL_5
};
// dma buf
static uint8_t *UART_DMA_BUF[UART_MAX][2]={
    {uartRxBuffer_1, uartTxBuffer_1},
    {uartRxBuffer_2, uartTxBuffer_2},
    {uartRxBuffer_3, uartTxBuffer_3},
    {uartRxBuffer_4, uartTxBuffer_4},
    {uartRxBuffer_5, uartTxBuffer_5},
    {uartRxBuffer_6, uartTxBuffer_6},
};
// DMA send busy
static uint8_t UART_TX_DMA_BUSY[UART_MAX]={0};
// 串口中断号
static uint8_t UART_IRQn[UART_MAX]={
    USART1_IRQn, USART2_IRQn, USART3_IRQn,
    UART4_IRQn, UART5_IRQn, USART6_IRQn,
};
// 接收队列长度
static uint16_t UART_RX_QUEUE_SIZE[UART_MAX]={
    UART1_RX_QUEUE_SIZE, UART2_RX_QUEUE_SIZE,
    UART3_RX_QUEUE_SIZE, UART4_RX_QUEUE_SIZE,
    UART5_RX_QUEUE_SIZE, UART6_RX_QUEUE_SIZE,
};


USART_TypeDef *LL_GET_UARTX(uint8_t id){
    switch(id){
        case 1: return USART1;
        case 2: return USART2;
        case 3: return USART3;
        case 4: return UART4;
        case 5: return UART5;
        case 6: return USART6;
    }
}
DMA_TypeDef *LL_GET_UART_DMAX(uint8_t id){
    if(id==1 || id==6)
        return DMA2;
    else
        return DMA1;
}
uint8_t LL_CONFIG_UART_PIN(uint8_t id){
    // queue
    g_uartStruct[id - 1].queue_id = 0xff;
    g_uartStruct[id - 1].queue_size = UART_RX_QUEUE_SIZE[id - 1];
    g_uartStruct[id - 1].UARTx = LL_GET_UARTX(id);
    // 获取引脚
    g_uartStruct[id - 1].rx_pin = UART_PIN_MAP[id - 1][0];
    g_uartStruct[id - 1].tx_pin = UART_PIN_MAP[id - 1][1];
    // 设置引脚复用
    if (id <= 3)
    {
        LL_CONFIG_GPIO(g_uartStruct[id - 1].rx_pin, LL_GPIO_MODE_ALTERNATE, LL_GPIO_PULL_NO, LL_GPIO_SPEED_FREQ_VERY_HIGH, LL_GPIO_OUTPUT_PUSHPULL, LL_GPIO_AF_7);
        LL_CONFIG_GPIO(g_uartStruct[id - 1].tx_pin, LL_GPIO_MODE_ALTERNATE, LL_GPIO_PULL_NO, LL_GPIO_SPEED_FREQ_VERY_HIGH, LL_GPIO_OUTPUT_PUSHPULL, LL_GPIO_AF_7);
    }
    else
    {
        LL_CONFIG_GPIO(g_uartStruct[id - 1].rx_pin, LL_GPIO_MODE_ALTERNATE, LL_GPIO_PULL_NO, LL_GPIO_SPEED_FREQ_VERY_HIGH, LL_GPIO_OUTPUT_PUSHPULL, LL_GPIO_AF_8);
        LL_CONFIG_GPIO(g_uartStruct[id - 1].tx_pin, LL_GPIO_MODE_ALTERNATE, LL_GPIO_PULL_NO, LL_GPIO_SPEED_FREQ_VERY_HIGH, LL_GPIO_OUTPUT_PUSHPULL, LL_GPIO_AF_8);
    }
    // 初始化GPIO
    /************************* 初始化 RX引脚 ******************************/
    STM32_GPIO_GROUP group = (g_uartStruct[id - 1].rx_pin) / 16;
    // 打开时钟
    LL_AHB1_GRP1_EnableClock(LL_GET_GPIO_CLK(g_uartStruct[id - 1].rx_pin));
    GPIO_TypeDef *GPIOx = LL_GET_GPIOX((g_uartStruct[id - 1].rx_pin));
    // 初始化引脚
    if (LL_GPIO_Init(GPIOx, &g_pinsGroup[g_uartStruct[id - 1].rx_pin].gpioStruct) != SUCCESS)
    {
        printf("%s line %d error : LL_GPIO_Init Uart%d rx pin failed...\n", __func__, __LINE__, id + 1);
        return ERROR;
    }
    /************************* 初始化 TX引脚 ******************************/
    // 改变引脚编号，其余参数一样
    group = (g_uartStruct[id - 1].tx_pin) / 16;
    // 打开时钟
    LL_AHB1_GRP1_EnableClock(LL_GET_GPIO_CLK(g_uartStruct[id - 1].tx_pin));
    GPIOx = LL_GET_GPIOX(g_uartStruct[id - 1].tx_pin);
    // 初始化引脚
    if (LL_GPIO_Init(GPIOx, &g_pinsGroup[g_uartStruct[id - 1].tx_pin].gpioStruct) != SUCCESS)
    {
        printf("%s line %d error : LL_GPIO_Init Uart%d tx pin failed...\n", __func__, __LINE__, id + 1);
        return ERROR;
    }
    return SUCCESS;
}
void LL_ENABLE_UART_CLK(uint8_t id){
    switch(id){
        case 1: LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_USART1); break;
        case 2: LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_USART2); break;
        case 3: LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_USART3); break;
        case 4: LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_UART4); break;
        case 5: LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_UART5); break;
        case 6: LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_USART6); break;
        default: break;
    }
}
/*********中断处理函数**********/
void UART_RxDmaHandler(){ 
    for(char i=1; i<=6; i++){
        if(g_uartStruct[i-1].UARTx == NULL)
            continue;
        // 判断标记位
        if(LL_DMA_IS_RX_TC(i))
            LL_DMA_CLEAR_RX_TC(i);// 清除标记位
        if(LL_DMA_IS_RX_TE(i))
            LL_DMA_CLEAR_RX_TE(i);
    }
}
void UART_TxDmaHandler(){
    for(char i=1; i<=6; i++){
        if(g_uartStruct[i-1].UARTx == NULL)
            continue;
        // 判断标记位
        if(LL_DMA_IS_TX_TC(i)){
            LL_DMA_CLEAR_TX_TC(i);// 清除标记位
            LL_DMA_DisableStream(g_uartStruct[i-1].DMAx, UART_DMA_STREAM[i-1][1]);
            UART_TX_DMA_BUSY[i-1] = 0;
        }
        if(LL_DMA_IS_TX_TE(i)){
            LL_DMA_CLEAR_TX_TE(i);
            UART_TX_DMA_BUSY[i-1] = 0;
        }
    }
}
//extern QueueInfo g_queueInfo[QUEUE_MAX];
void UART_IRQHandler(void)
{
    for (uint8_t id = 1; id <= 6; id++)
    {
        if (g_uartStruct[id - 1].UARTx == NULL)
            continue;
        // 判断是否发生空闲中断，如果进入空闲中断，则可从DMA读取数据
        if (LL_USART_IsActiveFlag_IDLE(g_uartStruct[id - 1].UARTx))
        {
            // 关闭DMA，防止新数据覆盖
            LL_DMA_DisableStream(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX]);
            // 清空标记位
            LL_USART_ClearFlag_IDLE(g_uartStruct[id - 1].UARTx);
            // 读数据,DMA将数据存储到缓冲区 g_uartRxBuffer1
            int len = UART_DMA_LEN[id - 1][RX] - LL_DMA_GetDataLength(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX]);
            for (int j = 0; j < len; j++)
            {
                QueueIn(g_uartStruct[id - 1].queue_id, &UART_DMA_BUF[id - 1][RX][j]);
            }
            // 重启DMA
            LL_DMA_SetDataLength(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX], UART_DMA_LEN[id - 1][RX]);
            LL_DMA_EnableStream(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX]);
        }
    }
}

/****************************************** get dma interrupt flag ****************************************************/
uint8_t LL_DMA_IS_RX_TC(uint8_t id)
{
    switch (id)
    {
    case 1:
        return LL_DMA_IsActiveFlag_TC5(g_uartStruct[id - 1].DMAx);
    case 2:
        return LL_DMA_IsActiveFlag_TC5(g_uartStruct[id - 1].DMAx);
    case 3:
        return LL_DMA_IsActiveFlag_TC1(g_uartStruct[id - 1].DMAx);
    case 4:
        return LL_DMA_IsActiveFlag_TC2(g_uartStruct[id - 1].DMAx);
    case 5:
        return LL_DMA_IsActiveFlag_TC0(g_uartStruct[id - 1].DMAx);
    case 6:
        return LL_DMA_IsActiveFlag_TC2(g_uartStruct[id - 1].DMAx);
    }
}
uint8_t LL_DMA_IS_RX_TE(uint8_t id)
{
    switch (id)
    {
    case 1:
        return LL_DMA_IsActiveFlag_TE5(g_uartStruct[id - 1].DMAx);
    case 2:
        return LL_DMA_IsActiveFlag_TE5(g_uartStruct[id - 1].DMAx);
    case 3:
        return LL_DMA_IsActiveFlag_TE1(g_uartStruct[id - 1].DMAx);
    case 4:
        return LL_DMA_IsActiveFlag_TE2(g_uartStruct[id - 1].DMAx);
    case 5:
        return LL_DMA_IsActiveFlag_TE0(g_uartStruct[id - 1].DMAx);
    case 6:
        return LL_DMA_IsActiveFlag_TE2(g_uartStruct[id - 1].DMAx);
    }
}
uint8_t LL_DMA_IS_TX_TC(uint8_t id)
{
    switch (id)
    {
    case 1:
        return LL_DMA_IsActiveFlag_TC7(g_uartStruct[id - 1].DMAx);
    case 2:
        return LL_DMA_IsActiveFlag_TC6(g_uartStruct[id - 1].DMAx);
    case 3:
        return LL_DMA_IsActiveFlag_TC3(g_uartStruct[id - 1].DMAx);
    case 4:
        return LL_DMA_IsActiveFlag_TC4(g_uartStruct[id - 1].DMAx);
    case 5:
        return LL_DMA_IsActiveFlag_TC7(g_uartStruct[id - 1].DMAx);
    case 6:
        return LL_DMA_IsActiveFlag_TC6(g_uartStruct[id - 1].DMAx);
    }
}
uint8_t LL_DMA_IS_TX_TE(uint8_t id)
{
    switch (id)
    {
    case 1:
        return LL_DMA_IsActiveFlag_TE7(g_uartStruct[id - 1].DMAx);
    case 2:
        return LL_DMA_IsActiveFlag_TE6(g_uartStruct[id - 1].DMAx);
    case 3:
        return LL_DMA_IsActiveFlag_TE3(g_uartStruct[id - 1].DMAx);
    case 4:
        return LL_DMA_IsActiveFlag_TE4(g_uartStruct[id - 1].DMAx);
    case 5:
        return LL_DMA_IsActiveFlag_TE7(g_uartStruct[id - 1].DMAx);
    case 6:
        return LL_DMA_IsActiveFlag_TE6(g_uartStruct[id - 1].DMAx);
    }
}
/****************************************** clear dma interrupt flag ****************************************************/
void LL_DMA_CLEAR_RX_TC(uint8_t id)
{
    switch (id)
    {
    case 1:
        LL_DMA_ClearFlag_TC5(g_uartStruct[id - 1].DMAx);
        break;
    case 2:
        LL_DMA_ClearFlag_TC5(g_uartStruct[id - 1].DMAx);
        break;
    case 3:
        LL_DMA_ClearFlag_TC1(g_uartStruct[id - 1].DMAx);
        break;
    case 4:
        LL_DMA_ClearFlag_TC2(g_uartStruct[id - 1].DMAx);
        break;
    case 5:
        LL_DMA_ClearFlag_TC0(g_uartStruct[id - 1].DMAx);
        break;
    case 6:
        LL_DMA_ClearFlag_TC2(g_uartStruct[id - 1].DMAx);
        break;
    }
}
void LL_DMA_CLEAR_RX_TE(uint8_t id)
{
    switch (id)
    {
    case 1:
        LL_DMA_ClearFlag_TE5(g_uartStruct[id - 1].DMAx);
        break;
    case 2:
        LL_DMA_ClearFlag_TE5(g_uartStruct[id - 1].DMAx);
        break;
    case 3:
        LL_DMA_ClearFlag_TE1(g_uartStruct[id - 1].DMAx);
        break;
    case 4:
        LL_DMA_ClearFlag_TE2(g_uartStruct[id - 1].DMAx);
        break;
    case 5:
        LL_DMA_ClearFlag_TE0(g_uartStruct[id - 1].DMAx);
        break;
    case 6:
        LL_DMA_ClearFlag_TE2(g_uartStruct[id - 1].DMAx);
        break;
    }
}
void LL_DMA_CLEAR_TX_TC(uint8_t id)
{
    switch (id)
    {
    case 1:
        LL_DMA_ClearFlag_TC7(g_uartStruct[id - 1].DMAx);
        break;
    case 2:
        LL_DMA_ClearFlag_TC6(g_uartStruct[id - 1].DMAx);
        break;
    case 3:
        LL_DMA_ClearFlag_TC3(g_uartStruct[id - 1].DMAx);
        break;
    case 4:
        LL_DMA_ClearFlag_TC4(g_uartStruct[id - 1].DMAx);
        break;
    case 5:
        LL_DMA_ClearFlag_TC7(g_uartStruct[id - 1].DMAx);
        break;
    case 6:
        LL_DMA_ClearFlag_TC6(g_uartStruct[id - 1].DMAx);
        break;
    }
}
void LL_DMA_CLEAR_TX_TE(uint8_t id)
{
    switch (id)
    {
    case 1:
        LL_DMA_ClearFlag_TE7(g_uartStruct[id - 1].DMAx);
        break;
    case 2:
        LL_DMA_ClearFlag_TE6(g_uartStruct[id - 1].DMAx);
        break;
    case 3:
        LL_DMA_ClearFlag_TE3(g_uartStruct[id - 1].DMAx);
        break;
    case 4:
        LL_DMA_ClearFlag_TE4(g_uartStruct[id - 1].DMAx);
        break;
    case 5:
        LL_DMA_ClearFlag_TE7(g_uartStruct[id - 1].DMAx);
        break;
    case 6:
        LL_DMA_ClearFlag_TE6(g_uartStruct[id - 1].DMAx);
        break;
    }
}
void LL_UART_CLEAR_FLAG()
{
    for (int id = 1; id <= 6; id++)
    {
        if (g_uartStruct[id - 1].UARTx == NULL)
            continue;
        LL_USART_ClearFlag_IDLE(g_uartStruct[id - 1].UARTx);
        LL_DMA_CLEAR_RX_TC(id);
        LL_DMA_CLEAR_RX_TE(id);
        LL_DMA_CLEAR_TX_TC(id);
        LL_DMA_CLEAR_TX_TE(id);
    }
}

/*****************dma 初始化***********************/
void LL_UART_DMA_Init(uint8_t id)
{
    // get DMAx
    g_uartStruct[id - 1].DMAx = LL_GET_UART_DMAX(id);
    // clear all falg
    LL_UART_CLEAR_FLAG();
    // enable dma clock
    LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_DMA2);
    LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_DMA1);
    // 设置缓冲区大小
    LL_DMA_SetDataLength(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX], UART_DMA_LEN[id - 1][RX]);
    LL_DMA_ConfigAddresses(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX], (uint32_t)LL_USART_DMA_GetRegAddr(g_uartStruct[id - 1].UARTx), UART_DMA_BUF[id - 1][RX], LL_DMA_DIRECTION_PERIPH_TO_MEMORY);
    // DMA通道选择
    LL_DMA_SetChannelSelection(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX], UART_DMA_CHANNEL[id - 1]);
    // DMA传输方向
    LL_DMA_SetDataTransferDirection(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX], LL_DMA_DIRECTION_PERIPH_TO_MEMORY);
    // DMA传输级别
    LL_DMA_SetStreamPriorityLevel(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX], LL_DMA_PRIORITY_VERYHIGH);
    // DMA循环模式
    LL_DMA_SetMode(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX], LL_DMA_MODE_CIRCULAR);
    // DMA地址增长方式
    LL_DMA_SetPeriphIncMode(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX], LL_DMA_PERIPH_NOINCREMENT);
    LL_DMA_SetMemoryIncMode(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX], LL_DMA_MEMORY_INCREMENT);
    // DMA增长长度
    LL_DMA_SetPeriphSize(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX], LL_DMA_PDATAALIGN_BYTE);
    LL_DMA_SetMemorySize(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX], LL_DMA_MDATAALIGN_BYTE);
    // 禁用DMA FIFO
    LL_DMA_DisableFifoMode(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX]);
    // 配置DMA中断
    NVIC_SetVector(UART_DMA_IRQ[id - 1][RX], UART_RxDmaHandler);
    NVIC_SetPriority(UART_DMA_IRQ[id - 1][RX], NVIC_EncodePriority(NVIC_GetPriorityGrouping(), 0, 0));
    NVIC_EnableIRQ(UART_DMA_IRQ[id - 1][RX]);

    /* USART2_TX Init */
    LL_DMA_DisableStream(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX]);
    LL_DMA_SetPeriphAddress(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX], (uint32_t)&(g_uartStruct[id - 1].UARTx->DR));
    LL_DMA_SetDataTransferDirection(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX], LL_DMA_DIRECTION_MEMORY_TO_PERIPH);
    LL_DMA_SetStreamPriorityLevel(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX], LL_DMA_PRIORITY_HIGH);
    LL_DMA_SetMode(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX], LL_DMA_MODE_NORMAL);
    LL_DMA_SetPeriphIncMode(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX], LL_DMA_PERIPH_NOINCREMENT);
    LL_DMA_SetMemoryIncMode(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX], LL_DMA_MEMORY_INCREMENT);
    LL_DMA_SetPeriphSize(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX], LL_DMA_PDATAALIGN_BYTE);
    LL_DMA_SetMemorySize(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX], LL_DMA_MDATAALIGN_BYTE);
    LL_DMA_SetChannelSelection(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX], UART_DMA_CHANNEL[id - 1]);
    LL_DMA_DisableFifoMode(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX]);
    LL_USART_EnableDirectionTx(g_uartStruct[id - 1].UARTx);
    NVIC_SetVector(UART_DMA_IRQ[id - 1][TX], UART_TxDmaHandler);
    NVIC_SetPriority(UART_DMA_IRQ[id - 1][TX], NVIC_EncodePriority(NVIC_GetPriorityGrouping(), 0, 0));
    NVIC_EnableIRQ(UART_DMA_IRQ[id - 1][TX]);
    UART_TX_DMA_BUSY[id - 1] = 0;

    LL_USART_EnableDMAReq_RX(g_uartStruct[id - 1].UARTx);
    // 使能串口IDLE中断
    LL_USART_ClearFlag_IDLE(g_uartStruct[id - 1].UARTx);
    LL_USART_EnableIT_IDLE(g_uartStruct[id - 1].UARTx);
    // 打开DMA中断
    LL_DMA_EnableIT_TC(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX]);
    LL_DMA_EnableIT_TE(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX]);
    LL_DMA_EnableIT_TC(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX]);
    LL_DMA_EnableIT_TE(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX]);
    // 使能DMA通道
    LL_DMA_EnableStream(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX]);
    LL_DMA_EnableStream(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX]);
    NVIC_SetVector(UART_IRQn[id - 1], UART_IRQHandler);
    NVIC_SetPriority(UART_IRQn[id - 1], NVIC_EncodePriority(NVIC_GetPriorityGrouping(), 0, 1));
    NVIC_EnableIRQ(UART_IRQn[id - 1]);
}

void LL_UART_DMA_DeInit(uint8_t id){
     LL_DMA_DisableStream(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX]);
    LL_DMA_DisableStream(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX]);
    NVIC_DisableIRQ(UART_DMA_IRQ[id - 1][RX]);
    NVIC_DisableIRQ(UART_DMA_IRQ[id - 1][TX]);
    LL_DMA_DisableIT_TC(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][RX]);
    LL_DMA_DisableIT_TE(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX]);
}
/****************写数据****************/
int UartWriteDMA(unsigned int id, const unsigned char *data, unsigned int dataLen, uint8_t sec)
{
    // 等待发送完成，这个标志会在中断清零
    while (UART_TX_DMA_BUSY[id - 1])
        ;
    // 设置忙标记
    UART_TX_DMA_BUSY[id - 1] = 1;
    // 关闭通道
    LL_DMA_DisableStream(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX]);
    // 复制数据
    memcpy(UART_DMA_BUF[id - 1][TX], data, dataLen);
    // 设置内存
    LL_DMA_SetMemoryAddress(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX], UART_DMA_BUF[id - 1][TX]);
    // 设置长度
    LL_DMA_SetDataLength(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX], dataLen);
    // 开启发送请求
    LL_USART_EnableDMAReq_TX(g_uartStruct[id - 1].UARTx);
    // 打开通道
    LL_DMA_EnableStream(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX]);
    // 等待发送完成
    uint64_t start_tick, end_tick;
    start_tick = LL_GetTick();
    while (UART_TX_DMA_BUSY[id - 1])
    {
        end_tick = LL_GetTick();
        if (end_tick - start_tick > sec*1000)
        {
            UART_TX_DMA_BUSY[id - 1] = 0;
            break;
        }
    }
    //printf("dma tx %d\n", dataLen);
    return dataLen - LL_DMA_GetDataLength(g_uartStruct[id - 1].DMAx, UART_DMA_STREAM[id - 1][TX]);
}