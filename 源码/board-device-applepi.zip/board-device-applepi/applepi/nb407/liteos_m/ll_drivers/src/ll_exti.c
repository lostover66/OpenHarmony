#include "ll_exti.h"
#include "stm32f4xx_ll_exti.h"
#include "stm32f4xx_ll_system.h"
#include "ll_gpio.h"

static uint32_t g_sysCfgExtiLine[16]={
    LL_SYSCFG_EXTI_LINE0,
    LL_SYSCFG_EXTI_LINE1,
    LL_SYSCFG_EXTI_LINE2,
    LL_SYSCFG_EXTI_LINE3,
    LL_SYSCFG_EXTI_LINE4,
    LL_SYSCFG_EXTI_LINE5,
    LL_SYSCFG_EXTI_LINE6,
    LL_SYSCFG_EXTI_LINE7,
    LL_SYSCFG_EXTI_LINE8,
    LL_SYSCFG_EXTI_LINE9,
    LL_SYSCFG_EXTI_LINE10,
    LL_SYSCFG_EXTI_LINE11,
    LL_SYSCFG_EXTI_LINE12,
    LL_SYSCFG_EXTI_LINE13,
    LL_SYSCFG_EXTI_LINE14,
    LL_SYSCFG_EXTI_LINE15,
};
extern PIN_ST g_pinsGroup[STM32_GPIO_GROUP_MAX*STM32_GPIO_PIN_MAX];

static void LL_GPIO_EXTI_HANDLER(){
    // 遍历所有引脚
    for(uint16_t idx=0; idx<STM32_GPIO_GROUP_MAX*STM32_GPIO_PIN_MAX; idx++){
        // 查看是否允许中断，是，转发中断处理
        if(g_pinsGroup[idx].extiStruct.LineCommand==ENABLE){
            ITStatus status;
            // 查看中断方式
            if(g_pinsGroup[idx].extiStruct.Trigger==LL_EXTI_TRIGGER_RISING)
                status = SET;
            else
                status = RESET;
            // 判断标记位，如果有则清空
            if(LL_EXTI_IsActiveFlag_0_31(g_pinsGroup[idx].extiStruct.Line_0_31)){
                LL_EXTI_ClearFlag_0_31(g_pinsGroup[idx].extiStruct.Line_0_31);
                // 按钮消抖. 滤波，去毛刺
                delay_us(100);
                // 判断最终电平
                if(LL_GPIO_IsInputPinSet(LL_GET_GPIOX(idx), LL_GET_GPIO_PIN(idx))==status){
                    // 进入自定义中断
                    g_pinsGroup[idx].handler(idx);
                    break;
                }
            }
        }
    }
}

uint32_t LL_SETUP_EXTI(uint16_t id, LL_EXTI_InitTypeDef cfg,\
    LL_EXTI_HANDLER handler
){
    // 打开syscfg时钟
    LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_SYSCFG);
    // 配置外部中断线
    LL_SYSCFG_SetEXTISource(id/16, g_sysCfgExtiLine[id%16]);
    // 初始化外部中断结构
    g_pinsGroup[id].extiStruct.Line_0_31 = cfg.Line_0_31;
    g_pinsGroup[id].extiStruct.LineCommand = cfg.LineCommand;
    g_pinsGroup[id].extiStruct.Trigger = cfg.Trigger;
    g_pinsGroup[id].extiStruct.Mode = cfg.Mode;
    g_pinsGroup[id].handler = handler;
    // LL_EXTI_Init
    if(LL_EXTI_Init(&cfg)==ERROR){
        printf("%s line %d LL_EXTI_Init error\n", __func__, __LINE__);
        return ERROR;
    }
    // 使能中断
    // 中断优先级
    uint8_t group = id/16;
    uint8_t pin = id%16;
    if(pin<=4){
        NVIC_SetVector(EXTI0_IRQn+pin, (uint32_t)LL_GPIO_EXTI_HANDLER);
        NVIC_SetPriority(EXTI0_IRQn+pin, 0);
        NVIC_EnableIRQ(EXTI0_IRQn+pin);
    }else if(pin>=5 && pin<=9){
        NVIC_SetVector(EXTI9_5_IRQn,  (uint32_t)LL_GPIO_EXTI_HANDLER);
        NVIC_SetPriority(EXTI9_5_IRQn, 0);
        NVIC_EnableIRQ(EXTI9_5_IRQn);
    }else if(pin>=10 && pin<=15){
        NVIC_SetVector(EXTI15_10_IRQn,  (uint32_t)LL_GPIO_EXTI_HANDLER);
        NVIC_SetPriority(EXTI15_10_IRQn, 0);
        NVIC_EnableIRQ(EXTI15_10_IRQn);
    }
    return SUCCESS;
}