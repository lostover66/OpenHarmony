// device/board/applepi/stm32f407_atk/liteos_m/ll_drivers/src/ll_pwm.c
/*************************************************************************************************
            Tabel PWM-Pin about stm32f407 pwm channel and pins
┏━━━━━━━━━━━━━━━━┯━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┯━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┯━━━━━━━━━┓
┃                ┃        Positive output           ┃          negative output          ┃         ┃
┠━━━━━━━━━━━━━━━━┼━━━━━━━━━━━┯━━━━━━━━━━┯━━━━━━━━━━━┼━━━━━━━━━━━┯━━━━━━━━━━━┯━━━━━━━━━━━┼         ┃
┃   channel      ┃   pin     ┃  pin     ┃   pin     ┃   pin     ┃   pin     ┃   pin     ┃         ┃
┠━━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━┨
┃   TIM1_CH1     ┃   PA8     |  PE9     |           ┃   PA7     |   PB13    |   PE8     ┃  AF_1   ┃
┃   TIM1_CH2     ┃   PA9     |  PE11    |           ┃   PB0     |   PB14    |   PE10    ┃         ┃
┃   TIM1_CH3     ┃   PA10    |  PE13    |           ┃   PB1     |   PB15    |   PE12    ┃         ┃
┃   TIM1_CH4     ┃   PA11    |  PE14    |           ┃           |           |           ┃         ┃
┠━━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━┨
┃   TIM2_CH2     ┃   PA1     |  PB3     |           ┃           |           |           ┃  AF_1   ┃
┃   TIM2_CH3     ┃   PA2     |  PB10    |           ┃           |           |           ┃         ┃
┃   TIM2_CH4     ┃   PA3     |  PB11    |           ┃           |           |           ┃         ┃
┠━━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━┨
┃   TIM3_CH1     ┃   PA6     |  PB4     |   PC6     ┃           |           |           ┃  AF_2   ┃
┃   TIM3_CH2     ┃   PA7     |  PB5     |   PC7     ┃           |           |           ┃         ┃
┃   TIM3_CH3     ┃   PB0     |  PC8     |           ┃           |           |           ┃         ┃
┃   TIM3_CH4     ┃   PB1     |  PC9     |           ┃           |           |           ┃         ┃
┠━━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━┨
┃   TIM4_CH1     ┃   PB6     |  PD12    |           ┃           |           |           ┃  AF_2   ┃
┃   TIM4_CH2     ┃   PB7     |  PD13    |           ┃           |           |           ┃         ┃
┃   TIM4_CH3     ┃   PB8     |  PD14    |           ┃           |           |           ┃         ┃
┃   TIM4_CH4     ┃   PB9     |  PD15    |           ┃           |           |           ┃         ┃
┠━━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━┨
┃   TIM5_CH1     ┃   PH10    |          |           ┃           |           |           ┃  AF_2   ┃
┃   TIM5_CH2     ┃   PA1     |  PH11    |           ┃           |           |           ┃         ┃
┃   TIM5_CH3     ┃   PA2     |  PH12    |           ┃           |           |           ┃         ┃
┃   TIM5_CH4     ┃   PA3     |  PI0     |           ┃           |           |           ┃         ┃
┠━━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┨━━━━━━━━━┨
┃   TIM8_CH1     ┃   PC6     |  PI5     |           ┃   PA5     |   PA7     |   PH13    ┃  AF_3   ┃
┃   TIM8_CH2     ┃   PC7     |  PI6     |           ┃   PB0     |   PB14    |   PH14    ┃         ┃
┃   TIM8_CH3     ┃   PC8     |  PI7     |           ┃   PB1     |   PB15    |   PH15    ┃         ┃
┃   TIM8_CH4     ┃   PC9     |  PI2     |           ┃           |           |           ┃         ┃
┠━━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━┨
┃   TIM9_CH1     ┃   PA2     |  PE5     |           ┃           |           |           ┃  AF_3   ┃
┃   TIM9_CH2     ┃   PA3     |  PE6     |           ┃           |           |           ┃         ┃
┠━━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━┨
┃   TIM10_CH1    ┃   PB8     |  PF6     |           ┃           |           |           ┃  AF_3   ┃
┃   TIM10_CH2    ┃           |          |           ┃           |           |           ┃         ┃
┃   TIM10_CH3    ┃           |          |           ┃           |           |           ┃         ┃
┃   TIM10_CH4    ┃           |          |           ┃           |           |           ┃         ┃
┠━━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━┨
┃   TIM11_CH1    ┃   PB9     |  PF7     |           ┃           |           |           ┃  AF_3   ┃
┃   TIM11_CH2    ┃           |          |           ┃           |           |           ┃         ┃
┃   TIM11_CH3    ┃           |          |           ┃           |           |           ┃         ┃
┃   TIM11_CH4    ┃           |          |           ┃           |           |           ┃         ┃
┠━━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━┨
┃   TIM12_CH1    ┃   PB14    |  PH6     |           ┃           |           |           ┃  AF_9   ┃
┃   TIM12_CH2    ┃   PB15    |  PH9     |           ┃           |           |           ┃         ┃
┃   TIM12_CH3    ┃           |          |           ┃           |           |           ┃         ┃
┃   TIM12_CH4    ┃           |          |           ┃           |           |           ┃         ┃
┠━━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━┨
┃   TIM13_CH1    ┃   PA6     |  PF8     |           ┃           |           |           ┃  AF_9   ┃
┃   TIM13_CH2    ┃           |          |           ┃           |           |           ┃         ┃
┃   TIM13_CH3    ┃           |          |           ┃           |           |           ┃         ┃
┃   TIM13_CH4    ┃           |          |           ┃           |           |           ┃         ┃
┠━━━━━━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━━━┼━━━━━━━━━┨
┃   TIM14_CH1    ┃   PA7     |  PF9     |           ┃           |           |           ┃  AF_9   ┃
┃   TIM14_CH2    ┃           |          |           ┃           |           |           ┃         ┃
┃   TIM14_CH3    ┃           |          |           ┃           |           |           ┃         ┃
┃   TIM14_CH4    ┃           |          |           ┃           |           |           ┃         ┃
┗━━━━━━━━━━━━━━━━┷━━━━━━━━━━━┷━━━━━━━━━━┷━━━━━━━━━━━┷━━━━━━━━━━━┷━━━━━━━━━━━┷━━━━━━━━━━━┷━━━━━━━━━┛
**************************************************************************************************/
#include "ll_pwm.h"
#include "ll_gpio.h"

PWM_ST g_pwmGroups[PWM_MAX];
extern PIN_ST g_pinsGroup[STM32_GPIO_GROUP_MAX * STM32_GPIO_PIN_MAX];

static TIM_TypeDef *g_TIMx[14] = {
    TIM1, TIM2, TIM3, TIM4, TIM5, TIM6,
    TIM7, TIM8, TIM9, TIM10, TIM11, TIM12,
    TIM13, TIM14};
// PWM对应的引脚
static uint16_t g_pwmPin[PWM_MAX] = {
    PA8, PA9, PA10, PA11,
    PA1, PA2, PA3,
    PA6, PA7, PB0, PB1,
    PD12, PD13, PB8, PB9,
    PA10, PA1, PA2, PA3,

    PC6, PC7, PC8, PC9,
    PA2, PA3,
    PB8,
    PB9,
    PB14, PB15,
    PA6,
    PA7};
// PWM对应的定时器id  1~14
static uint8_t g_pwmTimId[PWM_MAX] = {
    1, 1, 1, 1,
    2, 2, 2,
    3, 3, 3, 3,
    4, 4, 4, 4,
    5, 5, 5, 5,
    8, 8, 8, 8,
    9, 9,
    10,
    11,
    12, 12,
    13,
    14};
// PWM对应的定时器通道id 1~4
static uint8_t g_pwmChId[PWM_MAX] = {
    1, 2, 3, 4,
    2, 3, 4,
    1, 2, 3, 4,
    1, 2, 3, 4,
    1, 2, 3, 4,
    1, 2, 3, 4,
    1, 2,
    1,
    1,
    1, 2,
    1,
    1};

TIM_TypeDef *LL_GET_TIMx(uint16_t id)
{
    // 根据pwm_id(1~PWM_MAX)，查表得到tim_id
    uint8_t tim_id = g_pwmTimId[id - 1];
    // 根据tim_id得到TIM1~TIM14
    return g_TIMx[tim_id - 1];
}
uint32_t LL_GET_TIM_CH(uint16_t id)
{
    // 根据pwm_id(1~PWM_MAX)，查表得到ch_id
    uint8_t ch_id = g_pwmChId[id - 1];
    // 根据ch_id得到LL_TIM_CHANNEL_CH1
    switch (ch_id)
    {
    case 1:
        return LL_TIM_CHANNEL_CH1;
    case 2:
        return LL_TIM_CHANNEL_CH2;
    case 3:
        return LL_TIM_CHANNEL_CH3;
    case 4:
        return LL_TIM_CHANNEL_CH4;
    }
}
void LL_ENABLE_TIM_CLK(uint16_t id)
{
    // 根据pwm_id得到timx
    TIM_TypeDef *timx = LL_GET_TIMx(id);
    // 根据timx决定打开某一个时钟
    if (timx == TIM1)
        LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_TIM1);
    else if (timx == TIM2)
        LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM2);
    else if (timx == TIM3)
        LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM3);
    else if (timx == TIM4)
        LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM4);
    else if (timx == TIM5)
        LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM5);
    else if (timx == TIM8)
        LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_TIM8);
    else if (timx == TIM9)
        LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_TIM9);
    else if (timx == TIM10)
        LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_TIM10);
    else if (timx == TIM11)
        LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_TIM11);
    else if (timx == TIM12)
        LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM12);
    else if (timx == TIM13)
        LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM13);
    else if (timx == TIM14)
        LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM14);
}
uint8_t LL_CONFIG_TIM_PIN(uint16_t id){
    // 记录TIMx\ch\realPin
    g_pwmGroups[id-1].TIMx = LL_GET_TIMx(id);
    g_pwmGroups[id-1].ch = LL_GET_TIM_CH(id);
    g_pwmGroups[id-1].realPin = g_pwmPin[id-1];
    // 根据timx得到AF_X
    uint32_t LL_GPIO_AF_X;
    if(g_pwmGroups[id-1].TIMx == TIM1 || \
        g_pwmGroups[id-1].TIMx == TIM2)
        LL_GPIO_AF_X = LL_GPIO_AF_1;
    else if(g_pwmGroups[id-1].TIMx == TIM3 || \
        g_pwmGroups[id-1].TIMx == TIM4 || \
        g_pwmGroups[id-1].TIMx == TIM5)
        LL_GPIO_AF_X = LL_GPIO_AF_2;
    else if(g_pwmGroups[id-1].TIMx == TIM8 || \
        g_pwmGroups[id-1].TIMx == TIM9 || \
        g_pwmGroups[id-1].TIMx == TIM10 || \
        g_pwmGroups[id-1].TIMx == TIM11)
        LL_GPIO_AF_X = LL_GPIO_AF_3;
    else if(g_pwmGroups[id-1].TIMx == TIM12 || \
        g_pwmGroups[id-1].TIMx == TIM13 || \
        g_pwmGroups[id-1].TIMx == TIM14)
        LL_GPIO_AF_X = LL_GPIO_AF_9;
    // 配置引脚为定时器的pwm模式,给结构体赋值
    LL_CONFIG_GPIO(g_pwmGroups[id-1].realPin,\
        LL_GPIO_MODE_ALTERNATE,
        LL_GPIO_PULL_NO,
        LL_GPIO_SPEED_FREQ_VERY_HIGH,
        LL_GPIO_OUTPUT_PUSHPULL,
        LL_GPIO_AF_X
        );
    // 打开gpio时钟
    uint8_t group = g_pwmGroups[id-1].realPin/16;
    uint8_t pin = g_pwmGroups[id-1].realPin%16;
    LL_AHB1_GRP1_EnableClock(LL_GET_GPIO_CLK(group));
    // 初始化引脚
    int res = LL_GPIO_Init(LL_GET_GPIOX(g_pwmGroups[id-1].realPin), \
        &g_pinsGroup[g_pwmGroups[id-1].realPin].gpioStruct);
    if(res == ERROR){
        printf("%s line %d, LL_GPIO_Init failed\n", __func__, __LINE__);
    }
    return res;
}

uint8_t LL_CAL_TIM_PARAMS(uint32_t rcc, uint8_t duty, uint32_t freq, \
    uint16_t *pre_div, uint32_t *auto_reload, uint32_t *oc_val){
    // duty/100 = (oc_val+1)/(auto_reload+1)
    // rcc/(pre_div+1) = freq*(auto_reload+1)
    // 两个等式，三个未知数；假设已经某一个未知数，利用for求另外两个
    // 假设oc_val已知
    if(duty==0){
        *oc_val = 0;
        *auto_reload = 1000;
        *pre_div = rcc/(freq*((*auto_reload)+1))-1;
        return SUCCESS;
    }
    uint16_t i;
    for(i=0xffff; i>0; i--){
        uint32_t j = (i+1)*100/duty-1;
        if(j<=0xffff){ // auto_reload<=65535
            if((j+1)*duty == (i+1)*100){ // 确保j是整数
                uint16_t k = rcc/(freq*(j+1))-1;
                if(k<=0xffff){ // pre_div<=65535
                    if((k+1)*(freq*(j+1)) == rcc){ // 确保k是整数
                        *oc_val = i;
                        *auto_reload = j;
                        *pre_div = k;
                        printf("oc=%d auto=%d prv=%d\n", i, j, k);
                        return SUCCESS;
                    }
                }
            }
        }
    }
    printf("cal pwm param fail\n");
    return ERROR;
}