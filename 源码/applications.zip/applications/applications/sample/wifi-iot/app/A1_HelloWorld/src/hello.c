#include "hello.h"

void print_hello(){
    printf("Hello weijie\n");
}