#ifndef __HELLO_H
#define __HELLO_H

#ifdef __cplusplus
extern "C" {
#endif

// 用户代码区
#include "stdio.h"
void print_hello();

#ifdef __cplusplus
}
#endif

#endif