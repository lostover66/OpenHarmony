#include "task.h"
#include "cmsis_os2.h"
#include "stdint.h"
osThreadId_t tid1,tid2;
void task1_entry(){
    while(1){
        printf("I'm weijie, running task1...\n");
        osThreadResume(tid2); // 恢复任务2
        osThreadSuspend(tid1);// 挂起任务1
        osDelay(1000*1);// 延时1000tick,默认1tick=1ms
    } 
}
void task2_entry(){
    while(1){
        printf("I'm weijie, running task2...\n");
        osDelay(1000*1);
        osThreadResume(tid1);
        osThreadSuspend(tid2);
    } 
}
void task_demo_cmsis(){
    osThreadAttr_t attr;
    attr.name = "task2";
    attr.priority = 10;
    attr.stack_size = 0x100*16;
    tid2 = osThreadNew(task2_entry, NULL, &attr);
    if(tid2 == NULL){
        printf("create task2 failed\n");
        return;
    }
    attr.name = "task1";
    attr.priority = 10;
    attr.stack_size = 0x100*16;
    tid1 = osThreadNew(task1_entry, NULL, &attr);
    if(tid1 == NULL){
        printf("create task1 failed\n");
        return;
    }
    
}