#ifndef __TASK_CMSIS_H
#define __TASK_CMSIS_H

#ifdef __cplusplus
extern "C" {
#endif

// 用户代码区
#include "stdio.h"
void task_demo_cmsis();

#ifdef __cplusplus
}
#endif

#endif