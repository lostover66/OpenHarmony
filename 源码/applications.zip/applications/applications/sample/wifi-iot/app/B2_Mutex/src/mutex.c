#include "mutex.h"
#include "los_task.h"
#include "los_sem.h"
#include "los_mux.h"
#include "stdint.h"
uint32_t tid_p1,tid_p2,tid_c;
uint32_t sem;
uint32_t mutex_read, mutex_write;
uint8_t buf_src[100], buf_dst[100]={0};
uint8_t p_pos_read=0, p_pos_write=0;
uint8_t c_pos_read=0;
static void producer1_entry(){
    // buf_dst[pos++]=buf_src[pos++]
    // 找到src read 位置
    // 加锁
    // 拿数据
    // 找到 dst write位置
    // 写数据
    // 解锁
    // 释放信号，通知customer数据量增加
    while(1){
        LOS_MuxPend(mutex_read, LOS_WAIT_FOREVER);//对读位置加上
        printf("p1 get read pos, begin read src\n");
        if(p_pos_read<100){
            LOS_MuxPend(mutex_write, LOS_WAIT_FOREVER);//对dst位置加锁
            buf_dst[p_pos_write]=buf_src[p_pos_read];//复制数据
            p_pos_write += 1;//位置＋1
            LOS_SemPost(sem);//释放信号，通知消费者有数据
            LOS_MuxPost(mutex_write);//释放dst写位置
            p_pos_read += 1;//src位置＋1
            LOS_MuxPost(mutex_read);//释放src 读位置
        }else{
            printf("p1 read over\n");
            LOS_MuxPost(mutex_read);
            break;
        }
        LOS_TaskDelay(1000);
    }
}
static void producer2_entry(){
    while(1){
        LOS_MuxPend(mutex_read, LOS_WAIT_FOREVER);//对读位置加上
        printf("p2 get read pos, begin read src\n");
        if(p_pos_read<100){
            LOS_MuxPend(mutex_write, LOS_WAIT_FOREVER);//对dst位置加锁
            buf_dst[p_pos_write]=buf_src[p_pos_read];//复制数据
            p_pos_write += 1;//位置＋1
            LOS_SemPost(sem);//释放信号，通知消费者有数据
            LOS_MuxPost(mutex_write);//释放dst写位置
            p_pos_read += 1;//src位置＋1
            LOS_MuxPost(mutex_read);//释放src 读位置
        }else{
            printf("p1 read over\n");
            LOS_MuxPost(mutex_read);
            break;
        }
        LOS_TaskDelay(1000);
    }
    LOS_MuxDelete(mutex_read);//删除锁，释放内存
    LOS_MuxDelete(mutex_write);
}

static void customer_entry(){
    while(1){
        printf("c try get sem\n");
        uint32_t ret = LOS_SemPend(sem, 0xff);
        if(ret==LOS_OK){
            printf("c get sem ok, dst is %d\n",\
                buf_dst[c_pos_read++]);
        }
        if(c_pos_read>=100)
            break;
    }
    LOS_SemDelete(sem);
}

void mutex_demo(){
    for(uint8_t i=0; i<100; i++)
        buf_src[i] = i+1;  //1~100
    uint32_t res;
    res=LOS_SemCreate(0, &sem);
    if(res!=LOS_OK){
        printf("create sem failed, errno=%x\n", res);
        return;
    }
    res=LOS_MuxCreate(&mutex_read);
    if(res!=LOS_OK){
        printf("create mux_read failed, errno=%x\n", res);
        return;
    }
    res=LOS_MuxCreate(&mutex_write);
    if(res!=LOS_OK){
        printf("create mux_write failed, errno=%x\n", res);
        return;
    }
    TSK_INIT_PARAM_S param;
    param.pcName = "task_p1";
    param.usTaskPrio = 10;
    param.uwStackSize = 0x100*16;
    param.pfnTaskEntry = producer1_entry;
    uint32_t ret = LOS_TaskCreate(&tid_p1, &param);
    if(ret != LOS_OK){
        printf("create task_p1 failed, errno=%x\n",ret);
        return;
    }
    param.pcName = "task_p2";
    param.usTaskPrio = 10;
    param.uwStackSize = 0x100*16;
    param.pfnTaskEntry = producer2_entry;
    ret = LOS_TaskCreate(&tid_p2, &param);
    if(ret != LOS_OK){
        printf("create task_p2 failed, errno=%x\n",ret);
        return;
    }
    param.pcName = "task_c";
    param.usTaskPrio = 10;
    param.uwStackSize = 0x100*16;
    param.pfnTaskEntry = customer_entry;
    ret = LOS_TaskCreate(&tid_c, &param);
    if(ret != LOS_OK){
        printf("create task_c failed, errno=%x\n",ret);
        return;
    }
}