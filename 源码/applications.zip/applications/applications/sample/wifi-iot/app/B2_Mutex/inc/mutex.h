#ifndef __MUTEX_H
#define __MUTEX_H

#ifdef __cplusplus
extern "C" {
#endif

// 用户代码区
#include "stdio.h"
void mutex_demo();

#ifdef __cplusplus
}
#endif

#endif