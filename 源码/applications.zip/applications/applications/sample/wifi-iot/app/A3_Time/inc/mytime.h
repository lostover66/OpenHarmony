#ifndef __MYTIME_H
#define __MYTIME_H

#ifdef __cplusplus
extern "C" {
#endif

// 用户代码区
#include "stdio.h"
void time_demo();

#ifdef __cplusplus
}
#endif

#endif