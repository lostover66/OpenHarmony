#include "mytime.h"
#include "los_task.h"
#include "los_tick.h"
#include "stdint.h"
uint32_t tid1;
void task1_entry(){
    printf("I'm weijie\n");
    uint32_t ms=LOS_Tick2MS(1000);
    printf("1000 tick ---> %d ms\n",ms);
    uint32_t tick=LOS_MS2Tick(500);
    printf("500 ms ---> %d tick\n",tick);
    uint64_t ns = LOS_CurrNanosec();
    printf("开机到目前经历 %d 毫秒\n", ns/1000000);
}

void time_demo(){
    
    TSK_INIT_PARAM_S param;
    param.pcName = "task1";
    param.usTaskPrio = 10;
    param.uwStackSize = 0x100*16;
    param.pfnTaskEntry = task1_entry;
    uint32_t ret = LOS_TaskCreate(&tid1, &param);
    if(ret != LOS_OK){
        printf("create task1 failed, errno=%x\n",ret);
        return;
    }
}