#include "sem.h"
#include "los_task.h"
#include "los_sem.h"
#include "stdint.h"
uint32_t tid_p1,tid_p2,tid_p3, tid_c, sem;

static void producer1_entry(){
    while(1){
        uint32_t ret = LOS_SemPost(sem);
        if(ret == LOS_OK){
            printf("I'm weijie, p1 put data ok\n");
        }
        LOS_TaskDelay(5000);
    }
}
static void producer2_entry(){
    while(1){
        uint32_t ret = LOS_SemPost(sem);
        if(ret == LOS_OK){
            printf("I'm weijie, p2 put data ok\n");
        }
        LOS_TaskDelay(5000);
    }
}
static void producer3_entry(){
    while(1){
        uint32_t ret = LOS_SemPost(sem);
        if(ret == LOS_OK){
            printf("I'm weijie, p3 put data ok\n");
        }
        LOS_TaskDelay(5000);
    }
}
static void customer_entry(){
    while(1){
        uint32_t ret = LOS_SemPend(sem, 0xff);
        if(ret == LOS_OK){
            printf("I'm weijie, c get data ok\n");
        }
        LOS_TaskDelay(1000);
    }
}

void sem_demo(){
    LOS_SemCreate(0, &sem);
    TSK_INIT_PARAM_S param;
    param.pcName = "task_p1";
    param.usTaskPrio = 10;
    param.uwStackSize = 0x100*16;
    param.pfnTaskEntry = producer1_entry;
    uint32_t ret = LOS_TaskCreate(&tid_p1, &param);
    if(ret != LOS_OK){
        printf("create task_p1 failed, errno=%x\n",ret);
        return;
    }
    param.pcName = "task_p2";
    param.usTaskPrio = 10;
    param.uwStackSize = 0x100*16;
    param.pfnTaskEntry = producer2_entry;
    ret = LOS_TaskCreate(&tid_p2, &param);
    if(ret != LOS_OK){
        printf("create task_p2 failed, errno=%x\n",ret);
        return;
    }
    param.pcName = "task_p3";
    param.usTaskPrio = 10;
    param.uwStackSize = 0x100*16;
    param.pfnTaskEntry = producer3_entry;
    ret = LOS_TaskCreate(&tid_p3, &param);
    if(ret != LOS_OK){
        printf("create task_p3 failed, errno=%x\n",ret);
        return;
    }
    param.pcName = "task_c";
    param.usTaskPrio = 10;
    param.uwStackSize = 0x100*16;
    param.pfnTaskEntry = customer_entry;
    ret = LOS_TaskCreate(&tid_c, &param);
    if(ret != LOS_OK){
        printf("create task_c failed, errno=%x\n",ret);
        return;
    }
}
