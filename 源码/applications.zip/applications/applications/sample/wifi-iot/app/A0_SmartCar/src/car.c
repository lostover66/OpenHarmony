#include "car.h"
#include "los_task.h"
#include "los_sem.h"
#include "led.h"
#include "relay.h"
#include "key.h"
#include "iot_gpio.h"
#include "motor.h"
#include "iot_uart.h"
#include "iot_errno.h"
#include "wifi_device.h"
#include "wifi_adapter.h"
#include "wifi_error_code.h"
#include "net.h"
#include "mqtt.h"

CAR_DATA car_data={0};
extern uint32_t net_sem, mqtt_sem;
extern NET_ST g_netStruct;
int mqtt_state=0;

static void led_check(){
    // RGB案序亮1000ms，然后熄灭
    printf("-----led check start-----\n");
    led_init(LED_RED);led_init(LED_GREEN);led_init(LED_BLUE);
    led_on(LED_RED);LOS_MDelay(1000);led_off(LED_RED);
    led_on(LED_GREEN);LOS_MDelay(1000);led_off(LED_GREEN);
    led_on(LED_BLUE);LOS_MDelay(1000);led_off(LED_BLUE);
    printf("-----led check over-----\n");
}
static void relay_check(){
    printf("-----relay check start-----\n");
    relay_init(RELAY);
    relay_on(RELAY);
    LOS_MDelay(1000);
    relay_off(RELAY);
    printf("-----relay check over-----\n");
}
static void key_check(){
    printf("-----key check in while start-----\n");
    key_init(KEY_UP);
    key_init(KEY_DOWN);
    key_init(KEY_FIRM);
    key_init(KEY_FAKE);
    key_init(KEY_WIFI);
#ifndef KEY_USE_INT
    uint8_t val, cnt=0;
    while(1){
        val = key_value(KEY_UP);
        if(val==0){
            led_on(LED_RED);
            cnt++;
            LOS_MDelay(1000);
        }
        val = key_value(KEY_DOWN);
        if(val==0){
            led_off(LED_RED);
            cnt++;
            LOS_MDelay(1000);
        }
        val = key_value(KEY_FIRM);
        if(val==0){
            led_on(LED_GREEN);
            cnt++;
            LOS_MDelay(1000);
        }
        val = key_value(KEY_FAKE);
        if(val==0){
            led_off(LED_GREEN);
            cnt++;
            LOS_MDelay(1000);
        }
        if(cnt>=4)
            break;
    }
#endif
    printf("-----key check in while over-----\n");
}
static void motor_check(){
    printf("----motor check start----\n");
    motor_init();
    motor_ctl(MOTOR_FORWARD, 90);
    delay_ms(1000);
    motor_ctl(MOTOR_STANDBY, 50);
    printf("----motor check over----\n");
}

static void ui_check(){
    ui_init();
    ui_show_menu();
    ui_show_cursor(1);
}

static void init_data(){
    car_data.led_red = LED_OFF;
    car_data.led_green = LED_OFF;
    car_data.led_blue = LED_OFF;
    car_data.relay = RELAY_OFF;
    car_data.motor_state = MOTOR_STANDBY;
    car_data.motor_speed = 0;
}

static void uart_check()
{
    // 初始化串口
    IotUartAttribute attr={0};
    attr.baudRate = 115200;
    attr.dataBits = IOT_UART_DATA_BIT_8;
    attr.stopBits = IOT_UART_STOP_BIT_1;
    attr.parity = IOT_UART_PARITY_NONE;
    if(IoTUartInit(1, &attr)==IOT_FAILURE){
        return;
    }
    // 打印数据
    IoTUartWrite(1, "HELLO\n", 6);
    // 接收
    char buf[30]={0};
    while(1){
        IoTUartRead(1, buf, 30);
        if(strlen(buf)>0){
            printf("buf=%s, %d\n", buf, strlen(buf));
            break;
        }
        delay_ms(2000);
    }
}
extern uint8_t ui_content[6][10];
static void update_ui_data(){
    sprintf(ui_content[0], "Red   %3s", car_data.led_red==LED_ON?"ON":"OFF");
    sprintf(ui_content[1], "Green %3s", car_data.led_green==LED_ON?"ON":"OFF");
    sprintf(ui_content[2], "Blue  %3s", car_data.led_blue==LED_ON?"ON":"OFF");
    sprintf(ui_content[3], "Relay %3s", car_data.relay==RELAY_ON?"ON":"OFF");
    sprintf(ui_content[4], "Motor %3d", car_data.motor_speed);
    sprintf(ui_content[5], "Vol %.2fV", car_data.vol);
}

static void car_entry(){
    MX_ADC1_Init();
    // 检测led
    led_check();
    // 检测继电器
    relay_check();
    // 检测key
    key_check();
    // 检测电机
    motor_check();
    init_data();
    // 检测I2C oled
    ui_check();
    uart_check();

    // 给网络参数赋初始值
    memcpy(g_netStruct.ssid, "航城蓝鸥5#-2.4G", strlen("航城蓝鸥5#-2.4G"));
    memcpy(g_netStruct.passwd,"88888888", strlen("88888888"));
    memcpy(g_netStruct.ip,"8.148.84.48", strlen("8.148.84.48"));
    g_netStruct.port = 13753;
    // 初始化wifi的串口
    WifiUartInit();
    delay_ms(1000);
    WifiErrorCode res;
    // 打开wifi功能
    res = EnableWifi();
    if(WIFI_SUCCESS){
        printf("enable wifi ok\n");
    }
WIFI_CONN:
    // 连接到热点
    res = ConnectToAP(g_netStruct.ssid, g_netStruct.passwd);
    if(WIFI_SUCCESS){
        printf("connect wifi ok\n");
    }
    // 连服务器
    if(mqtt_connect(g_netStruct.ip, g_netStruct.port)==0){
        mqtt_state = 1;
        mqtt_subscribe("server/to/device");
    }
    while(1){
        printf("---I'm working---\n");
        int len=0;
        char *buf;
        // 获取数据
        buf = mqtt_getdata(&len);
        if(buf != NULL){
            // 解析
            mqtt_parsedata(buf, len);
            free(buf);
            // 更新UI
            update_ui_data();
            ui_update_area();
        }
        //LOS_TaskDelay(3000);
        if(LOS_SemPend(net_sem,0)==LOS_OK){
            printf("get net sem, reconnect wifi\n");
            mqtt_state = 0;
            ESP8266_Transmission(0);
            LOS_TaskDelay(1000);
            goto WIFI_CONN;
        }
        if(LOS_SemPend(mqtt_sem,0)==LOS_OK){
            printf("get mqtt sem, publish data\n");
            mqtt_publish("device/to/server", car_data);
        }
    }
}

static void jump_entry(){
    while (1)
    {
        if(mqtt_state)
            mqtt_jump();
        LOS_TaskDelay(1000*90);
    }  
}

void car_task()
{
    TSK_INIT_PARAM_S param={0};
    param.pcName = "car task";
    param.uwStackSize = 0x400*4;
    param.usTaskPrio = 10;
    param.pfnTaskEntry = (TSK_ENTRY_FUNC)car_entry;

    uint32_t res, tid;
    res = LOS_TaskCreate(&tid, &param);
    if(res != LOS_OK){
        printf("%s line %d errno=%x\n", \
            __func__, __LINE__, res);
    }

    param.pcName = "jump task";
    param.uwStackSize = 0x400*4;
    param.usTaskPrio = 10;
    param.pfnTaskEntry = (TSK_ENTRY_FUNC)jump_entry;
    res = LOS_TaskCreate(&tid, &param);
    if(res != LOS_OK){
        printf("%s line %d errno=%x\n", \
            __func__, __LINE__, res);
    }
}