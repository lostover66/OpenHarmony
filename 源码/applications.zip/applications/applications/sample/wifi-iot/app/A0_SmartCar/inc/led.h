#ifndef __LED_H
#define __LED_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
#include "ll_gpio.h"

#define LED_RED     PA6
#define LED_GREEN   PA5
#define LED_BLUE    PA7

typedef enum{
    LED_OFF = 0,
    LED_ON,
}LED_STATE;

void led_init(uint16_t led);
void led_on(uint16_t led);
void led_off(uint16_t led);
LED_STATE led_state(uint16_t led);
void led_toggle(uint16_t led);

#ifdef __cplusplus
}
#endif

#endif