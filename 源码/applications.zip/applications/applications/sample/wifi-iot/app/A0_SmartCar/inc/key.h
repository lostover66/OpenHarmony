#ifndef __KEY_H
#define __KEY_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
#include "ll_gpio.h"

#define KEY_USE_INT 1

#define KEY_UP      PB12
#define KEY_DOWN    PB13
#define KEY_FIRM    PB14
#define KEY_FAKE    PB15
#define KEY_WIFI    PA1

void key_init(uint16_t key);
uint8_t key_value(uint16_t key);

#ifdef __cplusplus
}
#endif

#endif