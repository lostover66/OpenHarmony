#ifndef __UI_H
#define __UI_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
#include "stdio.h"

void ui_init();
// 显示完整界面
void ui_show_menu(); 
// 显示游标，0代表擦除，1代表显示
void ui_show_cursor(uint8_t is_show);
// 更新内容
void ui_update_area();

#ifdef __cplusplus
}
#endif

#endif