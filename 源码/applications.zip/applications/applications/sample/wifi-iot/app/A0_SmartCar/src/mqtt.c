#include "mqtt.h"
#include "stdint.h"
#include "cJSON.h"
#include "wifi_adapter.h"
#include "MQTTPacket.h"

/******系统接口，名字、参数、返回值固定*******/
// 发送数据, 返回实际发送的长度
int transport_sendPacketBuffer(int sock, unsigned char *buf, int buflen)
{
    return ESP8266_Send(buf, buflen);
}
// 接收数据, 有超时
int transport_getdata(unsigned char *buf, int count)
{
    int rc =  ESP8266_Recv(buf, count, 15);
    //printf("rec %d %d\n", count, rc);
    return rc;
}
// 接收数据， 无超时
int transport_getdatanb(void *sck, unsigned char *buf, int count)
{
    return ESP8266_Recv(buf, count, 0);
}
// 打开服务器
int transport_open(char *host, int port)
{
    if (ESP8266_ConnectTo(host, port, TCP) == 0)
    {
        ESP8266_Transmission(1); // 打开透传模式
        return 1;                // 成功
    }
    return -1; // 失败
}
// 关闭服务器
int transport_close(int sock)
{
    if (ESP8266_DisConnect() == 0)
    {
        ESP8266_Transmission(0); // 关闭透传模式
        return 0;
    }
    return -1;
}
/**********用户接口 ***********/
// 连接到服务器
int mysock;
int mqtt_connect(char *host, int port)
{
    MQTTPacket_connectData data = MQTTPacket_connectData_initializer;
    int rc = 0;
    unsigned char buf[200];
    int buflen = sizeof(buf);
    int len = 0;
    // 打开TCP服务器
    mysock = transport_open(host, port);
    if (mysock < 0)
        return mysock;
    printf("Sending to hostname %s port %d\n", host, port);

    data.clientID.cstring = "weijie"; // 由服务器提供算法，唯一id
    data.keepAliveInterval = 120;     // 保活时间，单位sec
    data.cleansession = 1;
    data.username.cstring = "testuser";     // 用户名，由服务器提供算法
    data.password.cstring = "testpassword"; // 密码
    // 序列化，结构体--->字符串
    len = MQTTSerialize_connect(buf, buflen, &data);
    // 发送
    rc = transport_sendPacketBuffer(mysock, buf, len);
    /* 等待应答 */
    // 读取应答数据
    if (MQTTPacket_read(buf, buflen, transport_getdata) == CONNACK)
    {
        unsigned char sessionPresent, connack_rc;
        // 反序列化，字符串--->结构体
        if (MQTTDeserialize_connack(&sessionPresent, &connack_rc, buf, buflen) != 1 || connack_rc != 0)
        {
            printf("Unable to connect, return code %d\n", connack_rc);
            return -1;
        }
    }
    else
    {
        printf("Unable to connect, no net\n");
        return -2;
    }
    printf("connect mqtt server ok\n");
    return 0;
}
// 断开服务器
int mqtt_disconnect()
{
    return transport_close(mysock);
}
// 订阅主题
int mqtt_subscribe(unsigned char *sub_topic)
{
    int rc = 0;
    unsigned char buf[200];
    int buflen = sizeof(buf);
    int msgid = 1;
    MQTTString topicString = MQTTString_initializer;
    int req_qos = 0;
    int len = 0;

    /* subscribe */
    // 设置主题
    topicString.cstring = sub_topic;
    // 序列化--->字符串
    len = MQTTSerialize_subscribe(buf, buflen, 0, msgid, 1, &topicString, &req_qos);
    // 发送
    rc = transport_sendPacketBuffer(mysock, buf, len);
    // 读取数据
    if (MQTTPacket_read(buf, buflen, transport_getdata) == SUBACK) /* wait for suback */
    {
        unsigned short submsgid;
        int subcount;
        int granted_qos;
        // 反序列化，判断应答
        rc = MQTTDeserialize_suback(&submsgid, 1, &subcount, &granted_qos, buf, buflen);
        if (granted_qos != 0)
        {
            printf("granted qos != 0, %d\n", granted_qos);
            return -1;
        }
    }
    else
    {
        printf("unable subscribe, no net\n");
        return -2;
    }
    printf("subscribe %s ok", sub_topic);
    return 0;
}
// 读取数据
unsigned char *mqtt_getdata(int *payloadlen_in)
{
    int rc = 0;
    unsigned char buf[200];
    int buflen = sizeof(buf);
    int len = 0;

    // 成功读取，进入if
    if (MQTTPacket_read(buf, buflen, transport_getdata) == PUBLISH)
    {
        unsigned char dup;
        int qos;
        unsigned char retained;
        unsigned short msgid;
        // int payloadlen_in;
        unsigned char *payload_in;
        int rc;
        MQTTString receivedTopic;

        rc = MQTTDeserialize_publish(&dup, &qos, &retained, &msgid, &receivedTopic,
                                     &payload_in, payloadlen_in, buf, buflen);
        printf("message arrived %.*s\n", *payloadlen_in, payload_in);
        // 申请内存
        unsigned char *tmp;
        tmp = (unsigned char *)malloc(*payloadlen_in);
        // 将消息复制到内存
        if (tmp != NULL)
        {
            memcpy(tmp, payload_in, *payloadlen_in);
            // 返回内存地址
            return tmp;
        }
    }
    // 失败
    *payloadlen_in = 0;
    return NULL;
}
// 解析
extern CAR_DATA car_data;
void mqtt_parsedata(unsigned char *payload_in, int payloadlen_in)
{
    // 使用cJSON库解析payload_in，得到键值对
    unsigned char *tmp=(unsigned char *)malloc(payloadlen_in);
    if(tmp == NULL)
        return;
    memcpy(tmp, payload_in, payloadlen_in);
    // 将字符串转为json格式
    cJSON *root = cJSON_Parse(tmp);
    // 提取每一个key-value
    cJSON *led_red = cJSON_GetObjectItem(root, "led_red");
    cJSON *led_green = cJSON_GetObjectItem(root, "led_green");
    cJSON *led_blue = cJSON_GetObjectItem(root, "led_blue");
    cJSON *relay = cJSON_GetObjectItem(root, "relay");
    cJSON *motor_speed = cJSON_GetObjectItem(root, "motor_speed");
    cJSON *motor_state = cJSON_GetObjectItem(root, "motor_state");
    // 判断value
    if(led_red != NULL){
        if(strcmp(led_red->valuestring,"on")==0){
            led_on(LED_RED);
            car_data.led_red = LED_ON;
        }else if(strcmp(led_red->valuestring,"off")==0){
            led_off(LED_RED);
            car_data.led_red = LED_OFF;
        }
    }
    if(led_green != NULL){
        if(strcmp(led_green->valuestring,"on")==0){
            led_on(LED_GREEN);
            car_data.led_green = LED_ON;
        }else if(strcmp(led_green->valuestring,"off")==0){
            led_off(LED_GREEN);
            car_data.led_green = LED_OFF;
        }
    }
    if(led_blue != NULL){
        if(strcmp(led_blue->valuestring,"on")==0){
            led_on(LED_BLUE);
            car_data.led_blue = LED_ON;
        }else if(strcmp(led_blue->valuestring,"off")==0){
            led_off(LED_BLUE);
            car_data.led_blue = LED_OFF;
        }
    }
    if(relay != NULL){
        if(strcmp(relay->valuestring,"on")==0){
            relay_on(RELAY);
            car_data.relay= RELAY_ON;
        }else if(strcmp(relay->valuestring,"off")==0){
            relay_off(RELAY);
            car_data.relay = RELAY_OFF;
        }
    }
    if(motor_state != NULL){
        if(strcmp(motor_state->valuestring, "forward")==0){
            motor_ctl(MOTOR_FORWARD, abs(motor_speed->valueint));
            car_data.motor_speed=motor_speed->valueint;
            car_data.motor_state=MOTOR_FORWARD;
        }
        else if(strcmp(motor_state->valuestring, "backward")==0){
            motor_ctl(MOTOR_BACKWARD, abs(motor_speed->valueint));
            car_data.motor_speed=motor_speed->valueint;
            car_data.motor_state=MOTOR_BACKWARD;
        }
        else if(strcmp(motor_state->valuestring, "standby")==0){
            motor_ctl(MOTOR_STANDBY, abs(motor_speed->valueint));
            car_data.motor_speed=motor_speed->valueint;
            car_data.motor_state=MOTOR_STANDBY;
        }
        else if(strcmp(motor_state->valuestring, "pause")==0){
            motor_ctl(MOTOR_PAUSE, abs(motor_speed->valueint));
            car_data.motor_speed=motor_speed->valueint;
            car_data.motor_state=MOTOR_PAUSE;
        }
    }
    cJSON_Delete(root);//root会自动释放内部节点
    free(tmp);
}
// 发布数据
/*
数据格式
{
    "led_red":"on",
    "led_green":"on",
    "led_blue":"on",
    "relay":"off",
    "motor_speed":90,
    "motor_state":"forward",
    "vol":2.48
}
原始数据存储在CAR_DATA car_data
*/
int mqtt_publish(unsigned char *pub_topic, CAR_DATA car_data)
{
    int rc = 0;
    unsigned char buf[200];
    int buflen = sizeof(buf);
    int len = 0;
    MQTTString topicString = MQTTString_initializer;

    topicString.cstring = pub_topic;
    // 将数据转为json，使用cJSON库
    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "led_red", car_data.led_red==LED_ON?"on":"off");
    cJSON_AddStringToObject(root, "led_green", car_data.led_green==LED_ON?"on":"off");
    cJSON_AddStringToObject(root, "led_blue", car_data.led_blue==LED_ON?"on":"off");
    cJSON_AddStringToObject(root, "relay", car_data.relay==RELAY_ON?"on":"off");
    char state[4][10]={"forward", "backward", "standby","pause"};
    cJSON_AddStringToObject(root, "motor_state",state[car_data.motor_state]);
    cJSON_AddNumberToObject(root, "motor_speed", car_data.motor_speed);
    car_data.vol = get_voltage(0);
    cJSON_AddNumberToObject(root, "vol", car_data.vol); 
    // 将数据序列化
    char *payload = cJSON_PrintUnformatted(root);
    // 发送
    len = MQTTSerialize_publish(buf, buflen, 0, 1, 0, 0, topicString, payload, strlen(payload));
    free(payload);
    cJSON_Delete(root);
    transport_sendPacketBuffer(mysock, buf, len);
    // 判断应答
    if(MQTTPacket_read(buf, buflen, transport_getdata)==PUBACK){
        printf("pubilsh ok\n");
        return 0;
    }else{
        printf("pubilsh failed\n");
        return -1;
    }
}
// 心跳, 发送ping包
int mqtt_jump()
{
    int rc = 0;
    unsigned char buf[200] = {0};
    int buflen = sizeof(buf);

    // 序列化ping包
    int len = MQTTSerialize_pingreq(buf, buflen);
    // 发送
    rc = transport_sendPacketBuffer(mysock, buf, len);
    // 读取应答
    if (MQTTPacket_read(buf, buflen, transport_getdata) == PINGRESP)
    {
        printf("ping ok\n");
        return 0;
    }
    printf("ping failed\n");
    return -1;
}
