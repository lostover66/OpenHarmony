#include "led.h"
#include "iot_gpio.h"
#include "iot_errno.h"

void led_init(uint16_t led){
    // 初始化引脚
    IoTGpioInit(led);
    // 设置为输出模式
    IoTGpioSetDir(led, IOT_GPIO_DIR_OUT);
    // 设置默认关灯
    IoTGpioSetOutputVal(led, LED_OFF==0?IOT_GPIO_VALUE0:IOT_GPIO_VALUE1);
}
void led_on(uint16_t led){
    IoTGpioSetOutputVal(led, LED_ON==1?IOT_GPIO_VALUE1:IOT_GPIO_VALUE0);
}
void led_off(uint16_t led){
    IoTGpioSetOutputVal(led, LED_OFF==0?IOT_GPIO_VALUE0:IOT_GPIO_VALUE1);
}
LED_STATE led_state(uint16_t led){
    IotGpioValue val;
    IoTGpioGetOutputVal(led, &val);
    return val==IOT_GPIO_VALUE1?LED_ON:LED_OFF;
}
void led_toggle(uint16_t led){
    LED_STATE state = led_state(led);
    if(state==LED_OFF)
        led_on(led);
    else
        led_off(led);
}
