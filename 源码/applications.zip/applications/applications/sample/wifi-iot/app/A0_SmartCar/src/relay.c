#include "relay.h"
#include "iot_gpio.h"
#include "iot_errno.h"

void relay_init(uint16_t relay){
    // 初始化引脚
    IoTGpioInit(relay);
    // 设置为输出模式
    IoTGpioSetDir(relay, IOT_GPIO_DIR_OUT);
    // 设置默认关灯
    IoTGpioSetOutputVal(relay, RELAY_OFF==0?IOT_GPIO_VALUE0:IOT_GPIO_VALUE1);
}
void relay_on(uint16_t relay){
    IoTGpioSetOutputVal(relay, RELAY_ON==1?IOT_GPIO_VALUE1:IOT_GPIO_VALUE0);
}
void relay_off(uint16_t relay){
    IoTGpioSetOutputVal(relay, RELAY_OFF==0?IOT_GPIO_VALUE0:IOT_GPIO_VALUE1);
}
RELAY_STATE relay_state(uint16_t relay){
    IotGpioValue val;
    IoTGpioGetOutputVal(relay, &val);
    return val==IOT_GPIO_VALUE1?RELAY_ON:RELAY_OFF;
}
void relay_toggle(uint16_t relay){
    RELAY_STATE state = relay_state(relay);
    if(state==RELAY_OFF)
        relay_on(relay);
    else
        relay_off(relay);
}
