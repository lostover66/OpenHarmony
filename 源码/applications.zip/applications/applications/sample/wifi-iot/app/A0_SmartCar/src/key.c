#include "key.h"
#include "iot_gpio.h"
#include "stdio.h"
#include "led.h"
#include "relay.h"
#include "car.h"
#include "adc.h"
#include "los_sem.h"

uint32_t key_sem;
uint32_t mqtt_sem;
extern uint8_t ui_idx;
extern uint8_t ui_content[6][10];
extern CAR_DATA car_data;

void key_handler(uint16_t pin){
    // 上下控制游标位置
    if(pin==KEY_UP){
        // led_toggle(LED_RED);
        // 擦除旧的
        ui_show_cursor(0);
        // 显示新的
        // 如果ui_idx>0 减1；如果=0，ui_idx变成5
        if(ui_idx>0)
            ui_idx--;
        else
            ui_idx = 5;
        ui_show_cursor(1);
    }else if(pin==KEY_DOWN){
        // led_toggle(LED_GREEN);
        // 擦除旧的
        ui_show_cursor(0);
        // 显示新的
        // 如果ui_idx<5 加1；如果=5，ui_idx变成0
        if(ui_idx<5)
            ui_idx++;
        else
            ui_idx = 0;
        ui_show_cursor(1);
    }else if(pin==KEY_FIRM){
        // led_toggle(LED_BLUE);
        if(ui_idx==0){
            // 开红灯
            led_on(LED_RED);
            // 保存状态car_data
            car_data.led_red = LED_ON;
            // 刷新ui
            //ui_content[ui_idx]="RED ON";
            sprintf(ui_content[ui_idx],"RED    ON");
            ui_update_area();
            // 更新网络数据
        }else if(ui_idx==1){
            // 开绿灯
            led_on(LED_GREEN);
            // 保存状态car_data
            car_data.led_green = LED_ON;
            // 刷新ui
            //ui_content[ui_idx]="RED ON";
            sprintf(ui_content[ui_idx],"Green  ON");
            ui_update_area();
            // 更新网络数据
        }else if(ui_idx==2){
            // 开蓝灯
            led_on(LED_BLUE);
            // 保存状态car_data
            car_data.led_blue = LED_ON;
            // 刷新ui
            sprintf(ui_content[ui_idx],"Blue   ON");
            ui_update_area();
            // 更新网络数据
        }else if(ui_idx==3){
            // 打开继电器
            relay_on(RELAY);
            // 保存状态car_data
            car_data.relay= RELAY_ON;
            // 刷新ui
            sprintf(ui_content[ui_idx],"Relay  ON");
            ui_update_area();
            // 更新网络数据
        }else if(ui_idx==4){
            // 电机加速 范围 -100<=speed<=100 
            // 负数表示反转，正数表示正转
            car_data.motor_speed += 10;
            if(car_data.motor_speed >= 100)
                car_data.motor_speed = 100;
            if(car_data.motor_speed < 0)
                car_data.motor_state = MOTOR_BACKWARD;
            else if(car_data.motor_speed == 0)
                car_data.motor_state = MOTOR_STANDBY;
            else if(car_data.motor_speed > 0)
                car_data.motor_state = MOTOR_FORWARD;
            motor_ctl(car_data.motor_state, abs(car_data.motor_speed));
            // 刷新ui
            sprintf(ui_content[ui_idx],"Motor %3d", car_data.motor_speed);
            ui_update_area();
            // 更新网络数据
        }else if(ui_idx==5){
            // 获取电压
            car_data.vol = get_voltage(0);
            // 刷新ui
            sprintf(ui_content[ui_idx],"Vol %.2fV", car_data.vol);
            ui_update_area();
            // 更新网络数据 
        }
        //mqtt_publish()
        LOS_SemPost(mqtt_sem);
    }else if(pin==KEY_FAKE){
        // relay_toggle(RELAY);
        if(ui_idx==0){
            // 开红灯
            led_off(LED_RED);
            // 保存状态car_data
            car_data.led_red = LED_OFF;
            // 刷新ui
            sprintf(ui_content[ui_idx],"RED   OFF");
            ui_update_area();
            // 更新网络数据
        }else if(ui_idx==1){
            // 开绿灯
            led_off(LED_GREEN);
            // 保存状态car_data
            car_data.led_green = LED_OFF;
            // 刷新ui
            //ui_content[ui_idx]="RED ON";
            sprintf(ui_content[ui_idx],"Green OFF");
            ui_update_area();
            // 更新网络数据
        }else if(ui_idx==2){
            // 开蓝灯
            led_off(LED_BLUE);
            // 保存状态car_data
            car_data.led_blue = LED_OFF;
            // 刷新ui
            sprintf(ui_content[ui_idx],"Blue  OFF");
            ui_update_area();
            // 更新网络数据
        }else if(ui_idx==3){
            // 打开继电器
            relay_off(RELAY);
            // 保存状态car_data
            car_data.relay= RELAY_OFF;
            // 刷新ui
            sprintf(ui_content[ui_idx],"Relay OFF");
            ui_update_area();
            // 更新网络数据
        }else if(ui_idx==4){
            // 电机加速 范围 -100<=speed<=100 
            // 负数表示反转，正数表示正转
            car_data.motor_speed -= 10;
            if(car_data.motor_speed <= -100)
                car_data.motor_speed = -100;
            if(car_data.motor_speed < 0)
                car_data.motor_state = MOTOR_BACKWARD;
            else if(car_data.motor_speed == 0)
                car_data.motor_state = MOTOR_STANDBY;
            else if(car_data.motor_speed > 0)
                car_data.motor_state = MOTOR_FORWARD;
            motor_ctl(car_data.motor_state, abs(car_data.motor_speed));
            // 刷新ui
            sprintf(ui_content[ui_idx],"Motor %3d", car_data.motor_speed);
            ui_update_area();
            // 更新网络数据
        }else if(ui_idx==5){
            // 获取电压
            car_data.vol = get_voltage(0);
            // 刷新ui
            sprintf(ui_content[ui_idx],"Vol %.2fV", car_data.vol);
            ui_update_area();
            // 更新网络数据 
        }
        LOS_SemPost(mqtt_sem);
    }else if(pin==KEY_WIFI){
        printf("key wifi\n");
        LOS_SemPost(key_sem);
    }
}

void key_init(uint16_t key){
    uint32_t res;
    res = LOS_SemCreate(0, &key_sem);
    if(res!=LOS_OK){
        printf("create key sem failed\n");
        return;
    }
    res = LOS_SemCreate(0, &mqtt_sem);
    if(res!=LOS_OK){
        printf("create mqtt sem failed\n");
        return;
    }
    IoTGpioInit(key);
    IoTGpioSetDir(key, IOT_GPIO_DIR_IN);
#if KEY_USE_INT
    IoTGpioRegisterIsrFunc(key,\
    IOT_INT_TYPE_EDGE,\
    IOT_GPIO_EDGE_FALL_LEVEL_LOW,\
    key_handler, NULL);
#endif
}
uint8_t key_value(uint16_t key){
    IotGpioValue val;
    IoTGpioGetInputVal(key, &val);
    return val==IOT_GPIO_VALUE0?0:1;
}