#ifndef __RELAY_H
#define __RELAY_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
#include "ll_gpio.h"

#define RELAY   PD11

typedef enum{
    RELAY_OFF = 0,
    RELAY_ON,
}RELAY_STATE;

void relay_init(uint16_t relay);
void relay_on(uint16_t relay);
void relay_off(uint16_t relay);
RELAY_STATE relay_state(uint16_t relay);
void relay_toggle(uint16_t relay);

#ifdef __cplusplus
}
#endif

#endif