#include "motor.h"
#include "iot_pwm.h"

void motor_init(){
    IoTPwmInit(MOTOR_A);// 将引脚初始化为pwm
    IoTPwmStop(MOTOR_A);
    IoTPwmInit(MOTOR_B);
    IoTPwmStop(MOTOR_B);
}
void motor_ctl(MOTOR_STATE state, uint8_t speed){
    if(state == MOTOR_FORWARD){
        //IoTPwmStop(MOTOR_B);
        IoTPwmStart(MOTOR_A, speed, 1000*50);
    }
    else if(state == MOTOR_BACKWARD){
        IoTPwmStop(MOTOR_A);
        IoTPwmStart(MOTOR_B, speed, 1000*50);
    }
    else if(state == MOTOR_STANDBY){
        IoTPwmStop(MOTOR_A);
        IoTPwmStop(MOTOR_B);
    }
    else if(state == MOTOR_PAUSE){
        IoTPwmStart(MOTOR_A, speed, 1000*50);
        IoTPwmStart(MOTOR_B, speed, 1000*50);
    }
}