#ifndef __MQTT_H
#define __MQTT_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
#include "car.h"
/******系统接口，名字、参数、返回值固定*******/
// 发送数据
int transport_sendPacketBuffer(int sock, unsigned char* buf, int buflen);
// 接收数据
int transport_getdata(unsigned char* buf, int count);
// 接收数据， 有超时
int transport_getdatanb(void *sck, unsigned char* buf, int count);
// 打开服务器
int transport_open(char* host, int port);
// 关闭服务器
int transport_close(int sock);
/**********用户接口 ***********/
// 连接到服务器
int mqtt_connect(char *host, int port);
// 断开服务器
int mqtt_disconnect();
// 订阅主题
int mqtt_subscribe(unsigned char *sub_topic);
// 读取数据
unsigned char *mqtt_getdata(int *payloadlen_in);
// 解析
void mqtt_parsedata(unsigned char *payload_in, int payloadlen_in);
// 发布数据
int mqtt_publish(unsigned char *pub_topic, CAR_DATA car_data);
// 心跳
int mqtt_jump();
#ifdef __cplusplus
}
#endif

#endif