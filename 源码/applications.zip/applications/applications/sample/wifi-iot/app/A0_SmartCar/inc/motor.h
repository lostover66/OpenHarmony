#ifndef __MOTOR_H
#define __MOTOR_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"

#define MOTOR_A 12 //PD12
#define MOTOR_B 13 //PD13

typedef enum{
    MOTOR_FORWARD,
    MOTOR_BACKWARD,
    MOTOR_STANDBY,
    MOTOR_PAUSE,
}MOTOR_STATE;

void motor_init();
void motor_ctl(MOTOR_STATE state, uint8_t speed);

#ifdef __cplusplus
}
#endif

#endif