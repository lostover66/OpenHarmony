#ifndef __NET_H
#define __NET_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"

typedef struct{
    char ssid[64];
    char passwd[32];
    char ip[16];
    int port;
}NET_ST;

void net_task();

#ifdef __cplusplus
}
#endif

#endif