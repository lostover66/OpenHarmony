#include "net.h"
#include "los_task.h"
#include "los_sem.h"
#include "iot_uart.h"

uint32_t net_sem;
NET_ST g_netStruct={0};
extern uint32_t key_sem;
int net_decode(char *buf, NET_ST *net_st)
{
    NET_ST tmp = {0};
    int found_ssid = 0;
    int found_passwd = 0;
    int found_host = 0;
    int found_port = 0;
    char *p = buf;

    if (buf == NULL || net_st == NULL) {
        return -1;
    }

    while (*p != '\0') {
        /* 跳过字段之间的空格、逗号、换行等 */
        while (*p == ' ' || *p == '\t' || *p == ',' ||
               *p == '\r' || *p == '\n') {
            p++;
        }
        if (*p == '\0') {
            break;
        }

        /* 当前字段结束位置：逗号、换行或字符串结尾 */
        char *field_end = p;
        while (*field_end != '\0' &&
               *field_end != ',' &&
               *field_end != '\r' &&
               *field_end != '\n') {
            field_end++;
        }

        /* 在当前字段中查找 '=' */
        char *eq = p;
        while (eq < field_end && *eq != '=') {
            eq++;
        }
        if (eq == field_end) {
            return -1;
        }

        /* 去掉 key 尾部空格 */
        char *key_end = eq;
        while (key_end > p &&
               (key_end[-1] == ' ' || key_end[-1] == '\t')) {
            key_end--;
        }
        int key_len = (int)(key_end - p);

        /* 去掉 value 前导和尾部空格 */
        char *val = eq + 1;
        while (val < field_end &&
               (*val == ' ' || *val == '\t')) {
            val++;
        }
        char *val_end = field_end;
        while (val_end > val &&
               (val_end[-1] == ' ' || val_end[-1] == '\t')) {
            val_end--;
        }
        int val_len = (int)(val_end - val);

        if (key_len == 4 && strncmp(p, "ssid", 4) == 0) {
            if (val_len >= (int)sizeof(tmp.ssid)) {
                return -1;
            }
            memcpy(tmp.ssid, val, val_len);
            tmp.ssid[val_len] = '\0';
            found_ssid = 1;
        } else if (key_len == 6 && strncmp(p, "passwd", 6) == 0) {
            if (val_len >= (int)sizeof(tmp.passwd)) {
                return -1;
            }
            memcpy(tmp.passwd, val, val_len);
            tmp.passwd[val_len] = '\0';
            found_passwd = 1;
        } else if (key_len == 4 && strncmp(p, "host", 4) == 0) {
            if (val_len >= (int)sizeof(tmp.ip)) {
                return -1;
            }
            memcpy(tmp.ip, val, val_len);
            tmp.ip[val_len] = '\0';
            found_host = 1;
        } else if (key_len == 4 && strncmp(p, "port", 4) == 0) {
            int port = 0;
            int i;

            if (val_len == 0 || val_len > 5) {
                return -1;
            }

            for (i = 0; i < val_len; i++) {
                if (val[i] < '0' || val[i] > '9') {
                    return -1;
                }
                port = port * 10 + (val[i] - '0');
            }

            if (port <= 0 || port > 65535) {
                return -1;
            }

            tmp.port = port;
            found_port = 1;
        }
        /* 未知字段直接忽略 */

        p = field_end;
    }

    if (!found_ssid || !found_passwd || !found_host || !found_port) {
        return -1;
    }

    *net_st = tmp;
    return 0;
}

void net_entry(){
    printf("----net task start----\n");
    while(1){
        // 如果按下wifi_key读取串口1数据
        if(LOS_SemPend(key_sem,0)!=LOS_OK)
            continue;
        char buf[128]={0};//64+32+16+4
        IoTUartRead(1, buf, 128);
        // 解析得到新的ssid passwd host ip
        if(strlen(buf)>0){
            // ssid=Mate30,passwd=12345678,host=8.148.84.48,port=8765
            if(net_decode(buf, &g_netStruct)==0){
                printf("%s %s %s %d\n",g_netStruct.ssid, g_netStruct.passwd, \
                  g_netStruct.ip, g_netStruct.port);
                // 发送信号，通知其他任务网络可以更新
                if(LOS_SemPost(net_sem)==LOS_OK){
                    printf("post net_sem ok\n");
                }
            }
        } 
    }
}
void net_task(){
    TSK_INIT_PARAM_S param={0};
    param.pcName = "net task";
    param.usTaskPrio = 10;
    param.uwStackSize = 0x400*4;
    param.pfnTaskEntry = (TSK_ENTRY_FUNC)net_entry;
    uint32_t res, tid;
    res = LOS_TaskCreate(&tid, &param);
    if(res!=LOS_OK){
        printf("create net task failed\n");
        return;
    }
    res = LOS_SemCreate(0, &net_sem);
    if(res!=LOS_OK){
        printf("create sem failed\n");
        return;
    }
}