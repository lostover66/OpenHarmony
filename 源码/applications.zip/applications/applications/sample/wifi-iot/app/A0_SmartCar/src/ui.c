#include "ui.h"
#include "oled.h"
#include "iot_i2c.h"
#include "iot_errno.h"
#include "los_swtmr.h"

uint8_t ui_content[6][10]={
    "Red   OFF",
    "Green OFF",
    "Blue  OFF",
    "Relay OFF",
    "Motor   0",
    "Vol 1.45v"
};
uint8_t ui_idx=0;

// 一个长标题，长度大于21，超出oled的宽度
uint8_t ui_title[]="OpenHarmony V1.0, author weijie, 2026.11.18, 16:29:30";
// 软件定时器id
uint32_t swtmr_id;
// 当前的显示偏移量
uint8_t title_offset=0;
// 定时器回调
void swtmr_cb(){
    // 获取总长度
    uint8_t title_len=strlen(ui_title);
    uint8_t tmp[17];
    // 复制一部分内容到tmp
    memcpy(tmp, ui_title+title_offset, 16);
    // 清除标题那一行
    OLED_ClearArea(0,0,128);
    // 显示tmp数据，这是标题的一部分
    OLED_ShowString((128-6*16)/2, 0, tmp, 12);
    // 偏移量增加
    title_offset++;
    // 防止超出范围
    if(title_offset>title_len-1-16)
        title_offset = 0;
}

void ui_init(){
    // 初始化i2c
    if(IoTI2cInit(OLED_I2C_PORT, 100*1000)!=IOT_SUCCESS){
        printf("I2C Init failed\n");
        return;
    }
    // 初始化oled
    OLED_Init();
    // 清屏
    OLED_Clear();
    // 显示标题
    OLED_ShowString((128-6*11)/2, 0, "weijie V1.0", 12);
    OLED_ShowString((128-6*13)/2, 1, "TH 21C,RH 67%", 12);
    // 启动一个软件定时器，在定时回调函数内显示标题
    uint32_t ret;
    ret = LOS_SwtmrCreate(LOS_MS2Tick(250), \
        LOS_SWTMR_MODE_PERIOD,
        swtmr_cb, &swtmr_id, 0,0,0
    );
    if(ret != LOS_OK){
        printf("create swtmr failed, errno=%x\n",ret);
        return;
    }
    //LOS_SwtmrStart(swtmr_id);
}

void ui_show_menu(){
    OLED_ShowString(0+7, 3, ui_content[0], 12);
    OLED_ShowString(0+7, 5, ui_content[1], 12);
    OLED_ShowString(0+7, 7, ui_content[2], 12);

    OLED_ShowString(64+7, 3, ui_content[3], 12);
    OLED_ShowString(64+7, 5, ui_content[4], 12);
    OLED_ShowString(64+7, 7, ui_content[5], 12);
}
void ui_show_cursor(uint8_t is_show){
    /*
        ui_idx  x   y
        0       0   3
        1       0   5
        2       0   7
        3       64  3
        4       64  5
        5       64  7
    */
    uint8_t x = (ui_idx/3)*64;
    uint8_t y = (ui_idx%3)*2+3;
    if(is_show)
        OLED_ShowChar(x, y, '>', 12);
    else
        //OLED_ShowChar(x, y, ' ', 12);
        OLED_ClearArea(x, y, 6);
}

void ui_update_area(){
    /*
        ui_idx  x   y
        0       0+7 3
        1       0+7 5
        2       0+7 7
        3       64+7 3
        4       64+7 5
        5       64+7 7
    */
    uint8_t x = (ui_idx/3)*64+7;
    uint8_t y = (ui_idx%3)*2+3;
    OLED_ShowString(x,y, ui_content[ui_idx], 12);
}