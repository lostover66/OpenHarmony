#ifndef __CAR_H
#define __CAR_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
#include "led.h"
#include "relay.h"
#include "motor.h"

typedef struct{
    LED_STATE led_red;
    LED_STATE led_green;
    LED_STATE led_blue; 
    RELAY_STATE relay;
    MOTOR_STATE motor_state;
    int8_t motor_speed;
    float vol;
}CAR_DATA;

void car_task();

#ifdef __cplusplus
}
#endif

#endif