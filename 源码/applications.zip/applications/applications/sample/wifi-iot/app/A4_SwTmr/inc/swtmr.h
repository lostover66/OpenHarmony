#ifndef __SWTMR_H
#define __SWTMR_H

#ifdef __cplusplus
extern "C" {
#endif

// 用户代码区
#include "stdio.h"
void swtmr_demo();

#ifdef __cplusplus
}
#endif

#endif