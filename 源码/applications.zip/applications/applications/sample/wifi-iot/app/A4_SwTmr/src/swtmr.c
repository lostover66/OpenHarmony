#include "swtmr.h"
#include "los_task.h"
#include "los_tick.h"
#include "los_swtmr.h"
#include "stdint.h"
uint32_t tid1, swtmr_id;
void swtmr_cb(){
    printf("I'm weijie, swtmr1 is running\n");
    uint64_t ns = LOS_CurrNanosec();
    printf("开机到目前经历 %d 毫秒\n", ns/100000);
}
void task1_entry(){
    uint32_t ret;
    ret = LOS_SwtmrCreate(LOS_MS2Tick(5000), \
        LOS_SWTMR_MODE_PERIOD,
        swtmr_cb, &swtmr_id, 0,0,0
    );
    if(ret != LOS_OK){
        printf("create swtmr failed, errno=%x\n",ret);
        return;
    }
    LOS_SwtmrStart(swtmr_id);
}

void swtmr_demo(){
    
    TSK_INIT_PARAM_S param;
    param.pcName = "task1";
    param.usTaskPrio = 10;
    param.uwStackSize = 0x100*16;
    param.pfnTaskEntry = task1_entry;
    uint32_t ret = LOS_TaskCreate(&tid1, &param);
    if(ret != LOS_OK){
        printf("create task1 failed, errno=%x\n",ret);
        return;
    }
}