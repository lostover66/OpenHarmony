/*
工作日 早7点  开，
休息日 早10点 开
每天20点      关

EVT_WORK  EVT_REST  EVT_7  EVT_10   EVT_20
*/
#include "stdio.h"
#include "stdint.h"
#include "los_task.h"
#include "los_event.h"

#define EVT_WORK    0x01
#define EVT_REST    0x02
#define EVT_7       0x04
#define EVT_10      0x08
#define EVT_20      0x10

uint8_t evt_arr[5]={EVT_WORK, EVT_REST, EVT_7, EVT_10, EVT_20};
char log[5][15]={"工作日", "休息日", "早7点", "早10点", "晚8点"};
EVENT_CB_S event;
// 利用随机数触发事件
static void event_entry(){
    while(1){
        // 产生随机数
        srand(time(NULL));
        uint8_t i = rand()%5; // 产生0~4之间的随机数
        LOS_EventWrite(&event, evt_arr[i]);
        printf("event %s happend\n", log[i]);
        LOS_TaskDelay(3000);
    }
}
static void curtains_entry(){
    uint32_t ret;
    while(1){
        // 读取EVT_WORK和EVT_7，等待它们同时发生;如果成功，则清除事件
        ret = LOS_EventRead(&event, EVT_WORK|EVT_7, LOS_WAITMODE_AND|LOS_WAITMODE_CLR, 0);
        if(ret == (EVT_WORK|EVT_7)){
            printf("open curtains, at workday 7:00.am\n");
        }
        ret = LOS_EventRead(&event, EVT_REST|EVT_10, LOS_WAITMODE_AND|LOS_WAITMODE_CLR, 0);
        if(ret == (EVT_REST|EVT_10)){
            printf("open curtains, at weekend 10:00.am\n");
        }
        ret = LOS_EventRead(&event, EVT_20, LOS_WAITMODE_OR|LOS_WAITMODE_CLR, 0);
        if(ret == EVT_20){
            printf("close curtains, at 8:00.pm\n");
        }
        LOS_TaskDelay(5);
    }
}
void event_demo(){
    // 初始化事件
    LOS_EventInit(&event);
    // 创建任务
    uint32_t ret;
    uint32_t tid;
    TSK_INIT_PARAM_S param={0};
    // 创建任务1 tid由系统回传，不需要初始化
    param.pfnTaskEntry = event_entry;//任务入口
    param.usTaskPrio = 10;
    param.uwStackSize = 0x2000;
    param.pcName = "event";
    ret = LOS_TaskCreate(&tid, &param);
    if(ret != LOS_OK){
        printf("create task event errno=0x%x",ret);
        return 0;
    }
    param.pfnTaskEntry = curtains_entry;//任务入口
    param.usTaskPrio = 10;
    param.uwStackSize = 0x2000;
    param.pcName = "curtains";
    ret = LOS_TaskCreate(&tid, &param);
    if(ret != LOS_OK){
        printf("create task curtains errno=0x%x",ret);
        return 0;
    }
}
