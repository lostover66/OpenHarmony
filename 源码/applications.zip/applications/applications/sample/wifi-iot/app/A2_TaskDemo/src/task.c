#include "task.h"
#include "los_task.h"
#include "stdint.h"
uint32_t tid1,tid2;
void task1_entry(){
    while(1){
        printf("I'm weijie, running task1...\n");
        LOS_TaskResume(tid2); // 恢复任务2
        LOS_TaskSuspend(tid1);// 挂起任务1
        LOS_TaskDelay(1000*1);// 延时1000tick,默认1tick=1ms
    } 
}
void task2_entry(){
    while(1){
        printf("I'm weijie, running task2...\n");
        LOS_TaskResume(tid1);
        LOS_TaskSuspend(tid2);
        LOS_TaskDelay(1000*1);
    } 
}

void task_demo(){
    
    TSK_INIT_PARAM_S param;
    param.pcName = "task1";
    param.usTaskPrio = 10;
    param.uwStackSize = 0x100*16;
    param.pfnTaskEntry = task1_entry;
    uint32_t ret = LOS_TaskCreate(&tid1, &param);
    if(ret != LOS_OK){
        printf("create task1 failed, errno=%x\n",ret);
        return;
    }
    param.pcName = "task2";
    param.usTaskPrio = 10;
    param.uwStackSize = 0x100*16;
    param.pfnTaskEntry = task2_entry;
    ret = LOS_TaskCreate(&tid2, &param);
    if(ret != LOS_OK){
        printf("create task2 failed, errno=%x\n",ret);
        return;
    }
}