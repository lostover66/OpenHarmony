#ifndef __TASK_H
#define __TASK_H

#ifdef __cplusplus
extern "C" {
#endif

// 用户代码区
#include "stdio.h"
void task_demo();

#ifdef __cplusplus
}
#endif

#endif