#ifndef __SEM_H
#define __SEM_H

#ifdef __cplusplus
extern "C" {
#endif

// 用户代码区
#include "stdio.h"
void sem_demo();

#ifdef __cplusplus
}
#endif

#endif