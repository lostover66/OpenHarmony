#include "sem.h"
#include "los_task.h"
#include "los_sem.h"
#include "stdint.h"
uint32_t tid_p1,tid_p2,tid_p3, tid_c, sem;

static void producer1_entry(){

}
static void producer2_entry(){

}
static void producer3_entry(){
 
}
static void customer_entry(){
 
}

void sem_demo(){
    LOS_SemCreate(0, &sem);
    TSK_INIT_PARAM_S param;
    param.pcName = "task_p1";
    param.usTaskPrio = 10;
    param.uwStackSize = 0x100*16;
    param.pfnTaskEntry = producer1_entry;
    uint32_t ret = LOS_TaskCreate(&tid_p1, &param);
    if(ret != LOS_OK){
        printf("create task_p1 failed, errno=%x\n",ret);
        return;
    }
    param.pcName = "task_p2";
    param.usTaskPrio = 10;
    param.uwStackSize = 0x100*16;
    param.pfnTaskEntry = producer2_entry;
    ret = LOS_TaskCreate(&tid_p2, &param);
    if(ret != LOS_OK){
        printf("create task_p2 failed, errno=%x\n",ret);
        return;
    }
    param.pcName = "task_p3";
    param.usTaskPrio = 10;
    param.uwStackSize = 0x100*16;
    param.pfnTaskEntry = producer3_entry;
    ret = LOS_TaskCreate(&tid_p3, &param);
    if(ret != LOS_OK){
        printf("create task_p3 failed, errno=%x\n",ret);
        return;
    }
    param.pcName = "task_c";
    param.usTaskPrio = 10;
    param.uwStackSize = 0x100*16;
    param.pfnTaskEntry = customer_entry;
    ret = LOS_TaskCreate(&tid_c, &param);
    if(ret != LOS_OK){
        printf("create task_c failed, errno=%x\n",ret);
        return;
    }
}
